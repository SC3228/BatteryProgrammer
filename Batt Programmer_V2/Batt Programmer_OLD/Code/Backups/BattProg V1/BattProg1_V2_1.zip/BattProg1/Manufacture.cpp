// Battery manufacture stuff

#include <Arduino.h>

#include "pwmbatt.h"
#include "BattProg.h"
#include "aes.h"
#include "F:\ArduinoKeys.h"
#include "GasGauge.h"

// Manufacture PP+ data
uint8_t ManufacturePPP(uint8_t *Buf)
{
	return (1);
}

// Manufacture Pollux data
uint8_t ManufacturePollux(uint8_t *Buf, uint8_t Format)
{
	// Get needed data

	return (1);
}

// Manufacture Hawkeye data
uint8_t ManufactureHawkeye(uint8_t *Buf)
{
	return (1);
}
