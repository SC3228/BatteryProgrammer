// Battery data table stuff
// NOTE: All battery type# defined in BattProg.h. Keep in sync!!!
const char NoBatt[] PROGMEM = "No Battery";
const char MPA2PP[] PROGMEM = "MPA2 PP";
const char MC95[] PROGMEM = "MC95 PP";
const char MC18[] PROGMEM = "MC18 PP+";
const char Rouge[] PROGMEM = "Rouge/TC8000";
const char Frenzy[] PROGMEM = "Frenzy/WT6000";
const char IronMan[] PROGMEM = "IronMan/Lightning";
const char Pollux[] PROGMEM = "Pollux";
const char Falcon[] PROGMEM = "Falcon/Thunder";
const char Hawkeye[] PROGMEM = "Hawkeye/TC20";
const char Sentry[] PROGMEM = "Sentry/Elektra";
const char Galactus[] PROGMEM = "Galactus/Badger/Firebird/Frozone Auth";
const char Frozone[] PROGMEM = "Frozone EEPROM";
const char Meteor[] PROGMEM = "Value Tier Battery";
const char NewGauge[] PROGMEM = "PP+ V2 Battery";

// Supported battery table
BattData Batts[MAX_BATTERY_TYPES] = {
	// No battery
	{0,0,0,0,0,
		0,0,
		PULLUP_VBATT,PULLUP_NONE,0,
		NO_KEYS,NoBatt,MIN_VOLTAGE,
		0},
	// MPA2 PP
	{MPA2_EEPROM_ADDR,MPA2_TMP_ADDR,0,0,0,
		MPA2_EEPROM_SIZE,MPA2_PAGE_SIZE,
		PULLUP_V3p3,PULLUP_2p9K,1,
		NO_KEYS,MPA2PP,MIN_VOLTAGE,
		0},
	// MC95 PP
	{MPA2_EEPROM_ADDR,MPA2_TMP_ADDR,0,0,0,
		MPA2_EEPROM_SIZE,MPA2_PAGE_SIZE,
		PULLUP_V3p3,PULLUP_2p9K,0,
		NO_KEYS,MC95,3100,
		0},
	// MC18 PP+
	{MPA3_EEPROM_ADDR,MPA3_TMP_ADDR,MPA3_GG_ADDR,0,0,
		MPA3_EEPROM_SIZE,MPA3_PAGE_SIZE,
		PULLUP_V3p3,PULLUP_2p9K,1,
		MPA3_KEYS,MC18,MIN_VOLTAGE,
		0},
	// Rouge
	{MPA3_EEPROM_ADDR,MPA3_TMP_ADDR,MPA3_GG_ADDR,0,0,
		MPA3_EEPROM_SIZE,MPA3_PAGE_SIZE,
		PULLUP_V3p3,PULLUP_3p4K,1,
		MPA3_KEYS,Rouge,MIN_VOLTAGE,
		0},
	// Frenzy
	{MPA3_EEPROM_ADDR,MPA3_TMP_ADDR,MPA3_GG_ADDR,0,0,
		MPA3_EEPROM_SIZE,MPA3_PAGE_SIZE,
		PULLUP_V3p3,PULLUP_3p4K,1,
		MPA3_KEYS,Frenzy,MIN_VOLTAGE,
		0},
	// IronMan
	{MPA2_EEPROM_ADDR,0,MPA3_GG_ADDR,AUTH_CHIP_ADDR,0,
		QC_EEPROM_SIZE,QC_PAGE_SIZE,
		PULLUP_VBATT,PULLUP_2p3K,0,
		IRONMAN_KEYS,IronMan,MIN_VOLTAGE,
		1},
	// Pollux
	{MPA2_EEPROM_ADDR,0,0,0,0,
		POLLUX_EEPROM_SIZE,POLLUX_PAGE_SIZE,
		PULLUP_VBATT,PULLUP_5p1K,0,
		NO_KEYS,Pollux,MIN_VOLTAGE,
		1},
	// Falcon
	{MPA2_EEPROM_ADDR,0,MPA3_GG_ADDR,AUTH_CHIP_ADDR,0,
		QC_EEPROM_SIZE,QC_PAGE_SIZE,
		PULLUP_VBATT,PULLUP_5p1K,0,
		FALCON_KEYS,Falcon,MIN_VOLTAGE,
		1},
	// Hawkeye
	{0,0,0,AUTH_CHIP_ADDR,1,
		0,0,
		PULLUP_VBATT,PULLUP_NONE,0,
		NO_KEYS,Hawkeye,MIN_VOLTAGE,
		1},
	// Sentry
	{MPA2_EEPROM_ADDR,0,MPA3_GG_ADDR,AUTH_CHIP_ADDR,1,
		QC_EEPROM_SIZE,QC_PAGE_SIZE,
		PULLUP_VBATT,PULLUP_5p1K,0,
		FALCON_KEYS,Sentry,MIN_VOLTAGE,
		1},
	// Galactus Auth data
	{0,0,MPA3_GG_ADDR,AUTH_CHIP_ADDR,1,
		0,0,
		PULLUP_VBATT,PULLUP_2p3K,0,
		FALCON_KEYS,Galactus,MIN_VOLTAGE,
		1},
	// Frozone EEPROM
	{MPA2_EEPROM_ADDR,0,0,0,0,
		POLLUX_EEPROM_SIZE,POLLUX_PAGE_SIZE,
		PULLUP_VBATT,PULLUP_5p1K,0,
		NO_KEYS,Frozone,MIN_VOLTAGE,
		1},
	// Value Tier Auth data
	{0,0,0,AUTH_CHIP_ADDR,1,
		0,0,
		PULLUP_VBATT,PULLUP_2p3K,0,
		NO_KEYS,Meteor,MIN_VOLTAGE,
		1},
	// New gauge V2 PP+ battery
	{0,0,MPA3_GG_ADDR,AUTH_CHIP_ADDR,1,
		0,0,
		PULLUP_VBATT,PULLUP_2p3K,0,
		NO_KEYS,NewGauge,MIN_VOLTAGE,
		1},
};

