//--------------------------------------------------------------------
// FILENAME:	BattMan_main.c
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	Battery manager KLM main file, handles init/deinit, etc..
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

/*
Version history
7.07	Added support for 16K EEPROM for VT batts

7.06	Changes to support independent ko builds for ZebraAuth and GiftedBattery

7.05	Removed UseEnhancedStatus flag as it must always be enabled

7.04	Removed logic for old load and build method (only ko now)
		Restructured code to be independent o objects and not one large source code file

7.03	Implemented calibration for the new gas gauge
		Updated the keys.h file to the new format for use in
		test builds.

7.02	Started GG reg read right after checking NGG batt is the same one after a resume.

7.01	Added supprot for a single module with all keys.

7.00	Added logic for being an independent ko file and not included as part of GiftedBattery driver
		Added wrapper methods for pointer functions to handle nocfi issues
		Moved init logic into new BattMan_loadStruct function

6.08	Added an "internal" battery type to simplify various state machines, etc.
		with the addition of the new gas gauge support. This will also make it
		simpler going forward to add new battery/gas gauge types.

6.07	Added more debug statements to pm_proc to help trace errors.
		Removed duplicate file include staements and duplicate varible definitions.
		Changed AES functions to use internel copy routine instead of memcopy. This
		prevents the stack issue seen on the 6490 builds.
		Added support for the hysteresis value used in extended temp charging for
		VT and V2 PP+ batts. Used a fixed 2 deg value for V1 PP+ batts.

6.06	Removed capacity drop prediction data from PP+ V2 format.

6.05	Added support for gas gauge reg dump data for V2 gas gauge.

6.04	Changed cap rate limiter to use 32 bit values to prevent issues on 32 bit OS.

6.03	Added check for same batttery on resume to PP+ V2 battery support.

6.02	Changed Eliminator byte to flags byte
		Fixed issue with Qmax Days reporting

6.01	Fixed math on Zebra total charge value
		Fixed cycle count value
		Added fast cycle time if VT health writes are waiting

6.00	Initial support for new PP+ gas gauge

5.05	Fixed a bug in the previous change that checked the detect state value right after
		having changed it. Added a message to show we had a bad battery during last suspend
		on a resume.

5.04	Added a check for suspending while a battery detection is in progress, will flush
		any current battery data and restart detection on resume. This prevents an issue
		where suspending during a paritally finished battery detection prevents a new
		battery from being correctly detected as well as blocking OS notifications.

5.03	Fixed a bug in VT battery support that was setting the slow charge current max
		vlaue to 0.

5.02	Fixed not returing GB_INVALID for the battery type with new error handling

5.01	Fixed comments and error message on VT batt charger
		control checksum checking.

5.00	Started on enhanced error/status reporting
		Removed support for old style Temp chip only TPB

4.10	Added code to handle QC fuel gauge returning 0V on invalid battery found.

4.09	Added code to enable charging when a low voltage battery is
		found during battery detection.

4.08	Added support for minimum battery slow charge current.

4.07	Added VT rev 2 format as a valid format

4.06	Added "check for same batt on resume" to value tier batts

4.05	Modified value tier part number to match format of PP+ part number/rev

4.04	Fix bug that prevented charge accumulation because charging was not being detected.
		Added in battery decomissioned flag updates for value tier batts.
		Changed value tier total charge accumulation to set both "Zebra" and "all device" values.

4.03	Added support for returning battery eliminator flag, thermistor
		coefficients, UVLO, OVLO, and cutoff voltage.

4.02	Fixed missing copying of arcitecture specific data blob from VT Battery

4.01	Added charge accumulation and cycle counting for value tier batteries

4.00	Added inital support for value tier batteries

3.31	Added code to return 0% capacity level during battery detection if the
		battery voltage is too low to talk to the gas gauge.
		Lowered the low battery threshold from 2.9V to 2.75V
		Increased wait time for battery voltage to come up to 20 min.

3.30	Fixed an issue where battery draining or device suspending
		while in calibration wait state caused the charger to
		be permantly disabled

3.29	Added api call to reset the gas gauge

3.28	Added retries on GG and EEPROM/Auth accesses during battery detection
		to help work around pogo-pin issues during viration testing.
		Incresed inital retires when looking for batts.
		Also added retries on incorrect values returned by GG during battery detection.

3.27	Fixed a bug in the loop that flushed JEITA data to 0 for TPB.

3.26	Added a fix for capacity from GG out of range due to I2C errors
		Used last capacity instead, added a comm error on bad capacity.

3.25	Added support for ship mode data in battery

3.24	Added check for unsealed/hibernated state and perform correction

3.23	Added addtional checks to prevent charge accumulation error

3.22	Fix bug with charge accumulation happening during battery detection

3.21	Simplified the include file paths below by changing the makefile to
		add the correct paths to the include search path

3.20	Added capacity rate limiting for falling capacity

3.19	Added support for displaying the GG regs from the battery driver
		Added support for Raven devices

3.18	Added capacity rate limiting
		Added support for overriding the GG SOC

3.17	Added hibernate battery code

3.16	Increased timeout to 6 seconds when reading the whole auth chip data

3.15	Extended timeout when reading the whole auth chip data
		Extended the EA wait timeout to account for longer delays
		when i2C debug log data is enabled.

3.14	Added code to show key version in version.

3.13	Decreased time to detect/read battery on swap [BSPA-75780]
		Increased loop time when reading auth chip data to prevent time
		wasted check for transaction done.
		Changed BATT_DET_START case to jump right to check voltage state.
		Moved the check for g_bReadMPA3Regs being true to the first one.
		Added support for dual I2C transactions to speed gas gauge access.
		Added set of the FULL_SLEEP bit. [EE-3507]

3.12	Added support for doing auth chip data reads in one shot to
		improve performance. NOTE: This depends on batts with an auth
		chip NOT needing clock mux control.

3.11	Added support for reading the GG volt/curr/temp/SOC registers.

3.10	Added SDM660 and Beast big board support

3.9		Fixed a bug in the smart battery temp conversion

3.8		Added code to update cycle count on new smart battery insertion

3.7 	Fix for old MC32 batts that used the upper byte of the serial number
		field for the pack maker ID.

3.6		Simplified the temp conversion
		Fixed the charge accumulation
		Added support for data storage in the auth chip

3.5 	Enable Accumulation charge for smart battery support

3.4		Fixed a bug in MPA2 smart battery temperature reading and converion.
		Added changes to use 2nd byte of temperature data and coversion of 2's complement data.

3.3		Fixed a bug in MPA2 smart battery detection where a
		retry counter kept getting reset, preventing a gifted
		battery from beig detected.

3.2		Added printing battery type to ShowbatteryData().
		Added padding to smart battery dat structure to allow
		reading all 256 bytes of EEPROM into structure. This
		fixed a bug caused by EEPROM data overruning the structure.
		Added support for date of first use.

3.1		Added support for the GetDate function returning an error.
		Changed SupportedHealthType, Supported1725Type, and
		SB_SupportedType to all caps to show they are constants.
		Added "SB" to smart battery messages for clarity.
		Refactored the SB validation code to eliminate duplication
		of setting stuff to defaults, and to reduce code size/complexity.
		Changed smart battery part number decodeing so the "New" part
		number gets the correctly decoded smart battery part number.

3.0		Added back in smart battery support.
		Cleaned up duplicated varible defs in pwm.c and pwm.h

2.48	Added retries to gifted battery EEPROM reads
		Added defines for new battery

2.47	Changed rated capacity to be the higer of design capacity and CC_Threshold

2.46	Added logging for updating battery thresholds

2.45	Fix a bug where the min discharge temp was not being copied from the
		battery data structure to the shared structure.

2.44	Added code to detect "wacky" temp shifts from GG and reset it if needed.

2.43	Added code to support just checking for the same battery on resume.
		Added code to gas gauge register reads in one large chunk for non-muxed systems.

2.42	Added a message when the gas gauge gets reset.

2.41	Added code to reset gas gauge if it's "stuck" in hibernate.

2.40	Added code to support setting battery capacity based on what error/type of battery.

2.39	Added code to check for a battery being swapped before updating the dynamic blocks.

2.38	Reverted the change from version 2.37

2.37	Bypassed the checking of the manufacturer IDs in the dynamic blocks to address an issue
		of the data being written with the wrong ID value.

2.36	Corrected bad checksum message for dynamic block 3 & 4 to not show block 1 error.

2.35	Updated the handling of battery comm errors. First call charging error
		if needed, then invalidate battery.
		Added call to BatteryFound() since it was removed from InvalidateBattery().

2.34	Fixed a bug in the handling of the extended charging temp data

2.33	Fixed a bug where the default min on temp was lower then the min charge temp
		Added support for extended charging temp data

2.32	Added support for GB_UNAUTHENTIC and GB_INVALID battery types

2.31	Changed battery type detection to check for GG first.
		Streamlined battery detection to improve performance.

2.30	Changed CurTemp to an int16_t to avoid sign extension issues in battery driver.
		Changed battery detection to eliminate issue with legacy Pollux batts.

2.29	Added Falcon and IronMan device types
		Added workaround for compiler generating optimization error on a loop in pwm_batt.c

2.28	Speed up battery detection by reducing fast loop times from 1S to 50ms

2.27	Fixed a bug in the output of raw gas gauge data.

2.26	Added support for sending version string to driver.

2.25	Added support for retaining current battery capacity on suspend to use for resume.

2.24	Sped up finding an MPA3 batt on a resume. Had been checking for MPA2 batt first.

2.23	Added support for Third Party Batteries. (TPB)
		Put gifted battery detection first to improve battery detect times.
		Eliminated duplicate values in BattManPointers for charge up voltage.
		Cleaned up an issue that was causing battery detection to sometimes be
		restarted, making for longer battery detection times.

2.22	Added support for passing slow charge current up to kernel.
		Added additional data fields to the battery data printout.

2.21	Added support for charge restarting when battery gets below threshold.

2.20	Added support for new battery keys on Frenzy EV units, while keeping old keys for freeport

2.19	Cleaned up some battery level handling.

2.18	Broke up the access to the gas gauge registers into 3 seperate accesses to
		eliminate a possible issue with voltage droop in the battery pack EEPROM circuit.

2.17	Modified to support building for both Sunrise and Freeport devices.
		Added support for transfering data for QMAX Days ,valid QMAX cycles, and flags.

2.16	Added suspend/resume code to invalidate/rescan battery.
		Removed code to delay reporting MPA3 battery capacity.
		Added code to set charging timeouts and voltage levels into shared struct.

2.15	Added support for detecting too many I2C com errors and calling ErrorCharger() function.
		Added code to clear I2C error counter on good transactions.
		Added code to declare inability to start an I2C transaction a com error.
		Started adding suspend/resume stuff.

2.14	Added support for cycle counts in the shared data structure.

2.13	Added support for updating the percent and cycle count thresholds.

2.12	Fixed battery detect code to correctly handle bad fixed blocks
		Made all functions and global varibles static to eliminate referances in the
		symbol/relocation tables. Added "strip" command to the make file to remove
		debug data as well.
		Changed build to be one big file, also to reduce symbol/relocation table data
		Added #ifndef's to all include files to prevent mutiple includes

2.11	Added support for gifted battery calibration
		Added "done charging" detection
		Added detection of charger shutdown
		Changed debug stuff to use the same flags as OS driver

2.10	Added support for reading battery voltage and current
		Fixed bug where some error returns in battery detection didn't tell OS it had failed

2.9	Moved keys and fixed block defs to a seperate file that won't get archived

2.8 Added support for dwSecSinceFirstUse
	Added support for all the battery data reporting sysfs entries.

2.7 Added support for a re-init on battery removal by adding BattReinit()

2.6	Fixed bug where OS check batt routine was not call for "other" battery

2.5	Added encryption support and MPA3 EEPROM updates

2.0	Added I2C support and initial battery validation

1.0	Inital "dummy" version
*/

#include <linux/string.h>
#include <linux/types.h>

#include "pwm.h"
#include "pwm_batt.h"
#include "pwm_chrg.h"
#include "aes.h"
#include "keys.h"
#include "BattMan_main.h"

#define BM_VERSION "7.07"
#define BM_VERSION_LENGTH 10

struct BattManPointers *Pointers;
char BM_Version[BM_VERSION_LENGTH];

// Local funtionc prototypes
void SetPointers(void);
uint32_t BattReinit(void);

// Global battery data storage
NEW_GIFTED_BATT_DATA_t g_GiftedV2Data;	// Data for V2 PP+ batts
VALUE_TIER_BATT_DATA_t g_ValueTierData;	// Data for value tier battery
SMART_BATT_DATA_t g_SmartBattData;		// Data for MPA2 smart battery
GIFTED_BATT_DATA_t g_GiftedBattData;		// Gifted battery data
SHIP_MODE_DATA_t g_ShipModeDefaults;		// Default ship mode data

// Shared data
int g_BattType;							// KLM internal battery type
int g_OldBattType;						// KLM last good internal battery type
BATTERY_TRANSACTION g_BattTrans;			// Battery transaction data
unsigned long dwBDStopTime;				// Battery detection stop time
uint32_t	g_dwBattDetectState;			// Battery detect state machine state
uint32_t	g_dwBattDetectRestartState;		// State to restart detect state machine in
uint32_t g_dwBattDetectAfterResetState;	// State to go to after a GG reset
u32 g_dwAggregateCharge = 10000;		// Total accumulated charge
uint16_t g_LastErrorCode;				// Error code for last battery error

// Keys
uint8_t *Key1, *Key2;

//wrappers
int __nocfi local_print(const char *format, ...)
{  // Generic printf
	int ret;
	va_list arglist;
   	va_start( arglist, format );
   	ret = Pointers->print( format, arglist );
   	va_end( arglist );
	return ret;
}  // Generic printf
int __nocfi local_sprint(char *dest, size_t len, const char *format, ...)
{  // Generic snprintf
	int ret;
	va_list arglist;
   	va_start( arglist, format );
   	ret = Pointers->sprint( dest, len, format, arglist );
   	va_end( arglist );
	return ret;
}  // Generic snprintf

// Battery charger functions
void __nocfi local_EnableCharger(int Enb)
{
	Pointers->EnableCharger(Enb);
}
void __nocfi local_StopCharger()
{
	Pointers->StopCharger();
}
void __nocfi local_ErrorCharger()
{
	Pointers->ErrorCharger();
}
void __nocfi local_StartChg()
{
	Pointers->StartChg();
}
void __nocfi local_StopChg()
{
	Pointers->StopChg();
}

// Battery driver functions
void __nocfi local_BatteryFound(u32 NewBatt)
{
	Pointers->BatteryFound(NewBatt);
}
void __nocfi local_InvalidBattery(u32 Invalid)
{
	Pointers->InvalidBattery(Invalid);
}
void __nocfi local_NewData(u32 DataChanged)
{
	Pointers->NewData(DataChanged);
}
void __nocfi local_InHibernate(uint32_t Error)
{
	Pointers->InHibernate(Error);
}

// Battery voltage/current stuff
int __nocfi local_GetBatteryVoltage()
{
	return Pointers->GetBatteryVoltage();
}
int __nocfi local_GetBatteryCurrent()
{
	return Pointers->GetBatteryCurrent();
}
int __nocfi local_GetBatteryTemp()
{
	return Pointers->GetBatteryTemp();
}
int __nocfi local_GetBatteryCapacity()
{
	return Pointers->GetBatteryCapacity();
}

// I2C routines
int __nocfi local_EA_BattTransaction(LP_BATTERY_TRANSACTION trans)
{
	return Pointers->EA_BattTransaction(trans);
}
int __nocfi local_EA_BattTransresult(LP_BATTERY_TRANSACTION trans)
{
	return Pointers->EA_BattTransresult(trans);
}

// Time stuff
long __nocfi local_GetStopTime(unsigned long Delay)
{
	return Pointers->GetStopTime(Delay);
}
u64 __nocfi local_GetCurrTime()
{
	return Pointers->GetCurrTime();
}
u64 __nocfi local_GetTimeSince(u64 StartTime)
{
	return Pointers->GetTimeSince(StartTime);
}
int __nocfi local_PastTime(unsigned long StopTime)
{
	return Pointers->PastTime(StopTime);
}
int __nocfi local_GetDate(uint16_t *Month, uint16_t *Day, uint16_t *Year)
{
	return Pointers->GetDate(Month, Day, Year);
}

// Funtion to re-init battery stuff
uint32_t BattReinit(void)
{
	uint32_t dwLoop;  // New delay time for PM loop

	RETAILMSG(ZONE_FUNCTION,("BattMan: BattReinit\n"));

	PM_Reinit();  // Restart PM stuff
	ChargerInit();  // Startup charger stuff
	dwLoop = BattInit(); // Startup batt detection stuff

	return (dwLoop);  // Return new loop time
}

// Funtion to initialize pointers
void SetPointers(void)
{
	// Battery KLM data

	// Battery KLM functions
	Pointers->Hello = Hello;
	Pointers->BattInit = BattReinit;
	Pointers->BattDetectStart = BattDetectStart;
	Pointers->PM_Tick = PM_Tick;
	Pointers->Charger_Tick = DoChargerStuff;
	Pointers->NewLevel = FindNewLevel;
	Pointers->UpdatePercentThreshold = UpdatePercent;
	Pointers->UpdateCycleThreshold = UpdateCycle;
	Pointers->PM_Suspend = PM_Suspend;
	Pointers->PM_Resume = PM_Resume;
	Pointers->HibernateBatt = HibernateBatt;
	Pointers->ResetRateLimit = ResetRateLimit;
	Pointers->BM_Ver = BM_Version;
	Pointers->ARpnt = &g_GiftedBattData.AR;
	Pointers->ResetGG = BattDetectReset;
}

int BattMan_loadStruct(struct BattManPointers* point)
{
	// Set struct pointers
	Pointers = (struct BattManPointers *)point;

	//create the BattMan verison
	local_sprint(BM_Version, BM_VERSION_LENGTH, "%sK%02u", BM_VERSION, Pointers->dwTerminalType);

	// Set from passed value for terminal type
	Key1 = (uint8_t *)AllKeys1[Pointers->dwTerminalType];
	Key2 = (uint8_t *)AllKeys2[Pointers->dwTerminalType];

	SetPointers();
	g_ShipModeDefaults.HighVoltage = Pointers->dwShipModeVoltHi;
	g_ShipModeDefaults.LowVoltage = Pointers->dwShipModeVoltLow;
	g_ShipModeDefaults.HighCapacity = Pointers->dwShipModeCapHi;
	g_ShipModeDefaults.LowCapacity = Pointers->dwShipModeCapLow;
	local_print("BattMan Version: %s\n",BM_Version);

	PM_Init();  // Startup PM stuff
	ChargerInit();  // Startup charger stuff
	BattInit(); // Startup batt detection stuff

	return 1;
}

#include "aes.c"
#include "pwm_batt.c"
#include "pwm_chrg.c"
#include "pwm.c"

#if __has_include("keys.c")
	#include "keys.c"
#else
	#include "default_keys.c"
#endif
