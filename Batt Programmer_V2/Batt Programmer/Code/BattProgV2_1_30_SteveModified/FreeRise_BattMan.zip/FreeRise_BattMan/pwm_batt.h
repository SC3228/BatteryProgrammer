//--------------------------------------------------------------------
// FILENAME:	pwm_batt.h
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	Virtual Power Micro Battery stuff Include File
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

#ifndef PWRM_BATT_H_
#define PWRM_BATT_H_

//-----------------------------------------------------------------------------
// Function prototypes
//
void Hello(void);
uint32_t BattDetect(void);
uint32_t BattInit(void);
uint32_t BattDetectStart(void);
void BattDetectResume(void);
void BattDetectReset(void);
void GasGauge(uint32_t dwReset);
void UpdatePercent(uint32_t NewPercent);
void UpdateCycle(uint32_t NewCycle);
uint8_t BlockReadCheck(int cmd, uint8_t buf[]);
void CancelAccess(void);
void VT_CheckHealth(void);
void Update_TSFU(void);

// Internal battery type defs
#define BATT_NONE	0  // No Valid battery
#define BATT_SMART	1  // MPA2 Smart battery
#define BATT_M200	2  // Original TI M200 GG PP+ battery
#define BATT_VT		3  // Value tier battery
#define BATT_Z561	4  // New TI BQ27Z561 GG PP+ V2 battery

// Debug defs
#define RETAILMSG(cond,printf_exp) if(cond) local_print printf_exp
#define ZONE_ERROR 1
#define SHOW_MF_ID		(Pointers->DebugMode & 0x10000)	// Show battery manufacturer IDs
#define SHOW_DET_STATES	(Pointers->DebugMode & 0x08000)	// Show battery detect states
#define DUMP_GG_DATA	(Pointers->DebugMode & 0x04000)	// Dump gas gauge data flag
#define SHOW_CAL		(Pointers->DebugMode & 0x02000)	// Show batt calibration stuff
#define SHOW_CHG_STATES	(Pointers->DebugMode & 0x01000)	// Show charger states
#define FORCE_CAL		(Pointers->DebugMode & 0x00800)	// Force an gifted batt calibration
#define SHOW_COM_STATES	(Pointers->DebugMode & 0x00400)	// Show battery comm stuff
#define FORCE_INVALID	(Pointers->DebugMode & 0x00002)	// Make all batts invalid

// The following are shared with GiftedBattery.c
#define ZONE_FUNCTION	(Pointers->DebugMode & 0x0080)	// Show functions
#define SHOW_BATT_DATA	(Pointers->DebugMode & 0x0010)	// Show battery data

#define EA_WAIT_TIME	6000	// ms to wait for I2C responce
#define GAS_GAUGE_INTERVAL 5000	// Battery gas gauge update time in ms
#define VOLT_WAIT_TIME	(20 * 60 * 1000)  // Time to wait for voltage to come up, 20min in ms.
#define TSFU_WAIT_TIME	(15 * 60 * 1000)  // Time to wait for time since first use update, 15min in ms.

// Battery chip defs
#define MPA2EEPROM	0xA0	// MPA2 EEPROM address
#define MPA2TEMP	0x90	// MPA2 Temp chip address
#define BM_ADD		0x42	// Battery micro address
#define MPA3EEPROM	0xA4	// MPA3 EEPROM address
#define MPA3TEMP	0x94	// MPA3 Temp chip address
#define MPA3GG		0xAA	// MPA3 gas gauge address
#define AUTH_CHIP	0xD0	// Auth chip address
#define VT_EEPROM	0xA0	// VT Large EEPROM address

// MPA3 eeprom address
extern uint16_t MPA3_eeprom_addr;

// Other battery defines
#define NO_BATT_TEMP 0		// No battery present temp
#define MPA3_BATT_PN_LEN 22
#define MPA2_BATT_PN_LEN 22
#define MIN_BATT_VOLTS 2750   // Minimum battery voltage in mv to be able to talk to battery
#define CAP_UNKNOWN 50  // Inital starting capacity

// Gas Gauge commands/registers (MPA3 Batteries)
#define CNTL_CMD	0x00
#define AR_CMD		0x02	// Command to read/write the at rate current
#define FLAGS_CMD	0x0A	// Command to read the current gas gauge flags
#define SOC_CMD		0x2A	// Command to read the state of charge %
#define SOH_CMD		0x28	// Command to read the state of health %
#define LCCA_CMD	0x34	// Command to read the charge current accumulator
#define CHGCC_CMD	0x36	// Command to read the charge cycle count
#define DCAP_CMD	0x72	// Design capacity registers
#define MFGID_CMD	0x6a	// Manuf ID
#define DFBLK_CMD	0x3f	// DataFlashBlock()
#define A_DF_CMD	0x40	// Authenticate()/BlockData()

// New gas gauge commands/registers
#define ALT_MANF_ACC			0x3e	// Alt manufaturer access, new gas gauge
#define MAC_DATA_CSUM			0x60	// Checksum for Alt manufaturer access/mac data bytes, new gas gauge
#define NGG_TEMP				0x06	// New gauge temp reg
#define NGG_VOLTAGE				0x08	// New gauge voltage reg
#define NGG_BATTERYSTATUS		0x0a	// New gauge battery status reg
#define NGG_CURRENT				0x0c	// New gauge current reg
#define NGG_RM					0x10	// New gauge remaining capacity
#define NGG_FCC					0x12	// New gauge full charge capacity
#define NGG_INT_TEMP			0x28	// New gauge internal temp
#define NGG_CYCLES				0x2a	// New gauge cycle count
#define NGG_SOH					0x2e	// New gauge state of health
#define NGG_RSOC				0x2c	// New gauge state of charge
#define NGG_QMAX_CYCLES			0x3a	// New gauge QMAX cycles
#define NGG_DCAP				0x3C	// New gauge design capacity
#define NGG_MANF_NAME			0x4C	// New gauge manufacture name code
#define NGG_MANF_DATE			0x4D	// New gauge date made
#define NGG_SERIAL_NUM			0x4E	// New gauge serial number
#define NGG_GAUGING_STATUS		0x56	// New gauge gauging status
#define NGG_LIFE_TIME_CAPS		0x65	// New gauge Start of time in cap ranges for temp range commands
#define NGG_MANF_BLKA			0x70	// New gauge Manf info block A command
#define NGG_MANF_BLKB			0x7a	// New gauge Manf info block B command
#define NGG_MANF_BLKC			0x7b	// New gauge Manf info block AC command
#define NGG_QMAX_DAY			0x17	// New gauge Qmax day command
#define NGG_FW_RT				0x62	// New gauge Firmware runtime command
#define NGG_ITSTATUS2			0x74	// New gas gauge ITStaus2
#define NGG_ITSTATUS3			0x75	// New gas gauge ITStaus3

// Control() sub commands (GG Batteries)
#define GG_READ_CONTROL_STATUS	0x0000	// Read CONTROL_STATUS flags
#define GG_DEVICE_TYPE			0x0001	// Get device type
#define GG_FW_VERSION			0x0002	// Get firmware version
#define GG_ENABLE_RMFCC			0x000c	// Enables automatic RM update based on FCC
#define GG_DISABLE_IBAW			0x0010	// Disables access to manf block A
#define GG_SET_FULLSLEEP		0x0012	// Forces FULL_SLEEP to 1
#define GG_SET_HIBERNATE		0x0013	// Forces CONTROL_STATUS[HIBERNATE] to 1
#define GG_CLEAR_HIBERNATE		0x0014	// Forces CONTROL_STATUS[HIBERNATE] to 0
#define GG_READ_QMAX_DAY		0x0017	// Get QMAX_DAY value
#define GG_SEAL_CHIP			0x0020	// Seal the gas gauge
#define GG_RESET_CHIP			0x0041	// Reset the gas gauge
#define NGG_SEAL_CHIP			0x0030	// Puts the V2 gas gauge into sealed mode

#define NGG_OCVFR_BIT			0x00100000 // OCVFR bit in GaugingStatus
#define NGG_QMAXDODOK_BIT		0x00200000 // QMAXDODOK bit in GaugingStatus
#define NGG_OCVPRED_BIT			0x00004000 // OCVPRED bit in GaugingStatus

// Unseal keys
#define UNSEAL_KEY1	0xe1b2
#define UNSEAL_KEY2	0x3e84

// Battery gas gauge defs (MPA3 Batteries)
#define MPA3_GG_FW_VERSION	0x0100	// Supported firmware version
#define NGG_DEVICE_TYPE_OLD	0xffa5  // Device type reported by new gauge using old register

// Gas gauge status register bit defines
#define STATUS_LOW_HIBERNATE_BIT	0x40	// Hibernate bit in lower status byte
#define STATUS_HIGH_FAS_BIT			0x40	// Full access sealed bit
#define STATUS_HIGH_SS_BIT			0x20	// Sealed bit

// Flag register defs (MPA3 Batteries)
#define FLAG_FC		0x0200	// Full-charged condition reached. True when set.
#define OCV_TAKEN	0x0040	// Open-Circuit-Voltage taken. True when set.
#define OCV_PRED	0x0020	// Open-Circuit-Voltage predicted. True when set.

// Flag defs, new gas gauge
#define NGG_BATTERYSTATUS_FC		0x0020  // Full charged flag, true when set

// Block select defs
#define AUTH_BLK	0	// Auth block
#define MAN_BLK_A	1	// Manuf block A
#define MAN_BLK_B	2	// Manuf block B
#define MAN_BLK_C	3	// Manuf block C

// New gauge block read defines
#define BLK_READ_SIZE	36	// Number of bytes in a block read
#define BLK_READ_CSUM	34	// Offset to block checksum
#define BLK_READ_LEN	35	// Offset to block length

// Smart battery data
#define	RTs_SIZE	11	// Size of RTs data in RT_DATA_ts
#define	VOCs_SIZE	11	// Size of Vocs data in VOC_DATA_ts

// Battery detect state machine defines
#define BATT_DET_IDLE			0	// Battery detection state machine is idle
#define BATT_DET_START			1	// Start looking for a valid battery
//  EA no longer supported
//#define BATT_DET_WAIT_EA		2	// Waitng for EA to see the battery
#define BATT_DET_GET_SDATA1		3	// Get smart battery data, step one
#define BATT_DET_GET_SDATA2		4	// Get smart battery data, step two
#define BATT_DET_CHECK_VOLT		8	// Check for high enough voltage to talk to Gas Gauge chip
#define BATT_DET_WAIT_VOLT		9	// Wait for battery voltage to be high enough
#define BATT_DET_AUTH2			11	// Authenticate gifted battery step 2
#define BATT_DET_AUTH3			12	// Authenticate gifted battery step 3
#define BATT_DET_AUTH4			13	// Authenticate gifted battery step 4
#define BATT_DET_AUTH5			14	// Authenticate gifted battery step 5
#define BATT_DET_AUTH6			15	// Authenticate gifted battery step 6
#define BATT_DET_AUTH7			16	// Authenticate gifted battery step 7
#define BATT_DET_SET_CTRL2		22	// Set GG controls step1
#define BATT_DET_GET_GDATA1		31	// Get gifted battery data, step 1
#define BATT_DET_GET_GDATA2		32	// Get gifted battery data, step 2
#define BATT_DET_GET_GDATA3		33	// Get gifted battery data, step 3
#define BATT_DET_GET_GDATA5		35	// Get gifted battery data, step 5
#define BATT_DET_GET_GDATA7		37	// Get gifted battery data, step 7
#define BATT_DET_GET_GDATA9		39	// Get gifted battery data, step 9
#define BATT_DET_GET_GDATA10	40	// Get gifted battery data, step 10
#define BATT_DET_GVAL			50	// Validate gifted battery data
#define BATT_DET_TOSS			60	// Toss next I2C
#define BATT_DET_RESTART		61	// Restart detection after suspend
#define BATT_DET_GET_ID1		62	// Get the battery ID step1
#define BATT_DET_GET_ID2		63	// Get the battery ID step2
#define BATT_DET_MPA2_ID		64	// Start getting MPA2 battery ID
#define BATT_DET_MPA3_ID		65	// Start getting MPA3 battery ID
#define BATT_DET_MPA2_FIND		66	// Start looking for MPA2 battery
#define BATT_DET_MPA3_FIND		67	// Start looking for MPA3 battery
// TPB no longer supported
//#define BATT_DET_TPB_FIND		68	// Start looking for Third Party Battery
//#define BATT_DET_GOT_TPB		69	// Found a Third Party Battery
#define BATT_DET_CHECK_STATUS2	71	// Check status register
#define BATT_DET_RESET1			72	// Reset pack step 1
#define BATT_DET_RESET2			73  // Reset pack step 2
#define BATT_DET_RESET3			74  // Reset pack step 3
#define BATT_DET_RESET4			75  // Reset pack step 4
#define BATT_DET_RESET5			76  // Reset pack step 5
#define BATT_DET_RESET6			77  // Reset pack step 6
#define BATT_DET_GET_GDATA3B	78	// Get gifted battery data, step 3 version B
#define BATT_DET_VT1			79	// Get value tier battery auth data
#define BATT_DET_VT2			80	// Get value tier EEPROM data/Check value tier battery data
#define BATT_DET_VTCHK			81	// Check for same VT battery as before
#define BATT_DET_NGG1			82	// Check device type for PP+ V2 battery
#define BATT_DET_NGG2			83	// Get firmware version for PP+ V2 battery
#define BATT_DET_NGG3			84	// Get manuf name
#define BATT_DET_NGG4			85	// Get date made
#define BATT_DET_NGG5			86	// Get serial number
#define BATT_DET_NGG6			87	// Get manf block A
#define BATT_DET_NGG7			88	// Get manf block B
#define BATT_DET_NGG8			89	// Get manf block C
#define BATT_DET_NGG9			90	// Do register read
#define BATT_DET_NGG10			91	// Get lifetime data
#define BATT_DET_NGG11			92	// Check all data
#define NGG_CHECK_BATT1			93  // Step one of checking for same PP+ V2 batt
#define NGG_CHECK_BATT2			94  // Step two of checking for same PP+ V2 batt
#define NGG_CHECK_BATT3			95  // Step three of checking for same PP+ V2 batt


// Error code defines
#define BATT_ERR_NONE		0	// No error

#define BATTERY_CHEMISTRY_LION  0x04 // Battery type define

#define MIN_SLOW_FAST_CURRENT	350	// Minimum setting for slow charge over current level

#define PWM_TEMP_HYS_SIZE           30  // Maximum sample size of the temperature hystersis buffer

#define PWM_TEMP_RETRY 5
#define PWM_TEMP_RETRY_DELAY 200 // in milliseconds
#define PWM_TEMP_DEFAULT 30 // Celcius

#define PWM_TEMP_DELTA 5
#define PWM_TEMP_DELTA_RETRY 5
#define PWM_TEMP_DELTA_RETRY_DELAY 200 // milliseconds

/* MPA2 Battery data defines */
#define	SB_DATA_ADD 0			// Address of battery data area in EEPROM
#define	SB_DATA_SIZE 156		// Size of battery data area in EEPROM

#define	SB_LIFE_ADD1	160		// Address of battery life data area 1
#define	SB_LIFE_ADD2	168		// Address of battery life data area 2
#define	SB_LIFE_SIZE	 5		// Size of battery life data

#define	SB_SUPPORTED_TYPE 4		// Currently supported battery data type

#define	SB_1725_DATA_ADD 208	// Address of 1725 data record in battery
#define	SB_1725_DATA_SIZE 8		// Size of 1725 data record
#define	SUPPORTED_1725_TYPE 1		// Currently supported 1725 data record type

#define	SB_HEALTH_DATA_ADD 216	// Address of health data record in battery
#define	SB_HEALTH_DATA_SIZE 6	// Size of health data record
#define	SUPPORTED_HEALTH_TYPE 1	// Currently supported health data record type
#define BAD_LIFE_DATA 0xffffffff// Bad TC data value

/* MPA3 Battery defines */
#define GB_DYN_BLK_SIZE 16			// Size of MPA3 dynamic blocks
#define GB_LOCK_BLK_ADD 0x30		// Address of lock block
#define GB_DYN_BLK1_ADD 0x40		// Address of dynamic block 1
#define GB_DYN_BLK2_ADD 0x50		// Address of dynamic block 2
#define GB_DYN_BLK3_ADD 0x60		// Address of dynamic block 3
#define GB_DYN_BLK4_ADD 0x70		// Address of dynamic block 4
#define GB_STATIC_DATA_SIZE 0x2f	// Size of static area in MPA3 EEPROM
#define	GB_SupportedType 1			// Currently supported battery data type
#define GB_MANF_BLK_SIZE 32			// Size of Manf blocks
#define GB_MANF_SupportedType 1		// Currently supported manf block data type
#define GB_BQ_ALLOC 0xcf			// Pattern for currently allocated blocks in the GG flash. Unused blocks are '1'
#define GB_CMD_PARTIAL_READ_SIZE 20	// Number of bytes to read at one time to fill
									// the GG registers in the MPA3 battery structure
#define GB_CMD_FULL_READ_SIZE 60	// Number of bytes to read all the gas gauge registers

/* Value tier battery defines */
#define	VT_HD_ADD1	432 	// Address of health data area 1
#define	VT_HD_ADD2	436 	// Address of health data area 2
#define	VT_AC_ADD1	440 	// Address of acc charge data area 1
#define	VT_AC_ADD2	444 	// Address of acc charge data area 2
#define VT_REC_SIZE	4		// Size of VT data records
#define VT_ASD1_SIZE 226	// Size of first architecture specific data
#define VT_ASD2_SIZE 184	// Size of second architecture specific data

#pragma pack(1)  // Byte align structure to match EEPROMM data

// MPA2 battery data
/*---------------------------------------------------------------------
 *
 *  RT Table structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagRT_DATA
{
	u8	Temp;		// Battery temp in deg C
	u16	Slope;		// Slope of this segment
	u16	Resistance;	// Battery resisteance (in ohms * 1.024) at start of region
} RT_DATA_t;
/*---------------------------------------------------------------------
 *
 *  VOC Table structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagVOC_DATA
{
	u16	Voltage;	// Battery V open circuit in mv
	u16	Slope;		// Slope of this segment
	u8	Capacity;	// Battery capacity at start of region
} VOC_DATA_t;

/*---------------------------------------------------------------------
 *
 *  MPA2 Battery data structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagSMART_BATT_DATA
{
	// Battery data
	char	BattDataCsum;		// Checksum of battery data
	char	BattDataType;		// Smart battery data type
	u32	BattPartNum;		// Smart battery part number
	u32	BattID;				// Smart battery ID number
	char	BattDate[3];		// Smart battery date made
	u16	BattRated;			// Rated battery capacity in maHr's
	u8	BattFaireLevel;		// Battery capacity levels
	u8	BattUnfaireLevel;
	u8	BattLowLevel;
	u16	VocFudge;			// Slope of Voc below 0 fudge
	char	VocFudgeTempStart;	// Temperature below which Voc correction is made
	char	VocFudgeTempStop;	// Temperature below which no additional Voc correction is made

	// Gas Gauge Data
	RT_DATA_t	RTs[RTs_SIZE];		// Battery resistance by temp table
	VOC_DATA_t	VOCs[VOCs_SIZE];	// Battery Voc table

	// Charge control data
	u8	SlowChrgTO;			// Slow charge timeout in 10 min intervals
	u8	FastChrgTO;			// Fast charge timeout in 10 min intervals
	u16	SlowFastThreshold;	// Slow to fast charge voltage threshold in mv
	u16	RechargeVoltage;	// Recharge a charged battery voltage in mv
	u16	AbsentBattVoltage;	// Absent battery voltage in mv
	u16	AbnormalCurrent;	// Abnormal battery current in ma
	u16	SlowChrgHighFC;		// Slow charge high fault current in ma
	u16	SlowChrgLowFC;		// Slow charge low fault current in ma
	u16	NearlyDoneCurrent;	// Nearly done current in ma
	u16	DoneCurrent;		// Done current in ma
	int8_t	MinChrgTemp;		// Minimum charge temperature in deg C
	int8_t	ColdOnTemp;			// Turn on charger temp for cold battery
	int8_t	HotOnTemp;			// Turn on charger temp for hot battery
	int8_t	MaxChrgTemp;		// Maximum charge temperature in deg C
	int8_t	NoBattTemp;			// No battery temperature
	char	ChangeWaitCnt;		// The temperature delta above/below from 'too low' or 'too high' to recover
	char	Unused1[4];

	// Battery life data1
	u32	BattLife1;			// Battery life time total charge
	char	BattLifeCsum1;		// Checksum of battery life data
	char	Unused2[3];

	// Battery life data2
	u32	BattLife2;			// Battery life time total charge
	char	BattLifeCsum2;		// Checksum of battery life data
	char	Unused3[3];

	// Aging data (Not used)
	char	AgingData[28];
	char	Unused4[4];

	// 1725 data
	char	_1725_CSum;			// Check sum for the 1725 data record
	char	_1725_DataType;		// Data type for the 1725 data record
	char	BattMinDTemp;		// Battery min discharge temp
	char	BattMaxDTemp;		// Battery max discharge temp
	u16	BattMaxCVolt;		// Battery max charging voltage
	u16	BattFastCurr;		// Battery fast charge current

	// Health data
	char	Health_CSum;		// Check sum for the 1725 data record
	char	Health_DataType;	// Data type for the 1725 data record
	char	DateFirstUse[3];	// Smart battery date made
	u8	BattHealth;			// Battery health indicator
	char 	pad[34];		// Pad to get to 256 bytes
} SMART_BATT_DATA_t;

/*---------------------------------------------------------------------
 *
 *  MPA3 Gifted Battery data structures
 *
 *--------------------------------------------------------------------*/

/*---------------------------------------------------------------------
 *
 *  Dynamic block structure 1
 *
 *--------------------------------------------------------------------*/
typedef struct tagDYNAMIC_BLK1_DATA
{
	u8	MaxRecalPd_Days;		// Maximum number of days after the last recalibration that a
									// new recalibration should occur.  A value of 0x00 inhibits
									// duration-demanded recalibration.
	u8	HealthPct;				// StateOfHealth( ) value below which the battery is declared unhealthy.
	u32	BatteryLifeData;		// Total maHr put into the battery
	u8	CopiedManufactureID[8];	// This value shall be set initially to all ones. Upon seeing a value of
									// all ones, terminal and charger code shall replace this value with that
									// stored in the block located at hex address 0x30. Thereafter, code
									// shall check upon insertion of the battery pack into a unit that this
									// ID matches that stored in the block at 0x30.
	u8	Checksum_x;				// Checksum of this block (not including random pad)
	char	PadByte;				// Random Pad
} DYNAMIC_BLK1_DATA_t;


/*---------------------------------------------------------------------
 *
 *  Dynamic block structure 2
 *
 *--------------------------------------------------------------------*/
typedef struct tagDYNAMIC_BLK2_DATA
{
	u16	EEFixedPattRewriteCtr;	// Counter which keeps track of the number of times that the Reserved
									// EEPROM blocks have been rewritten.
	u16	BQFixedPattRewriteCtrB;	// Counter which keeps track of the number of times that the BQ27541
									// Manufacturing Block B has been rewritten.
	u16	BQFixedPattRewriteCtrA;	// Counter which keeps track of the number of times that the BQ27541
									// Manufacturing Block A has been rewritten.

	u8	CopiedManufactureID[8];	// This value shall be set initially to all ones. Upon seeing a value of
									// all ones, terminal and charger code shall replace this value with that
									// stored in the block located at hex address 0x30. Thereafter, code
									// shall check upon insertion of the battery pack into a unit that this
									// ID matches that stored in the block at 0x30.
	u8	Checksum_x;				// Checksum of this block (not including random pad)
	char	PadByte;				// Random Pad
} DYNAMIC_BLK2_DATA_t;


/*---------------------------------------------------------------------
 *
 *  Fixed block structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagFIXED_BLK_DATA
{
	u8	BlockNum[15];			// Block number of this block
	char	PadByte;
} FIXED_BLK_DATA_t;

/*---------------------------------------------------------------------
 *
 *  Extended temp range structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagEX_TEMP_RANGE_EP
{
	int8_t StartTemp;		// Lower end of this temp range
	uint16_t Voltage[3];	// Charge to voltages for this temp range
	uint16_t Current[3];	// Max charge currents for this temp range
	uint8_t pad[3];
} EX_TEMP_RANGE_EP_t;

/*---------------------------------------------------------------------
 *
 *  Extended temp charging structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagEX_TEMP_CHARGING_EP
{
	uint8_t DataType;	// Structure version byte.
	uint8_t csum;  // Checksum, bytewise total of struct (including csum) should be zero
	int8_t StopTemp;  // High end of last range, if needed.
	int8_t RecMinTemp, RecMaxTemp;  // JEITA recommended temperature range
	uint8_t pad[11];
	EX_TEMP_RANGE_EP_t TempRange[5]; // Charging temp ranges
} EX_TEMP_CHARGING_EP_t;

// Bit mask for blocks used by the EX_TEMP_CHARGING_EP_t struct
#define EX_CHARGE_TEMP_BLOCKS 0x00003F00

/*---------------------------------------------------------------------
 *
 *  QC660 data structure for value PP+ V1
 *
 *--------------------------------------------------------------------*/
typedef struct tagQC660_DATA
{
	uint8_t Flags;	// Battery flags
	uint16_t MinStartupVolt;  // Minimum startup voltage in mv
	uint8_t ThermCoff[3];	// Thermistor coefficients
	uint16_t UVLO;  // Under voltage lockout voltage in mv
	uint16_t OVLO;  // Over voltage lockout voltage in mv
	uint16_t CutoffVolt;  // Cutoff voltage in mv
	uint16_t RechargeVoltDelta;  // Recharge voltage delta from charged voltage
	uint8_t zero_pad;
	uint8_t checksum;
} tagQC660_DATA_t;

// Bit mask for block used by ship mode data
#define QC660_DATA_BLOCK (uint32_t)0x00004000

/*---------------------------------------------------------------------
 *
 *  Ship mode structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagSHIP_MODE_DATA
{
	uint16_t LowVoltage;	// Low end of shipmode voltage range
	uint16_t HighVoltage;	// High end of shipmode voltage range
	uint8_t LowCapacity;	// Low end of shipmode capacity range
	uint8_t HighCapacity;	// High end of shipmode capacity range
	uint8_t CheckSum;		// Checksum of above bytes
	uint8_t pad[9];
} SHIP_MODE_DATA_t;

#define SHIP_MODE_SIZE 7  // Number of bytes to checksum

// Bit mask for block used by ship mode data
#define SHIP_MODE_BLOCK (uint32_t)0x00020000

/*---------------------------------------------------------------------
 *
 * Gifted battery EEPROM structure
 *
 *--------------------------------------------------------------------*/
typedef struct tagGIFTED_BATT_DATA
{
	// Battery data
	char	Checksum_z;				// Checksum of static battery data
	char	DataType;				// Battery data type
	u8	Faire;					// Battery capacity levels
	u8	Unfaire;
	u8	Low;

	// Charge control data
	u8	ChargeSlowMins;			// Slow charging time out, minutes.
	u16	ChargeFastMins;			// Fast charging time out, minutes.
	u16	ChargeUp_mV;			// Charge-up voltage, mV.
	u16	SlowFastCharge_mV;		// Slow/fast charge voltage threshold, mV.
	u16	CC_Threshold;			// Capacity that must charge the battery before the BQ27541 advances ChgCycleCount().
									// This parameter is identical in name and value to the one stored in the BQ27541 data flash.
									// The BQ parameter cannot be read, however, hence this copy. (mAhrs)
	char	FillerByte1;			// Should be 0xff
	char	PadByte1;				// Random Pad

	u16	AbnormalCharge_mA;		// Abnormal battery charge current, mA.
	u16	SlowCharge_mA;			// Slow charge current, mA.
	u16	NearlyCharged_mA;		// Current at which charge completion is indicated, mA.
	u16	FastCharge_mA;			// Fast Charge Current, mA.
	u16	ChargeTerm_mA;			// Minimum Charge Termination Current, mA (below BQ27541 value.)
	u8	Block_Allocation_27541;	// Bits refer to a block of 16 contiguous bytes in the 27541, for a total of 6.
									// The LSb refers to the first block of Manu Block A, then the second of A,
									// then the first of B, etc.  If set to 0, the bit indicates that the block
									// contains useful data.  If set to 1, the block is reserved, is expected to
									// contain the pattern shown in the BQ27541 map in the document PackMakerMemSpec.
	u32	Block_Allocation_EEPROM;// Each bit refers to a block of 16 contiguous bytes in this EEPROM, a total of 32.
									// The LSb of the LSB refers to block 0, etc.  If set to 0, the bit indicates that the
									// block contains useful data.  If set to 1, the block is reserved and is treated as described in ????????
	char	PadByte2;				// Random Pad

	u8	ChargeColdOff_C;		// Highest cold temp at which battery is never charged, signed, °C.
	u8	ChargeColdOn_C;			// Hysteretic cold charging turn on temp, signed, °C.
	u8	ChargeHotOn_C;			// Hysteretic hot charging turn on temp, signed, °C.
	u8	ChargeHotOff_C;			// Lowest hot temp at which battery is never charged, signed, °C.
	u8	DischargeMin_C;			// Discharge Temperature, minimum allowed, signed, °C.
	u8	DischargeMax_C;			// Discharge Temperature, maximum allowed, signed, °C.
	u16	MaxOCV_PREDmins;		// A value greater than the maximum period in minutes starting
									// from entering BQ27541 Relaxation to seeing OCV_PRED set.
	u16	OCV_PRED_Prep_Curr_mA;	// The minimum charge or discharge current that must flow before
									// the Relaxation mode can be entered if OCV_PRED is to be set.
	u16	OCV_PRED_Prep_Time_Sec;	// The minimum time that OCV_PRED_Prep_Curr_mA must flow before
									// the Relaxation mode can be entered if OCV_PRED is to be set.
	u8	SOC_DELTA;				// The minimum amount in percent that the BQ27541 SoC must change
									// between OCV readings before OCV_PRED can be set. Typically 40%.
	u8	SOC_CAL_MAX;			// The maximum SOC percentage allowed before the calibration is
									// initiated.  Typically, SOC_CAL_MAX <= 100% - SOC_DELTA ?
									// ( OCV_PRED_Prep_Curr_mA * OCV_PRED_Prep_Time_Sec )  /
									// ( 3600 * CC_Threshold )
	u8	MaxRecal_Cycle;			// The maximum number of cycles between recalibrations.  A value
									// of 0x00 inhibits cycle number-demanded recalibration.
	char	PadByte3;				// Random Pad

	// Lock Block
	u8	Manufacture_ID[8];	// Copy of manufacture ID of the battery's SN27541-M200
	u8	DummyData[6];		// Set to 0x00
	u8	Checksum_y;			// Checksum of this block of data (random pad set to 0)
	char	PadByte4;			// Random Pad

	// Dynamic blocks 1-2
	DYNAMIC_BLK1_DATA_t	Dyn1Block[2];

	// Dynamic blocks 3-4
	DYNAMIC_BLK2_DATA_t	Dyn2Block[2];

	// Extended temp charging
	EX_TEMP_CHARGING_EP_t ExCharge;

	// QC660 data block
	tagQC660_DATA_t _660Data;

	// Fixed blocks
	FIXED_BLK_DATA_t FixBlockA[2];

	// Ship mode data
	SHIP_MODE_DATA_t ShipMode;

	// Fixed blocks
	FIXED_BLK_DATA_t FixBlockB[16];

	// Manf data block A
	u8 BlockA[32];

	// Manf data block B
	u8 BlockB[32];

	// Manf data block C
	char	Checksum_c;				// Checksum of manf block C data
	char	DataFormat541;			// Battery data type (should be 1)
	char	BatteryPartNumber[21];	// Battery part number in ASCII string
	u8		Revision;				// Battery pack revision. 0x00 or 0xff are unassigned
	char	SerialNumber[5];		// Battery pack serial number in ASCII string
	char	DateMade[3];			// Battery date made

	// Other data
	u16	M200_DeviceType;		// Device type of M200
	u16	M200_FirmwareVer;		// Firmware version of GG code
	u8	M200_Manf_ID[8];		// Manufacture ID read from the battery?s SN27541-M200
	u16	QMAX_DAY;				// Days of last calibration
	u16	Last_CHGCC;				// Last read values of cycle count and charge accumulator
	u16	Last_LCCA;
	u16 CONTROL_STATUS;			// CONTROL_STATUS flags

	// The following are read periodically from the gas gauge registers
	int16_t	AR;					// AtRate( )
	u16	ARTTE;					// AtRateTimeToEmpty( )
	u16	TEMP;					// Temperature( )
	u16	VOLT;					// Voltage( )
	u16	FLAGS;					// Flags( )
	u16	NAC;					// NominalAvailableCapacity( )
	u16	FAC;					// FullAvailableCapacity( )
	u16	RM;						// RemainingCapacity( )
	u16	FCC;					// FullChargeCapacity( )
	int16_t	AI;					// AverageCurrent( )
	u16	TTE;					// TimeToEmpty( )
	u16	TTF;					// TimeToFull( )
	u16	SI;						// StandbyCurrent( )
	u16	STTE;					// StandbyTimeToEmpty( )
	u16	MLI;					// MaxLoadCurrent( )
	u16	MLTTE;					// MaxLoadTimeToEmpty( )
	u16	AE;						// AvailableEnergy( )
	u16	AP;						// AveragePower( )
	u16	TTECP;					// TTEatConstantPower( )
	u16	SOH;					// StateOfHealth( )
	u16	SOC;					// StateOfCharge( )
	u16	QVC;					// ValidQmaxCycles()
	u16	ETU;					// ElapsedTimeUpper()
	u16	ETL;					// ElapsedTimeLower()
	u16	TV;						// TerminateVoltage()
	u16	LCCA;					// ChargeCurrentAccumulator()
	u16	CHGCC;					// ChgCycleCount( )
	u16	LDCA;					// DischargeCurrentAccumulatot()
	u16	DSGCC;					// DsgCycleCount( )
	u16	SOCZ;					// StateOfChargeZone( )
} GIFTED_BATT_DATA_t;

/*---------------------------------------------------------------------
 *
 *  Cell identifing data structure for value tier
 *
 *--------------------------------------------------------------------*/
typedef struct tagCELL_IDENT
{
	int8_t Checksum;// Checksum of ident data strct
	uint8_t Vendor;	// Cell vendor code
	uint8_t IdentData[30];	// Cell identifing data
} CELL_IDENT_t;

/*---------------------------------------------------------------------
 *
 *  Charger control structure for value tier
 *
 *--------------------------------------------------------------------*/
typedef struct tagCHARGER_CTRL_VT
{
	uint8_t Checksum;
	uint8_t SlowChrgTimeout;
	uint8_t FastChrgTimeout;
	uint16_t SlowFastVolt;
	uint16_t RechargeVolt;
	uint16_t AbnormalCurr;
	uint16_t SlowChrgHighFaultCurr;
	uint16_t SlowChrgLowFaultCurr;
	uint16_t NearlyDone;
	uint16_t Done;
	uint8_t Hysteresis;
} CHARGER_CTRL_VT_t;

/*---------------------------------------------------------------------
 *
 *  Aggregate charge structure for value tier
 *
 *--------------------------------------------------------------------*/
typedef struct tagAGG_CHARGE_VT
{
	uint8_t Checksum;  // Structure checksum
	uint8_t Partial;  // Partial charge cycle percentage
	uint16_t Cycles;  // Full charge cycle count
} AGG_CHARGE_VT_t;

/*---------------------------------------------------------------------
 *
 *  Ship mode structure for value tier/PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagSHIP_MODE_DATA_VT
{
	uint16_t LowVoltage;  // Low end of shipmode voltage range
	uint16_t HighVoltage; // High end of shipmode voltage range
	uint8_t LowCapacity;  // Low end of shipmode capacity range
	uint8_t HighCapacity;	  // High end of shipmode capacity range
} SHIP_MODE_DATA_VT_t;

/*---------------------------------------------------------------------
 *
 *  Battery health data structure for value tier/PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagBATT_HEALTH_VT
{
	uint8_t Checksum;  // Structure checksum
	uint8_t RecordType;	// Health record type, currently 0
	uint8_t Health;	// Battery health byte
	uint8_t Pad;
} BATT_HEALTH_VT_t;

/*---------------------------------------------------------------------
 *
 *  Extended temp range structure for value tier/PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagEX_TEMP_RANGE_EP_VT
{
	int8_t StartTemp;		// Lower end of this temp range
	uint16_t Voltage[3];	// Charge to voltages for this temp range
	uint16_t Current[3];	// Max charge currents for this temp range
} EX_TEMP_RANGE_EP_VT_t;

/*---------------------------------------------------------------------
 *
 *  Extended temp charging structure for value tier
 *
 *--------------------------------------------------------------------*/
typedef struct tagEX_TEMP_CHARGING_EP_VT
{
	uint8_t DataType;	// Structure version byte.
	uint8_t csum;  // Checksum, bytewise total of struct (including csum) should be zero
	int8_t StopTemp;  // High end of last range, if needed.
	int8_t RecMinTemp, RecMaxTemp;  // JEITA recommended temperature range
	EX_TEMP_RANGE_EP_VT_t TempRange[5]; // Charging temp ranges
} EX_TEMP_CHARGING_EP_VT_t;

/*---------------------------------------------------------------------
 *
 *  QC660 data structure for value tier/PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagQC660_DATA_VT
{
	uint8_t Flags;	// Battery flags
	uint16_t MinStartupVolt;  // Minimum startup voltage in mv
	uint8_t ThermCoff[3];	// Thermistor coefficients
	uint16_t UVLO;  // Under voltage lockout voltage in mv
	uint16_t OVLO;  // Over voltage lockout voltage in mv
	uint16_t CutoffVolt;  // Cutoff voltage in mv
} tagQC660_DATA_VT_t;

/*---------------------------------------------------------------------
 *
 *  Thermistor data structure for value tier
 *
 *--------------------------------------------------------------------*/
typedef struct THERM_DATA_VT
{
	int8_t Temps[9];
	uint16_t Res[9];
	uint8_t addend;
} THERM_DATA_VT_t;

/*---------------------------------------------------------------------
 *
 *  VT (Value tier) batttery data format
 *
 *--------------------------------------------------------------------*/
typedef struct tagVALUE_TIER_BATT_DATA
{
	// Battery data
	uint8_t Checksum;
	uint8_t FormatRev;
	uint8_t PartNumber[20];
	uint8_t SerialNumber[6];
	uint8_t Date[3];
	uint16_t ManfCapacity;  // Must be byte swapped before use
	// Battery capacity limits
	uint8_t BatteryLow;
	uint8_t BatteryVeryLow;
	uint8_t BatteryCritical;
	// 660 DTSI data
	uint8_t ASD1[VT_ASD1_SIZE];
	// 1725 Stuff
	uint8_t _1725RecordType;
	int8_t _1725DiscLowLimit;
	int8_t _1725DiscHighLimit;
	// Charger control
	CHARGER_CTRL_VT_t ChargerCtrl;
	// Thermistor data
	THERM_DATA_VT_t Therm;
	// JEITA data
	EX_TEMP_CHARGING_EP_VT_t JEITA;
	tagQC660_DATA_VT_t _660Data;
	// Cell ident stuff
	CELL_IDENT_t Ident;
	// Ship mode data
	SHIP_MODE_DATA_VT_t ShipMode;
	uint8_t ASD2_Checksum;
	// Battery health
	BATT_HEALTH_VT_t Health1;
	BATT_HEALTH_VT_t Health2;
	// Agregate charge
	AGG_CHARGE_VT_t AggCharge1;
	AGG_CHARGE_VT_t AggCharge2;
	// Currently free space
	uint8_t ASD2[VT_ASD2_SIZE];
} VALUE_TIER_BATT_DATA_t;

//* NGG battery defines */
#define	NGG_HD_ADD	196 	// Address of health data area
#define	NGG_AC_ADD1	148 	// Address of acc charge data area 1
#define	NGG_AC_ADD2	156 	// Address of acc charge data area 2
#define NGG_IT_ADD	164		// Address of initial times data

/*---------------------------------------------------------------------
 *
 *  Charger control structure for PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagCHARGER_CTRL_PPPV2
{
	uint8_t SlowChrgTimeout;
	uint8_t FastChrgTimeout;
	uint16_t SlowFastVolt;
	uint16_t RechargeVoltDelta;
	uint16_t AbnormalCurr;
	uint16_t SlowChrgCurr;
	uint16_t NearlyDoneCurr;
	uint16_t FallBackTermCurr;
	uint8_t Hysteresis;
} CHARGER_CTRL_PPPV2_t;

/*---------------------------------------------------------------------
 *
 *  Extended temp charging structure for PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagEX_TEMP_CHARGING_EP_PPPV2
{
	uint8_t DataType;  // Data Type
	int8_t StopTemp;  // High end of last range, if needed.
	int8_t RecMinTemp, RecMaxTemp;  // JEITA recommended temperature range
	EX_TEMP_RANGE_EP_VT_t TempRange[5]; // Charging temp ranges
} EX_TEMP_CHARGING_EP_PPPV2_t;

/*---------------------------------------------------------------------
 *
 *  Gas gauge calibration data for PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagGG_CAL_PPPV2
{
	uint16_t MaxOCVPRED_Mins;
	uint16_t OCVPRED_PrepCurrMin;
	uint16_t OCVPRED_PrepTimeSec;
	uint8_t RSOC_Delta;
	uint8_t RSOC_CalMax;
	uint8_t MaxRecalCycles;
	uint8_t MaxRecalDays;
} GG_CAL_PPPV2_t;

/*---------------------------------------------------------------------
 *
 *  Aggregate charge structure for PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagAGG_CHARGE_PPPV2
{
	uint8_t Checksum;  // Structure checksum
	uint32_t AcumChg;  // Acumulated charge in maHrs
	uint8_t Pad[3];  // Pad bytes
} AGG_CHARGE_PPPV2_t;

/*---------------------------------------------------------------------
 *
 *  Initial times structure for PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagINITIAL_TIMES_PPPV2
{
	uint8_t Checksum;  // Structure checksum
	uint32_t Time[7];  // Initial time values
	uint8_t Pad[3];  // Pad bytes
} INITIAL_TIMES_PPPV2_t;

/*---------------------------------------------------------------------
 *
 *  Initial Data structure for PP+ V2
 *
 *--------------------------------------------------------------------*/
typedef struct tagINITIAL_DATA_PPPV2
{
	uint8_t Checksum;  // Structure checksum
	uint8_t Rev; // Format revision
	uint8_t RSOC;  // Initial RSOC
	uint16_t Voltage;  // Iniital voltage
	uint8_t Temps[6];  // Temp range values
} INITIAL_DATA_t;

// Temp range cutoff defines for above temp array
#define T1 0
#define T2 1
#define T5 2
#define T6 3
#define T3 4
#define T4 5

/*---------------------------------------------------------------------
 *
 *  PP+ V2 battery data format
 *
 *--------------------------------------------------------------------*/
#define NUM_CAPS	8  // Number of capacities used to track time in cap/temp
#define NUM_TEMPS	7  // Number of temps used to track time in cap/temp

// PP+ V2 data
typedef struct tagNEW_GIFTED_BATT_DATA
{
// Auth chip data
	// Block 1 data
	uint8_t B1Checksum;
	uint8_t B1FormatRev;
	uint8_t PartNumber[20];
	uint16_t ManfCapacity_ma;  // Label capacity in maHrs
	uint16_t ManfCapacity_mw;  // Label capacity in mwHrs

	// Power managment thesholds
	uint8_t BatteryLow;
	uint8_t BatteryVeryLow;
	uint8_t BatteryCritical;

	// 1725 Stuff
	int8_t _1725DiscLowLimit;
	int8_t _1725DiscHighLimit;

	SHIP_MODE_DATA_VT_t ShipMode;  // Ship mode data
	tagQC660_DATA_VT_t _660Data;  // 660 data
	uint8_t Pad1[3];

	// Block 2 data
	uint8_t B2Checksum;
	uint8_t B2FormatRev;

	CHARGER_CTRL_PPPV2_t ChargerCtrl;  // Charger control
	EX_TEMP_CHARGING_EP_PPPV2_t JEITA;  // JEITA data
	GG_CAL_PPPV2_t Cal;  // Gas gauge calibration data

	// Agregate charge
	AGG_CHARGE_PPPV2_t AggCharge1;
	AGG_CHARGE_PPPV2_t AggCharge2;

	INITIAL_TIMES_PPPV2_t IT;  // Inital times
	BATT_HEALTH_VT_t Health;  // Battery health

	// Block 3 data
	uint8_t B3Checksum;
	uint8_t B3FormatRev;
	uint8_t Pad2[2];
	uint8_t Random[428];

	// Manf data blocks A to C  ***MUST be located right after the auth chip data***
	INITIAL_DATA_t InitData;  // Initial data
	uint8_t Pad3[85];

// Gas Gauge Data
	// Data flash values
	uint8_t ManufName[22];  // Pack maker code
	uint16_t DateMade;  // Manuf date
	uint16_t SerialNum;  // Pack serial number

	// Other gas gauge data
	uint16_t GG_DeviceType;					// Device type of GG
	uint8_t GG_FirmwareVer[11];				// Firmware version of GG code
	uint16_t GG_HardwareVer;				// Hardware version of GG
	uint32_t times[NUM_TEMPS][NUM_CAPS];	// Lifetime temp/cap records
	uint32_t QMAX_DAY;						// Days of last calibration
	uint32_t FW_RT;							// Firmware run time
	uint32_t GaugingStatus;					// GaguingStatus register
	uint16_t QmaxDOD0;						// Qmax DOD0 from ITStatus3

	// The following are read periodically from the gas gauge registers
	uint16_t CONTROL_STATUS;// ContrlStatus()
	int16_t AR;				// AtRate()
	uint16_t ARTTE;			// AtRateTimeToEmpty()
	uint16_t TEMP;			// Temperature()
	uint16_t VOLT;			// Voltage()
	uint16_t BATTERYSTATUS;	// BatteryStatus()
	int16_t	INSTCURR;		// Current()
	uint16_t Pad4;
	uint16_t RM;			// RemainingCapacity()
	uint16_t FCC;			// FullChargeCapacity()
	int16_t	AI;				// AverageCurrent()
	uint16_t TTE;			// AverageTimeToEmpty()
	uint16_t TTF;			// AverageTimeToFull()
	uint16_t Pad5[2];
	uint16_t MLI;			// MaxLoadCurrent()
	uint16_t MLTTE;			// MaxLoadTimeToEmpty()
	int16_t	AP;				// AveragePower()
	uint16_t BTP[2];		// BTP Thresholds
	uint16_t INT_TEMP;		// InternalTemperature()
	uint16_t CC;			// CycleCount()
	uint16_t RSOC;			// RelativeStateOfCharge()
	uint16_t SOH;			// StateOfHealth()
	int16_t	CV;				// ChargingVoltage()
	int16_t	CI;				// ChargingCurrent()
	int16_t	TERMVOLT;		// TerminateVoltage()
	uint32_t TSU;			// TimeStamp
	uint16_t QVC;			// QmaxCycles()
	uint16_t DCAP;			// DesignCapacity()
	uint16_t Pad6;			// Makes data same size as V1 gauge
} NEW_GIFTED_BATT_DATA_t;

#pragma pack()

#endif	// #ifndef PWRMBATT_H_
