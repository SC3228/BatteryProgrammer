//--------------------------------------------------------------------
// FILENAME:	pwm_batt.c
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	Battery manager Power Micro file
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

#include <linux/string.h>
#include <linux/types.h>

// #include <GiftedBattery/GiftedBattery.h>
// #include <ZebraAuth/ZebraAuth.h>
// #include "../GiftedBattery/BattMan.h"

#include "pwm.h"
#include "pwm_batt.h"
#include "pwm_chrg.h"
#include "aes.h"
#include "keys.h"
#include "BattMan_main.h"

#ifndef abs
#define abs(n) ((n>0)? (n):(-n))
#endif

uint8_t Addr = 0;	// Address of dynamic block to write

u32 g_dwHadInvalidBattery; // Backup copy of battery status
u32 g_dwLeftOverChg;              // Left over maHrs * 3600000
int32_t g_AvgCurrent = 0, g_AvgCnt = 0;  // Average current stuff

// Capacity filter stuff
int g_dwCapacity = CAP_UNKNOWN;  // Last reported capacity
u32 dwAdd = 0, dwAdded = 0;
u64 dwRateLimitStart = 0;
u32 dwSub = 0, dwSubed = 0;
u64 dwRateLimitStartF = 0;

// Value tier charge accumlation stuff
int LastVTcap = -1;  // Last VT capacity reading

bool g_bWriteIT = false;  // NGG write initial times data flag
bool g_bWriteHD = false;  // NGG write health data flag
bool g_bUTSFU = false;  // NGG update time since first use
bool g_bGaugingStatus = false;  // Get gauging status data
bool g_bGotStatus = false;  // Flag to indicate a new gauging status value is in
bool g_bITStatus2 = false;  // Flag to trigger read of ITStatus2 register
bool g_bGotITStatus2 = false;  // Flag to indicate ITStatus2 was read
bool g_bITStatus3 = false;  // Flag to trigger read of ITStatus3 register
bool g_bGotITStatus3 = false;  // Flag to indicate ITStatus3 was read
int16_t LastGGTmp = 25; // Last temp from GG

uint32_t RegBytesRead;
uint32_t g_dwBattCommErrCnt;
uint32_t g_dwLastTC;
bool g_dwDoChgAcc;
long g_dwNextTSFU_Time;
bool g_bWriteNGG_AC1, g_bWriteNGG_AC2;
bool g_bReadTempChip;
bool g_bReadCONTROL_STATUS;
bool g_bGotQMAX_DAY;
bool g_bReadQMAX_DAY;
bool g_bUpdateBM;
bool g_bReadMPA3Regs;
bool g_bReadMPA3Health;
bool g_bWriteMPA2Health;
bool g_bWriteVTAC1, g_bWriteVTAC2, g_bWriteVTH1, g_bWriteVTH2;
bool g_bWriteDB1, g_bWriteDB2, g_bWriteDB3, g_bWriteDB4;
bool bWhichTC;
bool bWriteTC;
bool g_bHibernate;
unsigned long DoAccTime;
uint32_t dwWrBattMode;

void PM_Init(void)
{
	RETAILMSG(ZONE_FUNCTION,("BattMan: PM_Init\n"));

	// Reset write data state machine
	dwWrBattMode = WR_MODE_IDLE;
	ClearWriteFlags();
	g_dwHadInvalidBattery = 0;
	LastVTcap = -1;

	LastGGTmp = NO_TEMP_YET; // Clear last battery temp
	ResetRateLimit();

	g_AvgCurrent = local_GetBatteryCurrent();  // Reset avg stuff
	g_AvgCnt = 1;
	DoAccTime = local_GetStopTime(120000);  // Start two minute charge accumulation timer
}

// Reinit on no batt
void PM_Reinit(void)
{
	// Reset write data state machine
	dwWrBattMode = WR_MODE_TOSS; // Toss current operation
	g_AvgCurrent = local_GetBatteryCurrent();
	g_AvgCnt = 1;
	LastVTcap = -1;
	ResetRateLimit();
}

void ClearWriteFlags(void)
{
	g_bHibernate = false;
	bWriteTC = false;
	bWhichTC = false;  // Set to fist area
	g_bWriteDB1 = false;
	g_bWriteDB2 = false;
	g_bWriteDB3 = false;
	g_bWriteDB4 = false;
	g_bWriteVTAC1 = false;
	g_bWriteVTAC2 = false;
	g_bWriteVTH1 = false;
	g_bWriteVTH2 = false;
	g_bWriteMPA2Health = false;
	g_bReadMPA3Health = false;
	g_bReadMPA3Regs = false;
	g_bUpdateBM = false;
	g_bReadQMAX_DAY = false;
	g_bGotQMAX_DAY = false;
	g_bReadCONTROL_STATUS = false;
	g_bReadTempChip = false;
	g_bWriteNGG_AC1 = false;
	g_bWriteNGG_AC2 = false;
	g_bWriteHD = false;
	g_bWriteIT = false;
	g_bUTSFU = false;
	g_bGaugingStatus = false;
	g_bGotStatus = false;
	g_bITStatus2 = false;
	g_bGotITStatus2 = false;
	g_bITStatus3 = false;
	g_bGotITStatus3 = false;
}

// Routine to handle Power Micro ticks
uint32_t PM_Tick(void)
{
	uint32_t Delay; // Next loop delay
	uint8_t CSum;  // Checksum
	uint8_t *cpnt;  // Byte pointer
	uint32_t dwCnt;  // Counter
	int16_t tmp;  // Temp varible for temperature conversion
	uint16_t tmp16;  // Used for debug data output
	uint32_t tmp32;  // Used for debug data output
	uint8_t buf[16];  // Temp buffer for reading lock block
	u32 DataChanged;  // Flag to indicate new data is avaiable.
	u32 dwAccTime;
	uint16_t Month, Day, Year;  // Current date storage

	RETAILMSG(ZONE_FUNCTION,("BattMan: PM_Tick Start\n"));

//RETAILMSG(1,("PM_Proc: Volt: %d, Amp: %d\n",local_GetBatteryVoltage(),local_GetBatteryCurrent()));
	Delay = BattDetect(); // Do battery detect stuff

	GasGauge(0);  // Do gas gauging

	// Time to do TSFU update?
	if (BATT_Z561 == g_BattType)  // Valid new gauge battery?
	{
		if (local_PastTime(g_dwNextTSFU_Time))  // Been 15 minutes since the last time?
		{
			RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Start TSFU update\n"));  // Show battery data if needed
			g_dwNextTSFU_Time = local_GetStopTime(TSFU_WAIT_TIME);  // Set next time
			g_bUTSFU = true;  // Set flag to trigger update
		}
	}

	// Do charge accumulation
	if (g_dwDoChgAcc)
	{ // If we can do charge accumulation
		// Average the current
		g_AvgCurrent += local_GetBatteryCurrent();
		++g_AvgCnt;

		if (local_PastTime(DoAccTime)) // Has it been two minutes yet?
		{  // Yup, do last two minutes of charge
			g_AvgCurrent /= g_AvgCnt; // Calculate avg current
			switch (g_BattType) // Check battery type
			{
			case BATT_VT: // Value tier battery
				if (LastVTcap >= 0) // Valid last capacity?
				{
					if (Pointers->battCapacity > LastVTcap) // Change from last is plus?
					{
						// Are we charging?
						if (local_GetBatteryCurrent() > 5)
						{ // More than 5ma of charge current
							// Add in new capacity
							RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AggChrg: Last: %d\r\n",LastVTcap));
							RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AggChrg: Curr: %d\r\n",Pointers->battCapacity));
							RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AggChrg: Part: %d\r\n",g_ValueTierData.AggCharge1.Partial));
							g_ValueTierData.AggCharge1.Partial += Pointers->battCapacity - LastVTcap;

							// Check for over flow
							if (g_ValueTierData.AggCharge1.Partial >= 100)
							{
								g_ValueTierData.AggCharge1.Partial -= 100;  // Reset partial count
								++g_ValueTierData.AggCharge1.Cycles; // Increment cycles
								g_ValueTierData.AggCharge2.Partial = g_ValueTierData.AggCharge1.Partial; // Update second field
								g_ValueTierData.AggCharge2.Cycles = g_ValueTierData.AggCharge1.Cycles;
								Pointers->CycleCount = g_ValueTierData.AggCharge1.Cycles;
							}

							// Set total charge
							g_dwAggregateCharge = (u32)g_ValueTierData.AggCharge1.Cycles * (u32)g_ValueTierData.ManfCapacity;
							g_dwAggregateCharge += (u32)g_ValueTierData.AggCharge1.Partial * (u32)g_ValueTierData.ManfCapacity / 100;
							Pointers->TotalAccChargeAll = g_dwAggregateCharge; // Save charge from all devices
							Pointers->TotalAccCharge  = g_dwAggregateCharge; // Save charge from zebra devices

							// Trigger updates
							g_bWriteVTAC1 = true;
							g_bWriteVTAC2 = true;

							VT_CheckHealth(); // Check health level
						}
					}
				}
				LastVTcap = Pointers->battCapacity; // Update last capacity
				break;
			case BATT_Z561: // V2 PP+
				if (LastVTcap >= 0) // Valid last capacity? (Sharing LastVTcap with VT batts
				{
					if (Pointers->battCapacity > LastVTcap) // Change from last is plus?
					{
						// Are we charging?
						if (local_GetBatteryCurrent() > 5)
						{ // More than 5ma of charge current
							// Add in new capacity
							RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AggChrg: Last: %d\r\n",LastVTcap));
							RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AggChrg: Curr: %d\r\n",Pointers->battCapacity));
							g_GiftedV2Data.AggCharge1.AcumChg += ((uint32_t)Pointers->battCapacity - (uint32_t)LastVTcap) * (uint32_t)g_GiftedV2Data.FCC / (uint32_t)100;
							g_GiftedV2Data.AggCharge2.AcumChg = g_GiftedV2Data.AggCharge1.AcumChg;

							// Set total charge
							Pointers->TotalAccCharge  = g_GiftedV2Data.AggCharge1.AcumChg;  // Save charge from zebra devices

							// Trigger updates
							g_bWriteNGG_AC1 = true;
							g_bWriteNGG_AC2 = true;
						}
					}
				}
				LastVTcap = Pointers->battCapacity; // Update last capacity
				break;
			case BATT_M200: // MPA3 PP+
				// Add last two minutes into charge total
				if (g_dwAggregateCharge > g_dwLastTC)  // Check for any change
				{ // Yup, update the battery data
					g_GiftedBattData.Dyn1Block[0].BatteryLifeData += (g_dwAggregateCharge - g_dwLastTC);
					g_dwLastTC = g_dwAggregateCharge;  // Save new value
					Pointers->TotalAccCharge = g_GiftedBattData.Dyn1Block[0].BatteryLifeData; // Update shared data
					Pointers->TotalAccChargeAll = g_dwLastTC;

					// Set flag to trigger rewrites
					g_bWriteDB1 = true;
					g_bWriteDB2 = true;
				}
				break;
			case BATT_SMART: // MPA2 battery
				// Are we charging?
				if (g_AvgCurrent > 0)
				{  // Yes, add last two minutes into charge total
					dwAccTime = 120000;

					// Add in maHr
					g_dwAggregateCharge += ((g_AvgCurrent * dwAccTime) + g_dwLeftOverChg) / 3600000;

					// Figure left over fraction
					g_dwLeftOverChg = ((g_AvgCurrent * dwAccTime) + g_dwLeftOverChg) % 3600000;

					// Kick off write of TC area
					Pointers->TotalAccChargeAll = g_dwAggregateCharge; // Update shared data
					Pointers->TotalAccCharge = 0;

					bWriteTC = true;

					Pointers->CycleCount = Pointers->TotalAccChargeAll/Pointers->batteryRatedCapacity; // Update cycle count

					// Check battery health
					if (Pointers->dwCycleCountThreshold < (g_dwAggregateCharge/Pointers->batteryRatedCapacity))
					{  // Unhealthy
						// check for not currently marked as unhealthy
						if (g_SmartBattData.BattHealth != BATT_SOH_UNHEALTHY)
						{  // Change to bad
							g_SmartBattData.BattHealth = BATT_SOH_UNHEALTHY;
							// Set update flag
							g_bWriteMPA2Health = true;
						}
					}
					else
					{  // Healthy
						// check for not currently marked as healthy
						if (g_SmartBattData.BattHealth != BATT_SOH_HEALTHY)
						{  // Change to good
							g_SmartBattData.BattHealth = BATT_SOH_HEALTHY;
							// Set update flag
							g_bWriteMPA2Health = true;
						}
					}

					Pointers->battHealth = g_SmartBattData.BattHealth; // Update global health byte
				}
				break;
			default: // Shouldn't get here
				local_print("PM_Batt: Unknown type in charge accumulate: %d\n",g_BattType);
				break;
			}

			g_AvgCurrent = local_GetBatteryCurrent();  // Reset avg stuff
			g_AvgCnt = 1;
			DoAccTime = local_GetStopTime(120000); // Reset timer
			RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AggChrg: %dmaHr\r\n",g_dwAggregateCharge));  // Show battery data if needed
		}
	}
	else
		DoAccTime = local_GetStopTime(120000); // Reset charge accumulation timer

	// Do any I2C updates/reads needed
	if (BATT_NONE != g_BattType) // Do we have a valid battery
	{  // Yes, so we know that there is no battery I2C from detect software happening
		RETAILMSG(ZONE_FUNCTION,("BattMan: PM_Tick: WrMode: %d\n",dwWrBattMode));
		switch (dwWrBattMode)  // Switch on current write battery data mode
		{
		case WR_MODE_IDLE:
			// NOTE: This check must always be the first one!
			// Check for putting GG into hibernate, stops all other updates/reads
			if (false != g_bHibernate)
			{
				g_bHibernate = false;  // Clear flag

				// Setup write of hibernate bit
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_SET_HIBERNATE & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_SET_HIBERNATE >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes
				g_BattTrans.byBattChipAddr2 = 0;  // No second transaction

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					// Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Start hibernate writed\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_HIBERNATE;  // Wait for write done
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start register read3\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for read of gas gauge registers
			if (false != g_bReadMPA3Regs)
			{
				g_bReadMPA3Regs = false;  // Clear flag

				switch (g_BattType)
				{
				case BATT_Z561: // Do Z561 GG read
					// Start read of registers
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // status register
					g_BattTrans.byBattDataSize1 = 0x20; // 32 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD + 0x20; // Next chunk
					g_BattTrans.byBattDataSize2 = 0x1e; // Rest of registers

					g_BattTrans.DoStop = 1; // Force stop in between
					break;
				case BATT_M200: // Do M200 GG read
					// Start read of registers
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set gas gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = AR_CMD; // Start read at AR register

					if (Pointers->MuxedClock)  // Are we using a clock mux?
						g_BattTrans.byBattDataSize1 = GB_CMD_PARTIAL_READ_SIZE; // Yes, read first chunk of registers
					else
						g_BattTrans.byBattDataSize1 = GB_CMD_FULL_READ_SIZE; // No, read all registers

					RegBytesRead = 0; // Reset bytes read counter
					break;
				default:
					local_print("PM_Batt: Unknown type in g_bReadMPA3Regs: %d\n",g_BattType);
					break;
				}

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					// Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Start GG register read\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_REGS;  // Wait for read done
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start register read3\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for QMAX_DAY read
			if (false != g_bReadQMAX_DAY)
			{
				g_bReadQMAX_DAY = false; // Clear flag

				switch (g_BattType)
				{
				case BATT_Z561: // Do Z561 GG read
					// Setup read of Qmax day
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_QMAX_DAY & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_QMAX_DAY >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Qmax day read\n"));  // Show battery data if needed
						dwWrBattMode = RD_QMAX_DAY_NGG1;  // Get data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start Qmax day read\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_bGotQMAX_DAY = true; // Return error
						g_GiftedV2Data.QMAX_DAY = 0xffff;
					}
					break;
				case BATT_M200: // Do M200 GG read
					// Setup read of QMAX_DAY
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_READ_QMAX_DAY & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_READ_QMAX_DAY >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						// Set next state
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Start QMAX_DAY read\n")); // Show battery data if needed
						dwWrBattMode = RD_QMAX_DAY1;  // Setup next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Proc: Can't start QMAX_DAY command write\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						g_bGotQMAX_DAY = true; // Return error
						g_GiftedBattData.QMAX_DAY = 0xffff;
						++g_dwBattCommErrCnt; // Increment comm error counter
					}
					break;
				default:
					local_print("PM_Batt: Unknown type in g_bReadQMAX_DAY: %d\n",g_BattType);
					break;
				}
				break;
			}

			// Check for MPA3 dynamic block write
			if (false != g_bWriteDB1 || false != g_bWriteDB2 || false != g_bWriteDB3 || false != g_bWriteDB4)
			{
				// Setup write address
				if (true == g_bWriteDB1)  // Check which area to use
				{ // Block1
					Addr = GB_DYN_BLK1_ADD; // Start of first dynamic block
					g_bWriteDB1 = false;  // Clear flag
				}
				else if (true == g_bWriteDB2)
				{ // Block2
					Addr = GB_DYN_BLK2_ADD; // Start of second dynamic block
					g_bWriteDB2 = false;  // Clear flag
				}
				else if (true == g_bWriteDB3)
				{ // Block3
					Addr = GB_DYN_BLK3_ADD; // Start of second dynamic block
					g_bWriteDB3 = false;  // Clear flag
				}
				else
				{ // Block4
					Addr = GB_DYN_BLK4_ADD; // Start of second dynamic block
					g_bWriteDB4 = false;  // Clear flag
				}

				// Setup read of lock block to double check we still have the same battery.
				g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr | 0x01;  // Set EEPROM address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataSize1 = 16; // Size of lock block
				g_BattTrans.byBattDataAddr1 = GB_LOCK_BLK_ADD; // Start of lock block

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: LB Read\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_DB1;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery DB write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for NGG acc charge record 1 write, don't do while doing authentication
			if (false != g_bWriteNGG_AC1 && !Pointers->DoingAuth)
			{
				g_bWriteNGG_AC1 = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((NGG_AC_ADD1 >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = NGG_AC_ADD1 & 0xff; // Start of first acc charge data
				g_BattTrans.byBattDataSize1 = 8; // Size of data
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_GiftedV2Data.AggCharge1;
				for (dwCnt = 1; dwCnt < sizeof(AGG_CHARGE_PPPV2_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG AC1 write start\n"));

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG AGC1 write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_Auth;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery NGG AGC1 write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for NGG acc charge record 2 write, don't do while doing authentication
			if (false != g_bWriteNGG_AC2 && !Pointers->DoingAuth)
			{
				g_bWriteNGG_AC2 = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((NGG_AC_ADD2 >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = NGG_AC_ADD2 & 0xff; // Start of first acc charge data
				g_BattTrans.byBattDataSize1 = 8; // Size of data
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_GiftedV2Data.AggCharge2;
				for (dwCnt = 1; dwCnt < sizeof(AGG_CHARGE_PPPV2_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG AGC2 write start\n"));

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG AGC2 write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_Auth;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery NGG AGC2 write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for NGG health data write, only do if authentication is not in progress
			if (false != g_bWriteHD && !Pointers->DoingAuth)
			{
				g_bWriteHD = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((NGG_HD_ADD >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = NGG_HD_ADD & 0xff; // Start of health data
				g_BattTrans.byBattDataSize1 = 4; // Size of data
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_GiftedV2Data.Health;
				for (dwCnt = 1; dwCnt < sizeof(BATT_HEALTH_VT_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG HD write start\n"));

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG HD write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_Auth;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery NGG HD write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for NGG TSFU update
			if (false != g_bUTSFU)
			{
				g_bUTSFU = false;  // Clear flag

				// Setup read of lifetime data
				RegBytesRead = 0; // Reading first block

				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_LIFE_TIME_CAPS & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_LIFE_TIME_CAPS >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: TSFU update\n"));  // Show battery data if needed
					dwWrBattMode = RD_MODE_TSFU;  // Do more reads
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start TSFU update\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for ITStatus2 read
			if (false != g_bITStatus2)
			{
				g_bITStatus2 = false;  // Clear flag

				// Setup read of gauging status data
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_ITSTATUS2 & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_ITSTATUS2 >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: ITS2 read\n"));  // Show battery data if needed
					dwWrBattMode = RD_MODE_ITS2;  // Check result
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start ITS2 read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotITStatus2 = true;  // Set flag
				}
				break;
			}

			// Check for ITStatus3 read
			if (false != g_bITStatus3)
			{
				g_bITStatus3 = false;  // Clear flag

				// Setup read of gauging status data
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_ITSTATUS3 & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_ITSTATUS3 >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: ITS3 read\n"));  // Show battery data if needed
					dwWrBattMode = RD_MODE_ITS3;  // Check result
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start ITS3 read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedV2Data.QmaxDOD0 = 0;  // Error return value
					g_bGotITStatus3 = true;  // Set flag
				}
				break;
			}

			// Check for NGG Gauging Status read
			if (false != g_bGaugingStatus)
			{
				g_bGaugingStatus = false;  // Clear flag

				// Setup read of gauging status data
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_GAUGING_STATUS & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_GAUGING_STATUS >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Gauging Status read\n"));  // Show battery data if needed
					dwWrBattMode = RD_MODE_GGST;  // Check result
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start gauging status read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedV2Data.GaugingStatus = 0xffffffff;  // Error return value
					g_bGotStatus = true;  // Set flag
				}
				break;
			}

			// Check for NGG initial times write, not during authentication
			if (false != g_bWriteIT && !Pointers->DoingAuth)
			{
				g_bWriteIT = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((NGG_IT_ADD >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = NGG_IT_ADD & 0xff; // Start of inital times data
				g_BattTrans.byBattDataSize1 = 32; // Size of data
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_GiftedV2Data.IT;
				for (dwCnt = 1; dwCnt < sizeof(INITIAL_TIMES_PPPV2_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG IT write start\n"));

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: NGG IT write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_IT;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery NGG IT write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for VT acc charge record 1 write
			if (false != g_bWriteVTAC1)
			{
				g_bWriteVTAC1 = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((VT_AC_ADD1 >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = VT_AC_ADD1 & 0xff; // Start of first acc charge data

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_ValueTierData.AggCharge1;
				for (dwCnt = 1; dwCnt < sizeof(AGG_CHARGE_VT_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: VTAC1 write start\n"));
				goto StartVTacWrite;
			}

			// Check for VT acc charge record 2 write
			if (false != g_bWriteVTAC2)
			{
				g_bWriteVTAC2 = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((VT_AC_ADD2 >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = VT_AC_ADD2 & 0xff; // Start of first acc charge data

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_ValueTierData.AggCharge2;
				for (dwCnt = 1; dwCnt < sizeof(AGG_CHARGE_VT_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: VTAC2 write start\n"));
				goto StartVTacWrite;
			}

			// Check for VT health record 1 write
			if (false != g_bWriteVTH1)
			{
				g_bWriteVTH1 = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((VT_HD_ADD1 >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = VT_HD_ADD1 & 0xff; // Start of first acc charge data

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_ValueTierData.Health1;
				for (dwCnt = 1; dwCnt < sizeof(BATT_HEALTH_VT_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: VTH1 write start\n"));
				goto StartVTacWrite;
			}

			// Check for VT health record 2 write
			if (false != g_bWriteVTH2)
			{
				g_bWriteVTH2 = false;  // Clear flag

				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | ((VT_HD_ADD2 >> 7) & 0x06);  // Set Auth chip address and write
				g_BattTrans.byBattDataAddr1 = VT_HD_ADD2 & 0xff; // Start of first acc charge data

				// Do checksum and put data into buffer
				CSum = 0;
				cpnt = (uint8_t *)&g_ValueTierData.Health2;
				for (dwCnt = 1; dwCnt < sizeof(BATT_HEALTH_VT_t); ++dwCnt)
				{
					CSum += cpnt[dwCnt];
					g_BattTrans.byBattDataBuff1[dwCnt] = cpnt[dwCnt];
				}
				g_BattTrans.byBattDataBuff1[0] = ~CSum + 1;
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: VTH2 write start\n"));

StartVTacWrite:
				// Setup I2C structure
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataSize1 = VT_REC_SIZE; // Size of data

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: VT write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_Auth;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery VT write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for MPA2 total charge write
			if (false != bWriteTC)
			{
				bWriteTC = false;  // Clear flag

				// Start first write
				// Setup I2C structure
				g_BattTrans.byBattChipAddr1 = MPA2EEPROM;  // Set EEPROM address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				if (false == bWhichTC)  // Check which area to use
				{
					g_BattTrans.byBattDataAddr1 = SB_LIFE_ADD1; // Start of first life data
					bWhichTC = true;
				}
				else
				{
					g_BattTrans.byBattDataAddr1 = SB_LIFE_ADD2; // Start of second life data
					bWhichTC = false;
				}
				g_BattTrans.byBattDataSize1 = SB_LIFE_SIZE; // Size of life data
				*(u32 *)g_BattTrans.byBattDataBuff1 = g_dwAggregateCharge; // Set in total charge data

				// Calculate checksum
				CSum = g_BattTrans.byBattDataBuff1[0] + g_BattTrans.byBattDataBuff1[1]
						+ g_BattTrans.byBattDataBuff1[2] + g_BattTrans.byBattDataBuff1[3];
				CSum = ~CSum + 1;
				g_BattTrans.byBattDataBuff1[4] = CSum;

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: TC write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_TC;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery TC write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for MPA3 CONTROL_STATUS read
			if (false != g_bReadCONTROL_STATUS)
			{
				g_bReadCONTROL_STATUS = false; // Clear flag

				// Setup read of CONTROL_STATUS
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					dwWrBattMode = RD_CONTROL_STATUS1;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start CONTROL_STATUS command write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					g_GiftedBattData.CONTROL_STATUS = 0xffff; // Set error
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for read of temp chip
			if (false != g_bReadTempChip)
			{
				g_bReadTempChip = false;  // Clear flag

				// Start read of temp chip
				if (BATT_SMART == g_BattType)
					g_BattTrans.byBattChipAddr1 = MPA2TEMP;  // Set gas gauge address and write
				else
				{  // Skip if not valid smart battery
//					g_BattTrans.byBattChipAddr1 = TPB_TEMP;  // Set gas gauge address and write
					Pointers->CurTemp = GB_ERR;
					break;
				}
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = 1; // Write config register
				g_BattTrans.byBattDataSize1 = 1;
				g_BattTrans.byBattDataBuff1[0] = 0;  // Clear config bits (Remove shutdown)

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					// Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Start temp read\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_START_TEMP;  // Wait for write done
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start temp read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}

			// Check for MPA2 health write
			// NOTE: This MUST be the last check made as it can be set for
			//       an extended period of time and needs to be prempted
			//       by any other flag.
			if (false != g_bWriteMPA2Health)
			{
				// Check for valid date
				if (0 == g_SmartBattData.DateFirstUse[0])
				{
					// Get date
					if (!local_GetDate(&Month,&Day,&Year))
					{  // Went OK
						// Verify date is OK
						if (Day >=1 && Day <=31
							&& Month >= 1 && Month <= 12
							&& Year >= 2017 && Year < 4096)
						{  // It's OK, use it
							g_SmartBattData.DateFirstUse[0] = (uint8_t)Day;
							g_SmartBattData.DateFirstUse[1] = (uint8_t)(Year & 0xff);
							g_SmartBattData.DateFirstUse[2] = (uint8_t)((Month << 4) | ((Year >> 8) & 0x0f));
							Pointers->fyear = ((g_SmartBattData.DateFirstUse[2] & 0x0f) << 8) | g_SmartBattData.DateFirstUse[1];
							Pointers->fmonth = g_SmartBattData.DateFirstUse[2] >> 4;
							Pointers->fday = g_SmartBattData.DateFirstUse[0];
						}
						else  // Try again next time
						{
							local_print("PM_Batt: Got bad date\n");
							break;
						}
					}
					else  // try again next time
					{
						local_print("PM_Batt: Unable to get date\n");
						break;
					}
				}

				g_bWriteMPA2Health = false;  // Clear flag

				// Start write
				// Setup I2C structure
				g_BattTrans.byBattChipAddr1 = MPA2EEPROM;  // Set EEPROM address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = SB_HEALTH_DATA_ADD; // Start of health data
				g_BattTrans.byBattDataSize1 = SB_HEALTH_DATA_SIZE; // Size of health data

				// Copy over data
				memcpy(g_BattTrans.byBattDataBuff1,(uint8_t *)&g_SmartBattData.Health_CSum,SB_HEALTH_DATA_SIZE);

				// Calculate checksum
				CSum = g_BattTrans.byBattDataBuff1[1] + g_BattTrans.byBattDataBuff1[2]
						+ g_BattTrans.byBattDataBuff1[3] + g_BattTrans.byBattDataBuff1[4]
						 + g_BattTrans.byBattDataBuff1[5];
				CSum = ~CSum + 1;
				g_BattTrans.byBattDataBuff1[0] = CSum;

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Health write\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_HEALTH;  // Setup next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery health write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
				break;
			}
			break;

		case RD_MODE_ITS2:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Check block transfer
					if (BlockReadCheck(NGG_ITSTATUS3,g_BattTrans.byBattDataBuff2) != 24) // Len is 7, gauging status is 3 bytes.
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: ITS2 block error: %d\n",g_BattTrans.byBattDataBuff2[BLK_READ_LEN]));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_bGotITStatus2 = true;  // Set flag
						break;
					}

					// Show debug data
					if (SHOW_CAL)
					{
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+3,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: LStatus: %02X\n",tmp16));
						memcpy((void *)(&tmp32),g_BattTrans.byBattDataBuff2+8,4);
						RETAILMSG(SHOW_CAL, ("PM_Proc: State Time: %d\n",tmp32));
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+12,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: DOD0_0: %d\n",tmp16));
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+14,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: DOD0 PassQ: %d\n",tmp16));
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+18,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: DOD0 Time: %d\n",tmp16));
					}

					g_bGotITStatus2 = true;  // Set flag
				}
				else // No good
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad ITS2 read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotITStatus2 = true;  // Set flag
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: ITS2 read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotITStatus2 = true;  // Set flag
				}
			}
			break;

		case RD_MODE_ITS3:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Check block transfer
					if (BlockReadCheck(NGG_ITSTATUS3,g_BattTrans.byBattDataBuff2) != 18) // Len is 7, gauging status is 3 bytes.
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: ITS3 block error: %d\n",g_BattTrans.byBattDataBuff2[BLK_READ_LEN]));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_GiftedV2Data.QmaxDOD0 = 0;  // Error return value
						g_bGotITStatus3 = true;  // Set flag
						break;
					}

					// Show debug data
					if (SHOW_CAL)
					{
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+2,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: QMAX 0: %d\n",tmp16));
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+6,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: QMAX PassQ: %d\n",tmp16));
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+8,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: QMAX Time: %d\n",tmp16));
						memcpy((void *)(&tmp16),g_BattTrans.byBattDataBuff2+14,2);
						RETAILMSG(SHOW_CAL, ("PM_Proc: DOD0: %d\n",tmp16));
					}

					// Copy over data
					memcpy((void *)(&g_GiftedV2Data.QmaxDOD0),g_BattTrans.byBattDataBuff2+4,2);
					g_bGotITStatus3 = true;  // Set flag
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					RETAILMSG(SHOW_CAL, ("PM_Proc: QMAX DOD0: %d\n",g_GiftedV2Data.QmaxDOD0));
				}
				else // No good
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad ITS3 read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedV2Data.QmaxDOD0 = 0;  // Error return value
					g_bGotITStatus3 = true;  // Set flag
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: ITS3 read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedV2Data.QmaxDOD0 = 0;  // Error return value
					g_bGotITStatus3 = true;  // Set flag
				}
			}
			break;

		case RD_MODE_GGST:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Check block transfer
					if (BlockReadCheck(NGG_GAUGING_STATUS,g_BattTrans.byBattDataBuff2) != 7) // Len is 7, gauging status is 3 bytes.
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Gauging Status block error: %d\n",g_BattTrans.byBattDataBuff2[BLK_READ_LEN]));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_GiftedV2Data.GaugingStatus = 0xffffffff;  // Error return value
						g_bGotStatus = true;  // Set flag
						break;
					}

					// Copy over data
					memcpy((void *)(&g_GiftedV2Data.GaugingStatus),g_BattTrans.byBattDataBuff2+2,4);
					g_bGotStatus = true;  // Set flag
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				}
				else // No good
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad gauging status read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedV2Data.GaugingStatus = 0xffffffff;  // Error return value
					g_bGotStatus = true;  // Set flag
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: gauging status read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedV2Data.GaugingStatus = 0xffffffff;  // Error return value
					g_bGotStatus = true;  // Set flag
				}
			}
			break;

		case RD_MODE_TSFU:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Check block transfer
					if (BlockReadCheck(NGG_LIFE_TIME_CAPS+RegBytesRead,g_BattTrans.byBattDataBuff2) != 36)
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: TSFU block error\n"));  // Show battery data if needed
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						break;
					}

					// Copy over data
					memcpy((void *)((uint8_t *)(&g_GiftedV2Data.times[RegBytesRead])),g_BattTrans.byBattDataBuff2+2,32);

					// Done yet?
					++RegBytesRead;
					if (RegBytesRead >= 7)
					{ // Update the TSFU!
						Update_TSFU();
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: TSFU update done\n"));  // Show battery data if needed
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						break;
					}

					// Setup read of next block
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = (NGG_LIFE_TIME_CAPS+RegBytesRead) & 0xff;
					g_BattTrans.byBattDataBuff1[1] = ((NGG_LIFE_TIME_CAPS+RegBytesRead) >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Setup for next time
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start TSFU read\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
					}
				}
				else // No good
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad TSFU read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: TSFU read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_STOPPED:
			break;

		case WR_MODE_HIBERNATE:
			// Config write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					CancelAccess(); // Stop any battery I/O
					dwWrBattMode = WR_MODE_STOPPED; // Keep it stopped
					local_InHibernate(0);  // Tell driver we are GTG
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad hibernate config write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					local_InHibernate(1);  // Tell driver we failed
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Hibernate config write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_START_TEMP:
			// Config write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Setup wait for conversions
					dwBDStopTime = local_GetStopTime(2000); // Wait two seconds for temp conversion
					dwWrBattMode = WR_MODE_WAIT_TEMP;  // Wait for read done
					Delay = FAST_LOOP * 2; // Use 2 second delay
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad temp config write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: temp config write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_WAIT_TEMP:
			if (local_PastTime(dwBDStopTime)) // Been long enough?
			{
				// Setup temp read
				g_BattTrans.byBattChipAddr1 = MPA2TEMP | 1;  // Set read of temp chip
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = 0; // Read temp register
				g_BattTrans.byBattDataSize1 = 2;

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					// Set next state
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Do temp read1\n"));  // Show battery data if needed
					dwWrBattMode = WR_MODE_GET_TEMP;  // Wait for read done
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't do temp read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{
				Delay = FAST_LOOP / 5; // Use 200ms second delay
			}
			break;

		case WR_MODE_GET_TEMP:
			// Temp read done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Get temp and sign extend if needed
					if (g_BattTrans.byBattDataBuff1[0] & 0x80)
						Pointers->CurTemp = (int16_t)g_BattTrans.byBattDataBuff1[0] | 0xff00;
					else
						Pointers->CurTemp = g_BattTrans.byBattDataBuff1[0];

					// Set event to update capacity/temp
					local_NewData(1);

					// Setup config write
					g_BattTrans.byBattChipAddr1 = MPA2TEMP;  // Set MPA2 temp chip address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = 1; // Set shutdown bit in config register
					g_BattTrans.byBattDataSize1 = 1;
					g_BattTrans.byBattDataBuff1[0] = 1; // Shutdown is bit 0

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						// Set next state
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Do temp read2\n"));  // Show battery data if needed
						dwWrBattMode = WR_MODE_STOP_TEMP;  // Wait for read done
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't do temp read\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
					}
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad temp read write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: temp read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_STOP_TEMP:
			// Temp config write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle

				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad config write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: config write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_DB1:
			// LB read done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: LB read done\n"));  // Show battery data if needed
				}
				else
				{  // Bad read
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad LB read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					break;
				}
				// Drop thru to check the block
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: LB read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					break;
				}

				// Try again
				break;
			}

			// Read block, validate ID
			MovI2Cdata(g_BattTrans.byBattDataBuff1,buf,Key2,0); // Get data

			for (dwCnt = 0, CSum = 0; dwCnt < 15; ++dwCnt)  // Check checksum
			{
				CSum = CSum + buf[dwCnt];
			}
			if (CSum) // Bad checksum?
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad lb checksum\n"));
				// Invalidate the battery
				Pointers->BatteryType = GB_INVALID; // Set to "Invalid" battery
				local_InvalidBattery(CHG_COMM_ERROR);  // Invalidate battery
				g_dwDoChgAcc = false; // Stop charge accumulation
				CancelAccess(); // Stop any battery I/O
				GasGauge(1);  // Reset gas gauging
				local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				ResetRateLimit();
				break;
			}

			// Check ID
			for (dwCnt = 0; dwCnt < 14; ++dwCnt)  // loop thru block data
			{
				if (dwCnt < 8)
				{ // Check ID
					if (g_GiftedBattData.Dyn1Block[0].CopiedManufactureID[dwCnt] != buf[dwCnt])
					{ // Had an error, battery was swapped
						RETAILMSG(ZONE_ERROR, ("PM_Proc: MID Missmatch!!!\n"));
						// Invalidate the battery
						Pointers->BatteryType = GB_INVALID; // Set to "Invalid" battery
						local_InvalidBattery(CHG_COMM_ERROR);  // Invalidate battery
						g_dwDoChgAcc = false; // Stop charge accumulation
						CancelAccess(); // Stop any battery I/O
						GasGauge(1);  // Reset gas gauging
						local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						ResetRateLimit();
						break;
					}
				}
				else
				{ // Check for zero
					if (g_GiftedBattData.DummyData[dwCnt-8])
					{
						RETAILMSG(ZONE_ERROR,("PM_Proc: Bad lb data\n"));
						// Invalidate the battery
						Pointers->BatteryType = GB_INVALID; // Set to "Invalid" battery
						local_InvalidBattery(CHG_COMM_ERROR);  // Invalidate battery
						g_dwDoChgAcc = false; // Stop charge accumulation
						CancelAccess(); // Stop any battery I/O
						GasGauge(1);  // Reset gas gauging
						local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						ResetRateLimit();
						break;
					}
				}
			}

			if (14 > dwCnt)
				break;  // ID did not check out, don't do the write!!!

			// looks OK, do the update!
			g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr;  // Set EEPROM address and write
			g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
			g_BattTrans.byBattChipAddr2 = 0; // No second transaction
			g_BattTrans.byBattDataAddr1 = Addr; // Start of dynamic block
			g_BattTrans.byBattDataSize1 = GB_DYN_BLK_SIZE; // Size of dynamic block

			// Calculate checksum
			CSum = 0;
			cpnt = (uint8_t *)&g_GiftedBattData.Dyn1Block[0];
			for (dwCnt = 0; dwCnt < 14; ++dwCnt)
			{
				CSum = CSum + *(cpnt+dwCnt);
			}
			CSum = ~CSum + 1;
			*(cpnt+dwCnt) = CSum;

			// Copy over data
			MovI2Cdata(cpnt,g_BattTrans.byBattDataBuff1,Key1,1);

			if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
			{  // Set next state
				RETAILMSG(SHOW_COM_STATES, ("PM_Proc: DB write\n"));  // Show battery data if needed
				dwWrBattMode = WR_MODE_DB2;  // Setup next state
				dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
			}
			else  // No good, give up.
			{
				RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start battery DB write\n"));
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				++g_dwBattCommErrCnt; // Increment comm error counter
			}
			break;

		case WR_MODE_DB2:
			// DB write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// All done
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: DB write %d done\n",((g_BattTrans.byBattDataAddr1 - GB_DYN_BLK1_ADD) / 16) + 1));  // Show battery data if needed
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad DB write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: DB write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_HEALTH:
			// DB write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					// All done
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Health write %d done\n",((g_BattTrans.byBattDataAddr1 - GB_DYN_BLK1_ADD) / 16) + 1));  // Show battery data if needed
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad health write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: health write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_Auth:
			// VT write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// All done
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Auth write done\n"));
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad Auth write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Auth write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_IT:
			// Inital times write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// All done
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Auth write done\n"));
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad Auth write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bWriteIT = true;  // Trigger initial time update again
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Auth write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bWriteIT = true;  // Trigger initial time update again
				}
			}
			break;

		case WR_MODE_TC:
			// TC write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					// All done
					if (false == bWhichTC)  // Check which area to use
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: TC2 write done\n"));
					}
					else
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: TC1 write done\n"));
					}
				}
				else
				{  // Bad write
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad TC write\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: TC write timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case WR_MODE_REGS:
			// Read done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				// Get results
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
/* Moved to after check for valid capacity to not
   lose counts of I2C data errors
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;
*/

					// Check results
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Register read done\n"));  // Show battery data if needed

					switch (g_BattType)
					{
					case BATT_Z561: // Do Z561 GG read
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle

						// Copy over data
						memcpy((void *)(&g_GiftedV2Data.CONTROL_STATUS),g_BattTrans.byBattDataBuff1,0x20);
						memcpy((void *)(&g_GiftedV2Data.MLTTE),g_BattTrans.byBattDataBuff2,0x1e);

						RETAILMSG(SHOW_CAL, ("Z561 Status: %04X\n",g_GiftedV2Data.CONTROL_STATUS));

						// Display GG data (if needed)
						if (DUMP_GG_DATA)
						{  // Do data dump!
							uint32_t dwCnt1, dwTmp, dwCnt2;
							char cMsg[240];
							uint8_t *Buff = (uint8_t *)&g_GiftedV2Data.AR;

							cMsg[0] = 0;
							for (dwCnt1 = 0, dwCnt2 = 0; dwCnt1 < 0x3e; dwCnt1 += 2, dwCnt2 += 5)
							{
								dwTmp = Buff[dwCnt1+1];
								dwTmp = (dwTmp << 8) | Buff[dwCnt1];
								local_sprint(cMsg+dwCnt2,200-dwCnt2,"%04X,", dwTmp);
							}

							RETAILMSG(1, ("PM_Proc: NGG Data Dump: %s END_DUMP\n",cMsg));
							g_bGotStatus = true;  // Set flag saying we updated the status register
						}

						DataChanged = 0;  // Clear data updated flag

						// Convert temp
						if (g_GiftedV2Data.TEMP < 2032 || g_GiftedV2Data.TEMP > 3732) // Out of range (-70C to +100C), set to invalid
						{
							Pointers->CurTemp =  NO_BATT_TEMP;
							DataChanged = 0;
							// Bad temp, comm error
							RETAILMSG(1, ("PM_Proc: Bad NGG temp\n"));
							++g_dwBattCommErrCnt; // Increment comm error counter
						}
						else
						{  // Convert to deg C
							tmp = (int16_t)g_GiftedV2Data.TEMP - 2732;  // Convert to .1 deg C
							tmp = tmp / 10;  // Convert to deg C

							if (Pointers->CurTemp != tmp)  // Did temp change?
							{
								DataChanged = 1;
								Pointers->CurTemp = tmp; // Set new temp
							}

							// Check for OK temp change, comm error if wacky
							if (NO_TEMP_YET == LastGGTmp) // Got a temp yet?
							{ // Nope
								LastGGTmp = tmp; // Grab current temp
							}
							else
							{ // Yes
								if (abs(LastGGTmp - tmp) > WACKY_TEMP_CHANGE) // Too big a shift?
								{ // Yes
									RETAILMSG(1, ("PM_Proc: Wacky temp change\n"));
									DataChanged = 0;
									++g_dwBattCommErrCnt; // Increment comm error counter
								}
								else
								{ // Nope
									LastGGTmp = tmp; // Grab current temp for next check
								}
							}
						}

						if (g_GiftedV2Data.VOLT < MIN_OK_VOLTAGE || g_GiftedV2Data.VOLT > MAX_OK_VOLTAGE) // Wacky voltage?
						{ // Yes
							RETAILMSG(1, ("PM_Proc: Wacky voltage\n"));
							++g_dwBattCommErrCnt; // Increment comm error counter
							goto END_WR_MODE_REGS;
							break;
						}

						// Update voltage and current
						Pointers->Voltage = g_GiftedV2Data.VOLT;
						Pointers->Current = g_GiftedV2Data.AI;

						if (Pointers->CycleCount != g_GiftedV2Data.CC)  // Did cycle count change?
						{
							DataChanged = 1;
							Pointers->TotalAccChargeAll = g_GiftedV2Data.CC * g_GiftedV2Data.DCAP; // Save charge from all devices
							Pointers->CycleCount = Pointers->TotalAccChargeAll / g_GiftedV2Data.ManfCapacity_ma;
						}

						// Check for capacity wacky (I2C error causes 0Xffff capacity)
						if (g_GiftedV2Data.RSOC > 100)
						{
							RETAILMSG(1, ("PM_Proc: Capacity out of range!\n"));
							g_GiftedV2Data.RSOC = g_dwCapacity; // Use last capacity
							++g_dwBattCommErrCnt;  // Add a comm error
						}
						else if (g_dwBattCommErrCnt > 0) // Cap OK, drop error counter
							--g_dwBattCommErrCnt;

						// Use dummy capacity if needed
						if (Pointers->OverrideCapacity > 0 && Pointers->OverrideCapacity <= 100)
							g_GiftedV2Data.RSOC = Pointers->OverrideCapacity;

						// Check for using the capacity rate limiter, and also not charging
						if (0 != Pointers->dwSecsPerPer && BM_CHARGER_DISABLED_STATE_NUM == g_dwChargerState)
						{  // Yup, doing rate limit
							if (g_GiftedV2Data.RSOC <= g_dwCapacity || BL_UNKNOWN == g_dwCapacity)  // Check for lower than last cap, or no last cap
							{ // Going down
								// Reset Secs-Percent counter
								dwRateLimitStart = local_GetCurrTime();
								// Reset "added" capacity
								dwAdded = 0;
							}
							else
							{ // Going up
								// Can we go up yet?
								dwAdd = (local_GetTimeSince(dwRateLimitStart) / Pointers->dwSecsPerPer) - dwAdded;
								dwAdded += dwAdd;  // Save new increase so we don't add it in again
								g_GiftedV2Data.RSOC = g_dwCapacity + (int)dwAdd;
							}
						}
						else  // Using current capacity
						{
							// Reset Secs-Percent counter
							dwRateLimitStart = local_GetCurrTime();
							// Reset "added" capacity
							dwAdded = 0;
						}

						// Check for using the capacity falling rate limiter, and also not charging
						if (0 != Pointers->dwSecsPerPerF && BM_CHARGER_DISABLED_STATE_NUM == g_dwChargerState)
						{  // Yup, doing rate limit
							if (g_GiftedV2Data.RSOC >= g_dwCapacity || BL_UNKNOWN == g_dwCapacity)  // Check for higher than last cap, or no last cap
							{ // Going up
								// Reset Secs-Percent counter
								dwRateLimitStartF = local_GetCurrTime();
								// Reset "subed" capacity
								dwSubed = 0;
							}
							else
							{ // Going down
								// Is the target lower than the warning level, and was it higher?
								if (g_GiftedV2Data.RSOC < Pointers->battUnfaireLevel && g_dwCapacity > Pointers->battUnfaireLevel)
								{ // Yes, jump down, and reset stuff
									g_GiftedV2Data.RSOC = Pointers->battUnfaireLevel; // Set to warning level
									// Reset Secs-Percent counter
									dwRateLimitStartF = local_GetCurrTime();
									// Reset "subed" capacity
									dwSubed = 0;
								}
								else  // Check if we can drop  capacity
								{
									// Can we go down yet?
									dwSub = (local_GetTimeSince(dwRateLimitStartF) / Pointers->dwSecsPerPerF) - dwSubed;
									dwSubed += dwSub;  // Save new decrease so we don't sub it out again
									g_GiftedV2Data.RSOC = g_dwCapacity - (int)dwSub;
								}
							}
						}
						else  // Using current capacity
						{
							// Reset Secs-Percent counter
							dwRateLimitStartF = local_GetCurrTime();
							// Reset "added" capacity
							dwSubed = 0;
						}

						g_dwCapacity = g_GiftedV2Data.RSOC;  // Store final capacity

						// Update capacity
						if (Pointers->battCapacity != g_GiftedV2Data.RSOC)  // Did capacity change?
						{
							DataChanged = 1;
							Pointers->battCapacity = g_GiftedV2Data.RSOC; // Set capacity
						}

						// Set state of health
						if (Pointers->dwPercentThreshold > g_GiftedV2Data.SOH)
						{ // Bad health
							if (Pointers->battHealth != BATT_SOH_UNHEALTHY)  // Did health change?
							{
								DataChanged = 1;
								Pointers->battHealth = BATT_SOH_UNHEALTHY;
							}
						}
						else
						{ // Good health
							if (Pointers->battHealth != BATT_SOH_HEALTHY)  // Did health change?
							{
								DataChanged = 1;
								Pointers->battHealth = BATT_SOH_HEALTHY;
							}
						}

						// Save health percentage
						if (Pointers->SOH != g_GiftedV2Data.SOH) // Did health percentage change?
						{
							DataChanged = 1;
							Pointers->SOH = g_GiftedV2Data.SOH;
						}

						// Update TTE/TTF/ARTTE
						if (Pointers->TTE != g_GiftedV2Data.TTE  // Any changes?
							|| Pointers->TTF != g_GiftedV2Data.TTF
							|| Pointers->ARTTE != g_GiftedV2Data.ARTTE)
						{
							DataChanged = 1;
							Pointers->TTE = g_GiftedV2Data.TTE;
							Pointers->TTF = g_GiftedV2Data.TTF;
							Pointers->ARTTE = g_GiftedV2Data.ARTTE;
						}

						// Update Valid QMAX cycles
						Pointers->QVC = g_GiftedV2Data.CC - g_GiftedV2Data.QVC;

						// Update flags
						Pointers->Flags = g_GiftedV2Data.BATTERYSTATUS;

						// Update capacites
						if (Pointers->RM != g_GiftedV2Data.RM   // Any changes?
							|| Pointers->FCC != g_GiftedV2Data.FCC)

						{
							DataChanged = 1;
							Pointers->RM = g_GiftedV2Data.RM;
							Pointers->FCC = g_GiftedV2Data.FCC;
						}

						// Set event to update capacity/level
						local_NewData(DataChanged);

						// Check for updated AtRate value
						if (g_GiftedV2Data.AR != Pointers->dwAtRate)
						{ // New value, start the update
							RETAILMSG(SHOW_COM_STATES, ("PM_Proc: AR Write\n"));  // Show battery data if needed

							// Setup write of AR
							g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
							g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
							g_BattTrans.byBattChipAddr2 = 0; // No second transaction
							g_BattTrans.byBattDataAddr1 = AR_CMD; // AtRate()
							g_BattTrans.byBattDataBuff1[0] = Pointers->dwAtRate & 0xff;
							g_BattTrans.byBattDataBuff1[1] = (Pointers->dwAtRate >> 8) & 0xff;
							g_BattTrans.byBattDataSize1 = 2; // 2 bytes

							if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
							{  // Set next state
								dwWrBattMode = WR_AT_RATE_DONE;  // Setup next state
								dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
							}
							else  // No good, give up.
							{
								RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start AtRate() write\n"));
								dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
								g_GiftedBattData.CONTROL_STATUS = 0xffff; // Set error
								++g_dwBattCommErrCnt; // Increment comm error counter
							}
						}
						break;
					case BATT_M200: // Do M200 GG read
						// Copy over data
						memcpy((uint8_t *)&g_GiftedBattData.AR+RegBytesRead,g_BattTrans.byBattDataBuff1,g_BattTrans.byBattDataSize1);
						RegBytesRead += g_BattTrans.byBattDataSize1; // Add in the current bytes

						// Are we done?
						if (RegBytesRead < GB_CMD_FULL_READ_SIZE)
						{ // No, read more bytes
							g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set gas gauge address and read
							g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
							g_BattTrans.byBattChipAddr2 = 0; // No second transaction
							g_BattTrans.byBattDataAddr1 = AR_CMD+RegBytesRead; // Start read at current address

							// Read next chunk of registers
							if ((RegBytesRead+GB_CMD_PARTIAL_READ_SIZE) > GB_CMD_FULL_READ_SIZE)  // Going too far?
							{ // Yes, do smaller read
								g_BattTrans.byBattDataSize1 = GB_CMD_FULL_READ_SIZE - RegBytesRead;
							}
							else
							{ // No, read size is OK
								g_BattTrans.byBattDataSize1 = GB_CMD_PARTIAL_READ_SIZE;
							}

							if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
							{
								RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Start GG register read\n"));  // Show battery data if needed
								dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
							}
							else  // No good, give up.
							{
								RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start register read4\n"));
								dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
								++g_dwBattCommErrCnt; // Increment comm error counter
							}
							goto END_WR_MODE_REGS;
							break;
						}

						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle

						// Display GG data (if needed)
						if (DUMP_GG_DATA)
						{  // Do data dump!
							uint32_t dwCnt1, dwTmp, dwCnt2;
							char cMsg[200];
							uint8_t *Buff = (uint8_t *)&g_GiftedBattData.AR;

							cMsg[0] = 0;
							for (dwCnt1 = 0, dwCnt2 = 0; dwCnt1 < GB_CMD_FULL_READ_SIZE; dwCnt1 += 2, dwCnt2 += 5)
							{
								dwTmp = Buff[dwCnt1+1];
								dwTmp = (dwTmp << 8) | Buff[dwCnt1];
								local_sprint(cMsg+dwCnt2,200-dwCnt2,"%04X,", dwTmp);
							}

							RETAILMSG(1, ("PM_Proc: GG Data Dump: %s%04X,%04X,END_DUMP\n"
								,cMsg,g_GiftedBattData.QMAX_DAY,g_GiftedBattData.CONTROL_STATUS));
						}

						DataChanged = 0;  // Clear data updated flag

						// Convert temp
						if (g_GiftedBattData.TEMP < 2032 || g_GiftedBattData.TEMP > 3732) // Out of range (-70C to +100C), set to invalid
						{
							Pointers->CurTemp =  NO_BATT_TEMP;
							DataChanged = 0;
							// Bad temp, try resetting gauge
							RETAILMSG(1, ("PM_Proc: Reset GG1\n"));
							BattDetectReset();
							goto END_WR_MODE_REGS;
							break;
						}
						else
						{  // Convert to deg C
							tmp = (int16_t)g_GiftedBattData.TEMP - 2732;  // Convert to .1 deg C
							tmp = tmp / 10;  // Convert to deg C

							if (Pointers->CurTemp != tmp)  // Did temp change?
							{
								DataChanged = 1;
								Pointers->CurTemp = tmp; // Set new temp
							}

							// Check for OK temp change, reset GG if wacky
							if (NO_TEMP_YET == LastGGTmp) // Got a temp yet?
							{ // Nope
								LastGGTmp = tmp; // Grab current temp
							}
							else
							{ // Yes
								if (abs(LastGGTmp - tmp) > WACKY_TEMP_CHANGE) // Too big a shift?
								{ // Yes
									RETAILMSG(1, ("PM_Proc: Reset GG2\n"));
									DataChanged = 0;
									BattDetectReset();
									goto END_WR_MODE_REGS;
									break;
								}
								else
								{ // Nope
									LastGGTmp = tmp; // Grab current temp for next check
								}
							}
						}

						if (g_GiftedBattData.VOLT < MIN_OK_VOLTAGE || g_GiftedBattData.VOLT > MAX_OK_VOLTAGE) // Wacky voltage?
						{ // Yes
							RETAILMSG(1, ("PM_Proc: Reset GG3\n"));
							DataChanged = 0;
							BattDetectReset();
							goto END_WR_MODE_REGS;
							break;
						}

						// Only do the rest if we have a valid M200 battery
						if (BATT_M200 != g_BattType)
						{
							local_NewData(DataChanged);
							goto END_WR_MODE_REGS;
							break;
						}

						// Update voltage and current
						Pointers->Voltage = g_GiftedBattData.VOLT;
						Pointers->Current = g_GiftedBattData.AI;

						// Update total charge
						// Check for error on increment of cycles
						if (g_GiftedBattData.Last_CHGCC == g_GiftedBattData.CHGCC || (g_GiftedBattData.Last_CHGCC != g_GiftedBattData.CHGCC && g_GiftedBattData.LCCA < g_GiftedBattData.Last_LCCA))
						{  // Cycle change OK, or no change
							g_dwAggregateCharge = (g_GiftedBattData.CC_Threshold * g_GiftedBattData.CHGCC) + g_GiftedBattData.LCCA;
							g_GiftedBattData.Last_LCCA = g_GiftedBattData.CHGCC && g_GiftedBattData.LCCA;
						}
						else
						{  // Out of sync maHrs, just use zero for now
							g_dwAggregateCharge = g_GiftedBattData.CC_Threshold * g_GiftedBattData.CHGCC;
							g_GiftedBattData.Last_LCCA = 0;
						}
						g_GiftedBattData.Last_CHGCC = g_GiftedBattData.CHGCC; // Save current cycle count

						if (Pointers->CycleCount != g_GiftedBattData.CHGCC)  // Did cycle count change?
						{
							DataChanged = 1;
							Pointers->CycleCount = g_GiftedBattData.CHGCC; // Update cycle count
						}

						// Check for capacity wacky (I2C error causes 0Xffff capacity)
						if (g_GiftedBattData.SOC > 100)
						{
							RETAILMSG(1, ("PM_Proc: Capacity out of range!\n"));
							g_GiftedBattData.SOC = g_dwCapacity; // Use last capacity
							++g_dwBattCommErrCnt;  // Add a comm error
						}
						else if (g_dwBattCommErrCnt > 0) // Cap OK, drop error counter
							--g_dwBattCommErrCnt;

						// Use dummy capacity if needed
						if (Pointers->OverrideCapacity > 0 && Pointers->OverrideCapacity <= 100)
							g_GiftedBattData.SOC = Pointers->OverrideCapacity;

						// Check for using the capacity rate limiter, and also not charging
						if (0 != Pointers->dwSecsPerPer && BM_CHARGER_DISABLED_STATE_NUM == g_dwChargerState)
						{  // Yup, doing rate limit
							if (g_GiftedBattData.SOC <= g_dwCapacity || BL_UNKNOWN == g_dwCapacity)  // Check for lower than last cap, or no last cap
							{ // Going down
								// Reset Secs-Percent counter
								dwRateLimitStart = local_GetCurrTime();
								// Reset "added" capacity
								dwAdded = 0;
							}
							else
							{ // Going up
								// Can we go up yet?
								dwAdd = (local_GetTimeSince(dwRateLimitStart) / Pointers->dwSecsPerPer) - dwAdded;
								dwAdded += dwAdd;  // Save new increase so we don't add it in again
								g_GiftedBattData.SOC = g_dwCapacity + (int)dwAdd;
							}
						}
						else  // Using current capacity
						{
							// Reset Secs-Percent counter
							dwRateLimitStart = local_GetCurrTime();
							// Reset "added" capacity
							dwAdded = 0;
						}

						// Check for using the capacity falling rate limiter, and also not charging
						if (0 != Pointers->dwSecsPerPerF && BM_CHARGER_DISABLED_STATE_NUM == g_dwChargerState)
						{  // Yup, doing rate limit
							if (g_GiftedBattData.SOC >= g_dwCapacity || BL_UNKNOWN == g_dwCapacity)  // Check for higher than last cap, or no last cap
							{ // Going up
								// Reset Secs-Percent counter
								dwRateLimitStartF = local_GetCurrTime();
								// Reset "subed" capacity
								dwSubed = 0;
							}
							else
							{ // Going down
								// Is the target lower than the warning level, and was it higher?
								if (g_GiftedBattData.SOC < Pointers->battUnfaireLevel && g_dwCapacity > Pointers->battUnfaireLevel)
								{ // Yes, jump down, and reset stuff
									g_GiftedBattData.SOC = Pointers->battUnfaireLevel; // Set to warning level
									// Reset Secs-Percent counter
									dwRateLimitStartF = local_GetCurrTime();
									// Reset "subed" capacity
									dwSubed = 0;
								}
								else  // Check if we can drop  capacity
								{
									// Can we go down yet?
									dwSub = (local_GetTimeSince(dwRateLimitStartF) / Pointers->dwSecsPerPerF) - dwSubed;
									dwSubed += dwSub;  // Save new decrease so we don't sub it out again
									g_GiftedBattData.SOC = g_dwCapacity - (int)dwSub;
								}
							}
						}
						else  // Using current capacity
						{
							// Reset Secs-Percent counter
							dwRateLimitStartF = local_GetCurrTime();
							// Reset "added" capacity
							dwSubed = 0;
						}

						g_dwCapacity = g_GiftedBattData.SOC;  // Store final capacity

						// Update capacity
						if (Pointers->battCapacity != g_GiftedBattData.SOC)  // Did capacity change?
						{
							DataChanged = 1;
							Pointers->battCapacity = g_GiftedBattData.SOC; // Set capacity
						}

						// Set state of health
						if (Pointers->dwPercentThreshold > g_GiftedBattData.SOH)
						{ // Bad health
							if (Pointers->battHealth != BATT_SOH_UNHEALTHY)  // Did health change?
							{
								DataChanged = 1;
								Pointers->battHealth = BATT_SOH_UNHEALTHY;
							}
						}
						else
						{ // Good health
							if (Pointers->battHealth != BATT_SOH_HEALTHY)  // Did health change?
							{
								DataChanged = 1;
								Pointers->battHealth = BATT_SOH_HEALTHY;
							}
						}

						// Save health percentage
						if (Pointers->SOH != g_GiftedBattData.SOH) // Did health percentage change?
						{
							DataChanged = 1;
							Pointers->SOH = g_GiftedBattData.SOH;
						}

						// Update secs since first use
						Pointers->dwSecSinceFirstUse = ((uint32_t)g_GiftedBattData.ETU << 16) | (uint32_t)g_GiftedBattData.ETL;

						// Update TTE/TTF/ARTTE
						if (Pointers->TTE != g_GiftedBattData.TTE  // Any changes?
							|| Pointers->TTF != g_GiftedBattData.TTF
							|| Pointers->ARTTE != g_GiftedBattData.ARTTE)
						{
							DataChanged = 1;
							Pointers->TTE = g_GiftedBattData.TTE;
							Pointers->TTF = g_GiftedBattData.TTF;
							Pointers->ARTTE = g_GiftedBattData.ARTTE;
						}

						// Update Valid QMAX cycles
						Pointers->QVC = g_GiftedBattData.QVC;

						// Update flags
						Pointers->Flags = g_GiftedBattData.FLAGS;

						// Update capacites
						if (Pointers->RM != g_GiftedBattData.RM   // Any changes?
							|| Pointers->FCC != g_GiftedBattData.FCC)

						{
							DataChanged = 1;
							Pointers->RM = g_GiftedBattData.RM;
							Pointers->FCC = g_GiftedBattData.FCC;
						}

						// Set event to update capacity/level
						local_NewData(DataChanged);

						// Check for updated AtRate value
						if (g_GiftedBattData.AR != Pointers->dwAtRate)
						{ // New value, start the update
							// Setup read of CONTROL_STATUS
							g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
							g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
							g_BattTrans.byBattChipAddr2 = 0; // No second transaction
							g_BattTrans.byBattDataAddr1 = AR_CMD; // AtRate()
							g_BattTrans.byBattDataBuff1[0] = Pointers->dwAtRate & 0xff;
							g_BattTrans.byBattDataBuff1[1] = (Pointers->dwAtRate >> 8) & 0xff;
							g_BattTrans.byBattDataSize1 = 2; // 2 bytes

							if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
							{  // Set next state
								dwWrBattMode = WR_AT_RATE_DONE;  // Setup next state
								dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
							}
							else  // No good, give up.
							{
								RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start AtRate() write\n"));
								dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
								g_GiftedBattData.CONTROL_STATUS = 0xffff; // Set error
								++g_dwBattCommErrCnt; // Increment comm error counter
							}
						}
						else
						{ // Same value, all done
							dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						}
						break;
					default:
						local_print("PM_Batt: Unknown type in WR_MODE_REGS: %d\n",g_BattType);
						break;
					}
				}
				else
				{  // Bad read
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad registers read\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Registers read timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
END_WR_MODE_REGS:
			break;

		case WR_AT_RATE_DONE:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad WR_AT_RATE\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: WR_AT_RATE Timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;

		case RD_QMAX_DAY_NGG1:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Check block transfer
					if (BlockReadCheck(NGG_QMAX_DAY,g_BattTrans.byBattDataBuff2) != 6)
					{
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Qmax day block error\n"));  // Show battery data if needed
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_bGotQMAX_DAY = true; // Return error
						g_GiftedV2Data.QMAX_DAY = 0xffff;
						break;
					}
					else
					{
						// Lower error counter
						if (g_dwBattCommErrCnt > 0)
							--g_dwBattCommErrCnt;
					}

					// Copy over data
					memcpy((void *)((uint8_t *)(&g_GiftedV2Data.QMAX_DAY)),g_BattTrans.byBattDataBuff2+2,2);
					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Read QMAX_DAY1 done\n"));  // Show battery data if needed

					// Start read of firmware run time
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_FW_RT & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_FW_RT >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Qmax day read2\n"));  // Show battery data if needed
						dwWrBattMode = RD_QMAX_DAY_NGG2;  // Get data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR, ("PM_Proc: Can't start Qmax day read2\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_bGotQMAX_DAY = true; // Return error
						g_GiftedV2Data.QMAX_DAY = 0xffff;
					}

				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad QMAX_DAY read1\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedBattData.QMAX_DAY = 0xffff;
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: QMAX_DAY Read1 Timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedV2Data.QMAX_DAY = 0xffff;
				}
			}
			break;

		case RD_QMAX_DAY_NGG2:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Check block transfer
					if (BlockReadCheck(NGG_FW_RT,g_BattTrans.byBattDataBuff2) != 8)
					{
						RETAILMSG(ZONE_ERROR, ("PM_Proc: Qmax day block error2\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_bGotQMAX_DAY = true; // Return error
						g_GiftedV2Data.QMAX_DAY = 0xffff;
						break;
					}

					// Copy over data
					memcpy((void *)((uint8_t *)(&g_GiftedV2Data.FW_RT)),g_BattTrans.byBattDataBuff2+2,4);
					g_bGotQMAX_DAY = true;  // Set Flag

					// Update QMAX_DAYS
					dwCnt = (g_GiftedV2Data.FW_RT/3600/24); // Get current number of days
					// Is Qmax day > current day? (In the future? Can happen after GG firmware update)
					if (g_GiftedV2Data.QMAX_DAY > dwCnt)
						Pointers->QMAX_DAYS = 100; // Set to overdue for a calibration
					else
						Pointers->QMAX_DAYS = dwCnt - g_GiftedV2Data.QMAX_DAY; // Set to real value
					// Check for calibration needed
					if (g_GiftedV2Data.Cal.MaxRecalDays > 0 &&  Pointers->QMAX_DAYS >= g_GiftedV2Data.Cal.MaxRecalDays)
						if (CAL_IN_PROGRESS != Pointers->GG_Cal) // Check not already doing cal cycle
							Pointers->GG_Cal = CAL_IS_NEEDED; // Flag that we need a cal cycle

					RETAILMSG(SHOW_CAL, ("PM_Proc: Read QMAX_DAY2 done: %d  %d  %d\n",g_GiftedV2Data.FW_RT,g_GiftedV2Data.QMAX_DAY,Pointers->QMAX_DAYS));  // Show battery data if needed
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad QMAX_DAY read2\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedV2Data.QMAX_DAY = 0xffff;
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: QMAX_DAY Read Timeout2\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedV2Data.QMAX_DAY = 0xffff;
				}
			}
			break;

		case RD_QMAX_DAY1:  // Setup read of QMAX_DAY
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					// Start read of QMAX_DAY
					// Setup I2C structure
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						dwWrBattMode = RD_QMAX_DAY2;  // Setup next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR, ("PM_Batt: Can't start QMAX_DAY read1\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_bGotQMAX_DAY = true; // Return error
						g_GiftedBattData.QMAX_DAY = 0xffff;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad QMAX_DAY read1\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedBattData.QMAX_DAY = 0xffff;
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: QMAX_DAY Read Timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedBattData.QMAX_DAY = 0xffff;
				}
			}
			break;

		case RD_QMAX_DAY2:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					// All done
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle

					RETAILMSG(SHOW_COM_STATES, ("PM_Proc: Read QMAX_DAY done\n"));  // Show battery data if needed

					// Copy over data
					memcpy((void *)(&g_GiftedBattData.QMAX_DAY),g_BattTrans.byBattDataBuff1,2);

					g_bGotQMAX_DAY = true;  // Set Flag

					// Update QMAX_DAYS
					Pointers->QMAX_DAYS = g_GiftedBattData.QMAX_DAY - (Pointers->dwSecSinceFirstUse/3600/24);
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad QMAX_DAY read2\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedBattData.QMAX_DAY = 0xffff;
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: QMAX_DAY Read Timeout1\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_bGotQMAX_DAY = true; // Return error
					g_GiftedBattData.QMAX_DAY = 0xffff;
				}
			}
			break;

		case RD_CONTROL_STATUS1:  // Setup read of control status register
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					// Start read of CONTROL_STATUS
					// Setup I2C structure
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						dwWrBattMode = RD_CONTROL_STATUS2;  // Setup next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR, ("PM_Batt: Can't start CONTROL_STATUS read1\n"));
						dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
						++g_dwBattCommErrCnt; // Increment comm error counter
						g_GiftedBattData.CONTROL_STATUS = 0xffff; // Return error
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad CONTROL_STATUS read1\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedBattData.CONTROL_STATUS = 0xffff; // Return error
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: CONTROL_STATUS Read Timeout\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedBattData.CONTROL_STATUS = 0xffff; // Return error
				}
			}
			break;

		case RD_CONTROL_STATUS2:
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
				{
					// Lower error counter
					if (g_dwBattCommErrCnt > 0)
						--g_dwBattCommErrCnt;

					// Check results
					// All done
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle

					// Copy over data
					memcpy((void *)(&g_GiftedBattData.CONTROL_STATUS),g_BattTrans.byBattDataBuff1,2);
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR, ("PM_Proc: Bad CONTROL_STATUS read2\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedBattData.CONTROL_STATUS = 0xffff; // Return error
				}
			}
			else  // Not done yet
			{
				// Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					RETAILMSG(ZONE_ERROR, ("PM_Batt: CONTROL_STATUS Read Timeout1\n"));
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
					++g_dwBattCommErrCnt; // Increment comm error counter
					g_GiftedBattData.CONTROL_STATUS = 0xffff; // Return error
				}
			}
			break;

		case WR_MODE_BM1:
			dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
			break;

		case WR_MODE_TOSS:
			// DB write done?
			if (g_BattTrans.hCommCmpltEvnt)  // Done yet??
			{
				dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
			}
			else
			{  // Been too long?
				if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
				{ // Too long!
					dwWrBattMode = WR_MODE_IDLE;  // Back to Idle
// Should not be an error					++g_dwBattCommErrCnt; // Increment comm error counter
				}
			}
			break;
		}

		// Check for battery comm errors
		if (g_dwBattCommErrCnt > 5)
		{ // Too many errors
			RETAILMSG(ZONE_ERROR, ("PM_Proc: Too many battery comm errors!!!\n"));

			if (g_dwChargerState != BM_CHARGER_DISABLED_STATE_NUM) // Are we charging?
			{ //Yes
				ChargerInit();  // Reset charger stuff
				local_ErrorCharger();  // Error charger
			}

			// Invalidate the battery
			Pointers->BatteryType = GB_INVALID; // Set to "Invalid" battery
			local_InvalidBattery(CHG_COMM_ERROR);  // Invalidate battery
			g_dwDoChgAcc = false; // Stop charge accumulation
			GasGauge(1);  // Reset gas gauging
			CancelAccess(); // Stop any battery I/O
			local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
		}
	}

	if (dwWrBattMode == WR_MODE_IDLE && (false != g_bHibernate     // Stuff pending to do
						|| false != bWriteTC || false != g_bReadMPA3Regs
						|| false != g_bUpdateBM || false != g_bWriteDB1 || false != g_bWriteDB2
						|| false != g_bWriteDB3 || false != g_bWriteDB4
						|| false != g_bWriteMPA2Health || false != g_bReadMPA3Health
						|| false != g_bReadQMAX_DAY || false != g_bReadCONTROL_STATUS
						|| false != g_bReadTempChip || false != g_bWriteVTAC1 || false != g_bWriteVTAC2
						|| false != g_bWriteVTH1 || false != g_bWriteVTH2
						|| false != g_bWriteNGG_AC1 || false != g_bWriteNGG_AC2
						|| false != g_bWriteIT || false != g_bWriteHD
						|| false != g_bUTSFU || false != g_bGaugingStatus
						|| false != g_bITStatus2 || false != g_bITStatus3))
	{ // yes do a quick delay
		Delay = FAST_LOOP / 2; // Yes use 1/2 second delay
	}

	RETAILMSG(ZONE_FUNCTION,("BattMan: PM_Tick Exit\n"));
	return (Delay);
}

//------------------------------------------------------------------------------
//
//  Function:  PM_Suspend()
//
//  Prepares the PM code for a suspend
//
void PM_Suspend(void)
{
	CancelAccess();  // Shutdown write state machine
	dwWrBattMode = WR_MODE_TOSS;
	bWhichTC = false;  // Set to first area
//	ChargerInit();  // Reset charger state machine

	RETAILMSG(ZONE_FUNCTION, ("PM_Suspend\n"));

	// Check for battery detection in progress
	if (g_dwBattDetectState != BATT_DET_IDLE)
		g_dwHadInvalidBattery = 1; // Doing a detect, mark as had invalid battery on suspend
	else  // Not doing detect, normal suspend
		g_dwHadInvalidBattery = Pointers->BatteryIsInvalid; // Save if we had a valid battery

	g_dwBattDetectRestartState = BATT_DET_RESTART;  // Set detect machine to spin till we come back up
	g_dwBattDetectState = BATT_DET_RESTART;

	// Don't call InvalidBattery() here. We don't want to set any events on a suspend.
	Pointers->BatteryIsInvalid = BM_BATTERY_UNKNOWN;  // Invalidate battery
	g_OldBattType = g_BattType; // Save current battery type
	g_BattType = BATT_NONE; // No battery type now

	// Save battery capacity for use on resume
	// Make sure it's above the minimum
	if (Pointers->battCapacity <= (Pointers->battLowLevel * Pointers->dwAdjustPer / 100))
		Pointers->battCapacity = (Pointers->battLowLevel * Pointers->dwAdjustPer / 100) + 1;

	Pointers->dwBatteryLevel = BL_UNKNOWN;

/* ***FIX***
	g_dwVoltageValid = FALSE;  // Set back to invalid voltage

    g_cCurTemp = NO_BATT_TEMP; // Set to error temp
*/
}

//------------------------------------------------------------------------------
//
//  Function:  PM_Resume()
//
//  Restarts the PM code after a suspend
//
void PM_Resume(void)
{
	RETAILMSG(ZONE_FUNCTION, ("PM_Resume\n"));

	if (CHG_NO_ERROR == g_dwHadInvalidBattery) // Had a valid battery?
	{  // Yes
		g_dwBattDetectRestartState = BATT_DET_GET_ID1;  // Check for same battery
		g_dwBattDetectAfterResetState = BATT_DET_START; // Start over after a GG reset
		dwWrBattMode = WR_MODE_IDLE;
		BattDetectResume();
	}
	else
	{ // Nope, just do a regular start looking.
		RETAILMSG(ZONE_ERROR, ("PM_Resume: Had bad battery\n"));
		BattDetectStart();
	}

	GasGauge(1);  // Reset gas gauging
	ResetRateLimit();

/*  ***FIX*** Do we need the rest of this???
	g_bSampleArrayFull = FALSE;  // Set flag to indicate sample array not full

	// Set event to reset the battery drivers data
	g_dwEventCauses = PM_EVENT_RESUME | PM_EVENT_POWER_STATUS;
	SetEvent(hPM_Event);
*/
}

//------------------------------------------------------------------------------
//
//  Function:  HibernateBatt()
//
//  Put the GG into hibernate mode
//
uint32_t HibernateBatt(void)
{
	// Check for GG batt
	if (BATT_M200 == g_BattType)
	{
		// Start hibernate process
		g_bHibernate = true;
		return (0);
	}
	else
		return (1);
}

// Function to reset the capacity rate limter
void ResetRateLimit(void)
{
	g_dwCapacity = BL_UNKNOWN;  // Clear capacity filter
	dwAdded = 0;
	dwSubed = 0;
}
