#ifndef BATTMAN_H
#define BATTMAN_H

#include <ZebraAuth/ZebraAuth.h>
#include <GiftedBattery/GiftedBattery.h>
#include "../GiftedBattery/BattMan.h"

int local_print(const char *format, ...);
int local_sprint(char *dest, size_t len, const char *format, ...);

// Battery charger functions
void local_EnableCharger(int Enb);
void local_StopCharger(void);
void local_ErrorCharger(void);
void local_StartChg(void);
void local_StopChg(void);

// Battery driver functions
void local_BatteryFound(u32 NewBatt);
void local_InvalidBattery(u32 Invalid);
void local_NewData(u32 DataChanged);
void local_InHibernate(uint32_t Error);

// Battery voltage/current stuff
int local_GetBatteryVoltage(void);
int local_GetBatteryCurrent(void);
int local_GetBatteryTemp(void);
int local_GetBatteryCapacity(void);

// I2C routines
int local_EA_BattTransaction(LP_BATTERY_TRANSACTION trans);
int local_EA_BattTransresult(LP_BATTERY_TRANSACTION trans);

// Time stuff
long local_GetStopTime(unsigned long Delay);
u64 local_GetCurrTime(void);
u64 local_GetTimeSince(u64 StartTime);
int local_PastTime(unsigned long StopTime);
int local_GetDate(uint16_t *Month, uint16_t *Day, uint16_t *Year);

extern struct BattManPointers *Pointers;

// Global battery data storage
extern NEW_GIFTED_BATT_DATA_t g_GiftedV2Data;	// Data for V2 PP+ batts
extern VALUE_TIER_BATT_DATA_t g_ValueTierData;	// Data for value tier battery
extern SMART_BATT_DATA_t g_SmartBattData;		// Data for MPA2 smart battery
extern GIFTED_BATT_DATA_t g_GiftedBattData;		// Gifted battery data
extern SHIP_MODE_DATA_t g_ShipModeDefaults;		// Default ship mode data

// Shared data
extern int g_BattType;							// KLM internal battery type
extern int g_OldBattType;						// KLM last good internal battery type
extern BATTERY_TRANSACTION g_BattTrans;			// Battery transaction data
extern unsigned long dwBDStopTime;				// Battery detection stop time
extern uint32_t	g_dwBattDetectState;			// Battery detect state machine state
extern uint32_t	g_dwBattDetectRestartState;		// State to restart detect state machine in
extern uint32_t g_dwBattDetectAfterResetState;	// State to go to after a GG reset
extern u32 g_dwAggregateCharge;		// Total accumulated charge
extern uint16_t g_LastErrorCode;				// Error code for last battery error

// Keys
extern uint8_t *Key1, *Key2;
#endif