//--------------------------------------------------------------------
// FILENAME:	pwm_chrg.c
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	Virtual Power Micro - Charging functions
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

#include <linux/string.h>
#include <linux/types.h>

// #include <GiftedBattery/GiftedBattery.h>
// #include <ZebraAuth/ZebraAuth.h>
// #include "../GiftedBattery/BattMan.h"

#include "pwm.h"
#include "pwm_batt.h"
#include "pwm_chrg.h"
#include "aes.h"
#include "keys.h"
#include "BattMan_main.h"

// Flags
bool WasFullyCharged = false;	// True if battery had been fully charged
bool StartedRecharge = false;	// True if we have started the battery recharging after it got low

// Shared data structure
// extern struct BattManPointers *Pointers;

// Charger state machine stuff
u32 g_dwChargerState = 0;  // Current state of state machine
unsigned long dwMinInt;  // Minute timer stuff
u32 dwMinCnt;
u32 dwWaitGetCap = 0;
uint16_t SOC_Ref = 0;
u32 dwStartDelay = 0;
u32 ChargerPaused = 0;  // Paused charging flag

#define NEARLY_DONE_WAIT	3		// Samples to check for being nearly done
#define USB_DONE_CURR		10		// Minimum current for USB charge done check
#define CHARGE_DETECT_TIME	15000	// Time current must be high to be considered charging
#define CHRG_OFF_TIMEOUT	15		// Seconds battery has to be draining to delcare charger off
#define CHRG_OFF_THRESHOLD	25		// Current in ma below which we are not charging

// Local function prototypes
bool DoCal(void);
void DoM200_ChargerStuff(void);
void DoZ561_ChargerStuff(void);

// Routine init the charger stuff
void ChargerInit(void)
{
	local_EnableCharger(1);  // Restart charger
	local_StopChg(); // Say we are not doing charge

	// Reset flags
	StartedRecharge = false;

	// Reset state machine
	g_dwChargerState = BM_CHARGER_DISABLED_STATE_NUM;
	dwMinInt = 0;
	dwMinCnt = 0;
	dwStartDelay = local_GetStopTime(CHARGE_DETECT_TIME);  // Inital delay to detect charging
	Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
}

// Routine to do charger stuff tick
uint32_t DoChargerStuff(void)
{
	RETAILMSG(ZONE_FUNCTION,("BattMan: Chrg_Tick\n"));

	// Do minute counter if needed
	if (dwMinCnt)
	{
		if (!dwMinInt) // Timing a minute yet?
			dwMinInt = local_GetStopTime(60000);  // Set stop time

		if (local_PastTime(dwMinInt))  // Been a minute yet?
		{
			dwMinInt = local_GetStopTime(60000);  // Restart counter

			if (dwMinCnt > 0)  // Dec 1 min interval counter if needed
				--dwMinCnt;
		}
	}

	switch (g_BattType)
	{
	case BATT_M200:  // M200 GG PP+ batt
		DoM200_ChargerStuff();
		break;
	case BATT_Z561:  // Z561 GG PP+ batt
		DoZ561_ChargerStuff();
		break;
	default:  // Only needed for PP+ batts
		WasFullyCharged = false;
		return (NORM_LOOP);
	}

	if (BM_CHARGER_DISABLED_STATE_NUM == g_dwChargerState)  // Do we need fast loop time?
		return (NORM_LOOP); // Nope
	else
		return (FAST_LOOP); // Yup
}


void DoM200_ChargerStuff(void)
{
	int BattCurrent; // Current current
	uint16_t CurrVolt; // Current voltage
	static int dwCnt1; // Counter
	static u32 dwCnt2 = 0;  // Charger off counter

	CurrVolt = Pointers->Voltage;  // Get current voltage
	BattCurrent =  Pointers->Current;  // Gifted current

	RETAILMSG(SHOW_CHG_STATES,("M200: V: %u C: %d R: %u\n",CurrVolt,BattCurrent,g_GiftedBattData.SOC));


	// Check for not charging and reset state machine
	if (g_dwChargerState != BM_CHARGER_DISABLED_STATE_NUM) // Are we charging?
	{ //Yes
		if (BattCurrent < CHRG_OFF_THRESHOLD)  // Are we draining the battery?
		{ // Yes
			// Check for in a "wait" state
			if (g_dwChargerState != BM_CAL_WAIT1_STATE_NUM && g_dwChargerState != BM_CAL_WAIT2_STATE_NUM)
			{ // Nope
				if (dwCnt2)// Time to quit?
				{ // Not yet
					--dwCnt2; // Dec counter
				}
				else
				{ // Yup
					RETAILMSG(ZONE_ERROR,("Charger_Tick: Draing battery in cal wait state!\n"));
					ChargerInit();  // Reset state machine
				}
			}
			else
			{ // In "wait" state, restart charger
//				dwCnt2 = CHRG_OFF_TIMEOUT; // Reset counter
// Fix for battery draining while in calibration wait state  JEC
				ChargerInit();  // Reset state machine, will restart charger
			}
		}
		else
		{ // Not draining
			dwCnt2 = CHRG_OFF_TIMEOUT; // Reset counter
		}
	}
	else
	{ // Not charging
		dwCnt2 = CHRG_OFF_TIMEOUT; // Reset counter
	}

	RETAILMSG(SHOW_CHG_STATES, ("Charger_State M200: %u, %dma\n",g_dwChargerState,BattCurrent));

	// Do charger state machine
	switch (g_dwChargerState)
	{
	case BM_CHARGER_DISABLED_STATE_NUM: // Disabled
		if (WasFullyCharged && !StartedRecharge)  // Check if we need to restart charging
		{
			// Check if we need to restart charging, OS handles initial start of charging
			if (!(g_GiftedBattData.FLAGS & FLAG_FC))
			{
				RETAILMSG(SHOW_CAL, ("Charger_Tick: Restart charging\n"));
				WasFullyCharged = false;
				local_EnableCharger(1);  // Tell OS to start charging again
				StartedRecharge = true;
			}
		}

		// Check for start of charging
		if (BattCurrent > MIN_CHARGING_CURRENT)  // Enough current to be considered charging?
		{ // Yes
			local_StartChg(); // Say we are starting charging
			if (local_PastTime(dwStartDelay)) // Has it been high long enough?
			{ // Yes
				dwCnt1 = SLOW_FAST_WAIT;
				g_dwChargerState = BM_SLOW_CHG_STATE_NUM;
				StartedRecharge = false;  // Clear started recharge flag

				g_bReadQMAX_DAY = true;
				g_bGotQMAX_DAY = false;
				RETAILMSG(SHOW_CAL, ("Charger_Tick: start QMAX_DAY read\n"));
			}
		}
		else
		{ // Nope
			dwStartDelay = local_GetStopTime(CHARGE_DETECT_TIME);  // Reset 10 second delay to detect charging
			local_StopChg(); // Say we are stoping charge
		}
		break;

		case BM_SLOW_CHG_STATE_NUM:
			if (Pointers->Voltage > Pointers->SlowFastCharge_mV)  // Over slow to fast threshold?
			{
				--dwCnt1;
				if (!dwCnt1)  // OK to go to fast mode?
					g_dwChargerState = BM_WAIT_QMAX_DAY_STATE_NUM;  // Set to check for cal
			}
			else
			{
				dwCnt1 = SLOW_FAST_WAIT; // Reset counter
			}
			break;

		case BM_FAST_CHG_STATE_NUM:		// Used code from USB fast charging state here because we don't know
										// what type of charging source/hardware we have
DoFastChargeState:
		// Check for done USB charging
		if (!(g_GiftedBattData.FLAGS & FLAG_FC)) // Reset was charged flag if needed
			WasFullyCharged = false;
// local_print("Was: %d Done:%d SOC:%d\n",WasFullyCharged,g_GiftedBattData.FLAGS & FLAG_FC,g_GiftedBattData.SOC);
		// Check if we need to stop charging
		// Gas gauge 'done' flag is set if it was cleared to start, or at 100% if it wasn't?
		if ((!WasFullyCharged && (g_GiftedBattData.FLAGS & FLAG_FC)) || (WasFullyCharged && (100 == g_GiftedBattData.SOC)))
		{
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Done charging\n"));
			ChargerInit();  // Reset state machine
			local_StopCharger();  // Tell OS to stop charging
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			WasFullyCharged = true;  // Set was charged flag
		}
		if (Pointers->Voltage > (Pointers->ChargeUp_mV - USB_DONE_VOLT_OFF)) // Voltage high enough to check current?
		{
			// Under done threshold, and over min usb current?
			if (BattCurrent < Pointers->DoneCurrent && BattCurrent > USB_DONE_CURR)
			{
				--dwCnt1;
				if (!dwCnt1)  // OK to go to done?
				{
					// Set to done state and turn off
					ChargerInit();  // Reset state machine
					local_StopCharger();  // Tell OS to stop charging
					Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
					WasFullyCharged = true;  // Set was charged flag
				}
			}
			else
			{
				dwCnt1 = USB_DONE_WAIT; // Reset counter
			}
		}
		else
		{
			dwCnt1 = USB_DONE_WAIT; // Reset counter
		}
		break;

	case BM_WAIT_QMAX_DAY_STATE_NUM:
		if (false == g_bGotQMAX_DAY)  // Wait until we get QMAX_DAY
			break;

		// Do common stuff
		dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination

		RETAILMSG(SHOW_CAL, ("Charger_Tick: Check for cal needed\n"));
		if (DoCal())
		{ // Start a cal cycle
			Pointers->GG_Cal = CAL_IN_PROGRESS; // Flag that we are doing a cal cycle
			g_dwChargerState = BM_WAIT_FLAT_TOP_STATE_NUM;  // Set to wait for over flat region
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Start cal\n"));
		}
		else
		{  // Just do a normal charge cycle
			dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
		}
		break;

	case BM_WAIT_FLAT_TOP_STATE_NUM:
		// Past the "flat top"?
		if (g_GiftedBattData.SOC > (g_GiftedBattData.SOCZ & 0x00ff))
		{ // Yup, setup the 2min of prep curr
			dwMinInt = 0;  // Setup prep charge timeout counter (round up to next minute if needed
			dwMinCnt = (g_GiftedBattData.OCV_PRED_Prep_Time_Sec / 60) + ((g_GiftedBattData.OCV_PRED_Prep_Time_Sec % 60) ? 1 : 0);
//			BCI_SetACIN_ChargerCurrent(g_GiftedBattData.OCV_PRED_Prep_Curr_mA);  // Set to prep current
			g_dwChargerState = BM_CAL_PREP_STATE_NUM;  // Set to charge for a bit
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Start cal prep"));
		}
		else
		{ // Nope, do normal checks
			// Check for enough % left to do delta
			if (g_GiftedBattData.SOC > g_GiftedBattData.SOC_CAL_MAX)
			{
				dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
				g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Not enough room left
				Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
				RETAILMSG(SHOW_CAL, ("Charger_Tick: Give up on cal"));
			}

			goto DoFastChargeState;
		}
		break;

	case BM_CAL_PREP_STATE_NUM:
		if (!dwMinCnt)  // Done Yet?
		{
			dwMinInt = 0;  // Setup wait time
			dwMinCnt = g_GiftedBattData.MaxOCV_PREDmins;

			g_dwChargerState = BM_CAL_WAIT1_STATE_NUM;  // Set to wait for cal OK state
			local_EnableCharger(0);  // Shut down charger
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Charger off"));
			break;
		}

		goto DoFastChargeState;
		break;

	case BM_CAL_WAIT1_STATE_NUM:
		if (g_GiftedBattData.FLAGS & (OCV_PRED | OCV_TAKEN)) // OK to start cal charging?
		{  // Yes
			dwWaitGetCap = 20; // Set to wait a bit before we get the ending percentage
			dwCnt1 = NEARLY_DONE_WAIT * 10;  // Setup timer for long switch to done to cover charger startup

			g_dwChargerState = BM_CAL_CHARGE_STATE_NUM;  // Set to cal charge state
			local_EnableCharger(1);  // Restart charger
//			BCI_EnableACIN_Charger(dwChargeCurrent,FALSE);  // Set to high current
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Cal phase one done"));
			break;
		}
/* ***FIX*** Add check for current too high (+ or -) to do cal (also in second wait time)
		else
		{ // No, check for current still low enough
			if (BattCurrent > (Pointers->batteryRatedCapacity/20) || BattCurrent < (-1*(int)Pointers->batteryRatedCapacity/20))
			{ // Too high
			}
			else
			{ // Still OK
			}
*/
		if (!dwMinCnt)  // Timeout?
		{  // Yes, just go to fast charge
			dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
			local_EnableCharger(1);  // Restart charger
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
//			BCI_SetACIN_ChargerCurrent(dwChargeCurrent);  // Set to high current
//			SetEvent(hPowerStateChange);  // Notify PM of state change
			break;
		}
		break;

	case BM_CAL_CHARGE_STATE_NUM:
		if (0 != dwWaitGetCap)  // Still waiting to get percentage?
		{
			--dwWaitGetCap;
			if (0 == dwWaitGetCap)  // Done yet?
			{
				SOC_Ref = g_GiftedBattData.SOC; // Save start of cal charge
				RETAILMSG(SHOW_CAL, ("Charger_Tick: SOC_Ref: %d\n",SOC_Ref));
			}
		}
		else
		{  // Did we charge enough yet?
			if (g_GiftedBattData.SOC >= (SOC_Ref+g_GiftedBattData.SOC_DELTA))
			{ // Yup, setup to wait for cal done
				dwMinInt = 0;  // Setup wait time
				dwMinCnt = g_GiftedBattData.MaxOCV_PREDmins;

				g_dwChargerState = BM_CAL_WAIT2_STATE_NUM;  // Set to wait for cal
				local_EnableCharger(0);  // Shut down charger
//				BCI_EnableACIN_Charger(0,FALSE);  // Shut down charger
//				SetEvent(hPowerStateChange);  // Notify PM of state change
				break;
			}
		}

		goto DoFastChargeState;
		break;

	case BM_CAL_WAIT2_STATE_NUM:
		if (g_GiftedBattData.FLAGS & (OCV_PRED | OCV_TAKEN)) // OK to go back to fast charging?
		{  // Yes
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Battery cal done!\n"));

			dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
			local_EnableCharger(1);  // Restart charger
//			BCI_EnableACIN_Charger(dwChargeCurrent,FALSE);  // Set to high current
//			SetEvent(hPowerStateChange);  // Notify PM of state change
			break;
		}

		if (!dwMinCnt)  // Timeout?
		{  // Yes, just go to fast charge
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Battery cal fail!\n"));

			dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
			local_EnableCharger(1);  // Restart charger
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
//			BCI_EnableACIN_Charger(dwChargeCurrent,FALSE);  // Set to high current
//			SetEvent(hPowerStateChange);  // Notify PM of state change
			break;
		}
		break;
	}
}

void DoZ561_ChargerStuff(void)
{
	int BattCurrent; // Current current
	uint16_t CurrVolt; // Current voltage
	static int dwCnt1; // Counter
	static int dwOCV_PA = 0; // OCV_Pred_Active Counter
	static u32 dwCnt2 = 0;  // Charger off counter
	static uint16_t StartVolt; // Startup voltage for cal function
	static int DBcnt = -1;  // Debug data output timer, -1 is disabled


	CurrVolt = Pointers->Voltage;  // Get current voltage
	BattCurrent =  Pointers->Current;  // Gifted current

	RETAILMSG(SHOW_CHG_STATES,("Z561: V: %u C: %d R: %d\n",CurrVolt,BattCurrent,g_GiftedV2Data.RSOC));

	// Update timers
	if (DBcnt > 0)  // Do debug timer
		--DBcnt;
	if (dwOCV_PA > 0)  // Do OCV_Pred_Active timer
		--dwOCV_PA;

	// Cal debug stuff
	if (SHOW_CAL && DBcnt == 0)
	{
		// Start ITStatus reads
		g_bITStatus2 = true;
		g_bGotITStatus2 = false;
		g_bITStatus3 = true;
		g_bGotITStatus3 = false;
		g_bReadQMAX_DAY = true;
		g_bGotQMAX_DAY = false;

		DBcnt = 10;  // Trigger again in 10 sec
		RETAILMSG(SHOW_CAL,("Z561: OCV_PA: %d\n",dwOCV_PA));
	}

	// Check for not charging and reset state machine
	if (g_dwChargerState != BM_CHARGER_DISABLED_STATE_NUM) // Are we charging?
	{ //Yes
		// Check for fully charged
		if (g_GiftedV2Data.BATTERYSTATUS & NGG_BATTERYSTATUS_FC)
		{  // We are done!
			ChargerInit();  // Reset state machine
			local_StopCharger();  // Tell OS to stop charging
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			RETAILMSG(SHOW_CHG_STATES, ("GG Full, stopped charging\n"));

			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
				g_bReadQMAX_DAY = true;
				g_bGotQMAX_DAY = false;
			}
		}
		if (BattCurrent < CHRG_OFF_THRESHOLD)  // Are we draining the battery?
		{ // Yes
			// Check for in a "wait" state
			if (!ChargerPaused)
			{ // Nope
				if (dwCnt2)// Time to quit?
				{ // Not yet
					--dwCnt2; // Dec counter
				}
				else
				{ // Yup
					RETAILMSG(SHOW_CHG_STATES, ("Charger_Tick: Draining battery!\n"));
					ChargerInit();  // Reset state machine
				}
			}
		}
		else
		{ // Not draining
			dwCnt2 = CHRG_OFF_TIMEOUT; // Reset counter
		}
	}
	else
	{ // Not charging
		dwCnt2 = CHRG_OFF_TIMEOUT; // Reset counter
	}

	RETAILMSG(SHOW_CHG_STATES, ("Charger_State Z561: %d\n",g_dwChargerState));

	// Do charger state machine
	switch (g_dwChargerState)
	{
	case BM_CHARGER_DISABLED_STATE_NUM: // Disabled
		if (WasFullyCharged && !StartedRecharge)  // Check if we need to restart charging
		{
			// Check if we need to restart charging, OS handles initial start of charging
			if (!(g_GiftedV2Data.BATTERYSTATUS & NGG_BATTERYSTATUS_FC))
			{
				WasFullyCharged = false;
				local_EnableCharger(1);  // Tell OS to start charging again
				StartedRecharge = true;
			}
		}

		// Check for start of charging
		if (BattCurrent > MIN_CHARGING_CURRENT)  // Enough current to be considered charging?
		{ // Yes
			local_StartChg(); // Say we are starting charging
			if (local_PastTime(dwStartDelay)) // Has it been high long enough?
			{ // Yes
				dwCnt1 = SLOW_FAST_WAIT;
				g_dwChargerState = BM_SLOW_CHG_STATE_NUM;
				StartedRecharge = false;  // Clear started recharge flag
				// Start QMAX reads
				g_bReadQMAX_DAY = true;
				g_bGotQMAX_DAY = false;
				if (SHOW_CAL)
				{
					// Start ITStatus2 read
					g_bITStatus2 = true;
					g_bGotITStatus2 = false;
				}
				// Start ITStatus3 read
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
				RETAILMSG(SHOW_CAL, ("Charger_Tick: start QMAX_DAY, ITStatus3 read\n"));
			}
		}
		else
		{ // Nope
			dwStartDelay = local_GetStopTime(CHARGE_DETECT_TIME);  // Reset 10 second delay to detect charging
			local_StopChg(); // Say we are stoping charge
		}
		break;

	case BM_SLOW_CHG_STATE_NUM:
		if (Pointers->Voltage > Pointers->SlowFastCharge_mV)  // Over slow to fast threshold?
		{
			--dwCnt1;
			if (!dwCnt1)  // OK to go to fast mode?
				g_dwChargerState = BM_WAIT_QMAX_DAY_STATE_NUM;  // Set to check for cal
		}
		else
		{
			dwCnt1 = SLOW_FAST_WAIT; // Reset counter
		}
		break;

	case BM_FAST_CHG_STATE_NUM:		// Used code from USB fast charging state here because we don't know
										// what type of charging source/hardware we have
DoFastChargeState:
		// Check for done charging
		if (!(g_GiftedV2Data.BATTERYSTATUS & NGG_BATTERYSTATUS_FC)) // Reset was charged flag if needed
			WasFullyCharged = false;
// local_print("Was: %d Done:%d SOC:%d\n",WasFullyCharged,g_GiftedBattData.FLAGS & FLAG_FC,g_GiftedBattData.SOC);
		// Check if we need to stop charging
		// Gas gauge 'done' flag is set if it was cleared to start, or at 100% if it wasn't?
		if ((!WasFullyCharged && (g_GiftedV2Data.BATTERYSTATUS & NGG_BATTERYSTATUS_FC)) || (WasFullyCharged && (100 == g_GiftedV2Data.RSOC)))
		{
			RETAILMSG(SHOW_CHG_STATES, ("Charger_Tick: Done charging\n"));
			local_StopCharger();  // Tell OS to stop charging
			ChargerInit();  // Reset state machine
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			WasFullyCharged = true;  // Set was charged flag
		}

/*
		if (Pointers->Voltage > (Pointers->ChargeUp_mV - USB_DONE_VOLT_OFF)) // Voltage high enough to check current?
		{
			// Under done threshold, and over min usb current?
			if (BattCurrent < Pointers->DoneCurrent && BattCurrent > USB_DONE_CURR)
			{
				--dwCnt1;
				if (!dwCnt1)  // OK to go to done?
				{
					// Set to done state and turn off
					ChargerInit();  // Reset state machine
					local_StopCharger();  // Tell OS to stop charging
					Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
					WasFullyCharged = true;  // Set was charged flag
				}
			}
			else
			{
				dwCnt1 = USB_DONE_WAIT; // Reset counter
			}
		}
		else
		{
			dwCnt1 = USB_DONE_WAIT; // Reset counter
		}
*/
		break;

	case BM_WAIT_QMAX_DAY_STATE_NUM:
		if (false == g_bGotQMAX_DAY || false == g_bGotITStatus3)  // Wait until we get QMAX_DAY and ITStatus3
			break;

		RETAILMSG(SHOW_CAL, ("Charger_Tick: Check for cal needed\n"));
		if (DoCal())
		{ // Start a cal cycle
			if (g_GiftedV2Data.QmaxDOD0 > 0x7332)  // Already have a good QMAX, over 45% discharged? (Error code forces full cal)
			{  // Yup, just charge to full
				Pointers->GG_Cal = CAL_IN_PROGRESS; // Flag that we are doing a cal cycle
				dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
				g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
				RETAILMSG(SHOW_CAL, ("Charger_Tick: Simple cal\n"));
				break;
			}
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Start cal\n"));
			dwCnt1 = Z561_RELAX_WAIT;  // Set delay
			g_dwChargerState = BM_CAL_WAIT_RELAXTIME1;  // Set to wait for relax time
			local_EnableCharger(0);  // Shut down charger
			ChargerPaused = 1;  // Set flag to show charging paused
		}
		else
		{  // Just do a normal charge cycle
			dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
		}
		break;

	case BM_CAL_WAIT_RELAXTIME1:
		// Done with delay yet?
		--dwCnt1;
		if (!dwCnt1) // Yes
		{
			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
			}
			// Start GaugingStatus read
			g_bGaugingStatus = true; // Trigger gauging status read
			g_bGotStatus = false; // Clear got status flag
			g_dwChargerState = BM_CAL_WAIT_GAUGING_STATUS1;  // Set to check status
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Get gauging status\n"));
		}
		break;

	case BM_CAL_WAIT_GAUGING_STATUS1:
		// Got status yet?
		if (!g_bGotStatus)
			break;  // Not yet
		RETAILMSG(SHOW_CAL, ("Charger_Tick: gauging status1: %08X\n",g_GiftedV2Data.GaugingStatus));

		local_EnableCharger(1);  // Resume charging
		ChargerPaused = 0;  // Clear charging paused flag
		if (0xffffffff == g_GiftedV2Data.GaugingStatus) // Check for error
		{ // Give up on cal this time round
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Bad gauging status\n"));
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;
			break;
		}

		// Check OCVFR flag
		if (!(g_GiftedV2Data.GaugingStatus & NGG_OCVFR_BIT)) // OCVFR = 0?
		{ // Above FZ+40mv
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status bit cleared!\n"));
			// Check SOC to see if we have room for a cal
			if (g_GiftedV2Data.RSOC > 60)
			{ // No room to cal
				// Just finish charging
				RETAILMSG(SHOW_CAL, ("Charger_Tick: No room to cal!\n"));
				g_dwChargerState = BM_FAST_CHG_STATE_NUM;
				Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
				break;
			}
			else
			{  // Try for a cal
				Pointers->GG_Cal = CAL_IN_PROGRESS; // Flag that we are doing a cal cycle
				dwOCV_PA = g_GiftedV2Data.Cal.OCVPRED_PrepTimeSec;  // Start OCV_Pred_Active timer
				g_dwChargerState = BM_CAL_WAIT_OCV_PRED_ACTIVE_TIMER; // Wait for time to expire
			}
		}

		// In/below FZ
		Pointers->GG_Cal = CAL_IN_PROGRESS; // Flag that we are doing a cal cycle
		dwCnt1 = 2; // Charge for 2 seconds
		g_dwChargerState = BM_CAL_WAIT_GAUGING_STATUS2;
		dwOCV_PA = g_GiftedV2Data.Cal.OCVPRED_PrepTimeSec;  // Start OCV_Pred_Active timer
		break;

	case BM_CAL_WAIT_GAUGING_STATUS2:
		// Done with delay yet?
		--dwCnt1;
		if (!dwCnt1) // Yes
		{
			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
			}
			// Start GaugingStatus read
			g_bGaugingStatus = true; // Trigger gauging status read
			g_bGotStatus = false; // Clear got status flag
			g_dwChargerState = BM_CAL_WAIT_GAUGING_STATUS3;  // Set to check status
		}
		break;

	case BM_CAL_WAIT_GAUGING_STATUS3:
		// Got status yet?
		if (!g_bGotStatus)
			break;  // Not yet
		RETAILMSG(SHOW_CAL, ("Charger_Tick: gauging status3: %08X\n",g_GiftedV2Data.GaugingStatus));

		if (0xffffffff == g_GiftedV2Data.GaugingStatus) // Check for error
		{ // Give up on cal this time round
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Bad gauging status\n"));
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			break;
		}

		// Check QMAXDODOK flag
		if (!(g_GiftedV2Data.GaugingStatus & NGG_QMAXDODOK_BIT)) // QMAXDODOK = 0?
		{
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status QMAXDODOK bit not set!\n"));
			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
			}
			// Wait for QMAXDODOK != 0
			// Start GaugingStatus read
			g_bGaugingStatus = true; // Trigger gauging status read
			g_bGotStatus = false; // Clear got status flag
			g_dwChargerState = BM_CAL_WAIT_GAUGING_STATUS4;  // Set to check status
		}
		else
		{
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status QMAXDODOK bit set!\n"));
			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
			}
			// Wait for QMAXDODOK == 0
			// Start GaugingStatus read
			g_bGaugingStatus = true; // Trigger gauging status read
			g_bGotStatus = false; // Clear got status flag
			g_dwChargerState = BM_CAL_WAIT_GAUGING_STATUS5;  // Set to check status
		}
		break;

	case BM_CAL_WAIT_GAUGING_STATUS5:
		// Got status yet?
		if (!g_bGotStatus)
			break;  // Not yet
		RETAILMSG(SHOW_CAL, ("Charger_Tick: gauging status5: %08X\n",g_GiftedV2Data.GaugingStatus));

		if (0xffffffff == g_GiftedV2Data.GaugingStatus) // Check for error
		{ // Give up on cal this time round
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Bad gauging status\n"));
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			break;
		}

		if (SHOW_CAL)
		{
			// Start ITStatus reads
			g_bITStatus2 = true;
			g_bGotITStatus2 = false;
			g_bITStatus3 = true;
			g_bGotITStatus3 = false;
		}

		// Start GaugingStatus read
		g_bGaugingStatus = true; // Trigger gauging status read
		g_bGotStatus = false; // Clear got status flag

		// Check QMAXDODOK flag
		if (g_GiftedV2Data.GaugingStatus & NGG_QMAXDODOK_BIT) // QMAXDODOK = 1?
		{
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status QMAXDODOK bit set!\n"));
			break;
		}
		RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status QMAXDODOK bit not set!\n"));
		// Wait for QMAXDODOK != 0
		g_dwChargerState = BM_CAL_WAIT_GAUGING_STATUS4;
		break;

	case BM_CAL_WAIT_GAUGING_STATUS4:
		// Got status yet?
		if (!g_bGotStatus)
			break;  // Not yet
		RETAILMSG(SHOW_CAL, ("Charger_Tick: gauging status4: %08X\n",g_GiftedV2Data.GaugingStatus));

		if (0xffffffff == g_GiftedV2Data.GaugingStatus) // Check for error
		{ // Give up on cal this time round
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Bad gauging status\n"));
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			break;
		}

		// Check QMAXDODOK flag
		if (!(g_GiftedV2Data.GaugingStatus & NGG_QMAXDODOK_BIT)) // QMAXDODOK = 0?
		{
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status QMAXDODOK bit not set!\n"));
			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
			}

			// Wait for QMAXDODOK != 0
			// Start GaugingStatus read
			g_bGaugingStatus = true; // Trigger gauging status read
			g_bGotStatus = false; // Clear got status flag
			break;
		}

		// Setup to wait for 60mv increase in voltage
		StartVolt = CurrVolt;  // Get initial voltage
		g_dwChargerState = BM_CAL_WAIT_VOLTAGE;  // Set to check status

		if (SHOW_CAL)
			DBcnt = 0;  // Start ITStatus reads
		break;

	case BM_CAL_WAIT_VOLTAGE:
		if (StartVolt >= CurrVolt) // Make sure it went up
			break;
		if ((CurrVolt - StartVolt) > 60)  // At least a 60mv increase?
		{ // Yup
			// Switch to wait for pred active timer timer
			g_dwChargerState = BM_CAL_WAIT_OCV_PRED_ACTIVE_TIMER;
			DBcnt = -1; // Disable debug stuff while waiting
		}
		break;

	case BM_CAL_WAIT_OCV_PRED_ACTIVE_TIMER:
		if (0 != dwOCV_PA) // Wait for timeout
			goto DoFastChargeState;  // Not yet
		local_EnableCharger(0);  // Shut down charger
		ChargerPaused = 1;  // Set flag to show charging paused
		// Setup to wait for OCVPRED
		dwMinCnt = g_GiftedV2Data.Cal.MaxOCVPRED_Mins;
		g_dwChargerState = BM_CAL_WAIT_OCVPRED;  // Wait for OCVPRED
		g_bGaugingStatus = true; // Trigger gauging status read
		g_bGotStatus = false; // Clear got status flag

		if (SHOW_CAL)
		{
			// Start ITStatus reads
			g_bITStatus2 = true;
			g_bGotITStatus2 = false;
			g_bITStatus3 = true;
			g_bGotITStatus3 = false;
			g_bReadQMAX_DAY = true;
			g_bGotQMAX_DAY = false;
		}
		break;

	case BM_CAL_WAIT_OCVPRED:
		if (!dwMinCnt)  // Timeout?
		{  // Yes, just go to fast charge
			RETAILMSG(SHOW_CAL, ("Charger_Tick: OCVPRED wait timeout, battery cal done?\n"));
			dwCnt1 = USB_DONE_WAIT;  // Setup timer for charge termination
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;  // Set to fast charge state
			local_EnableCharger(1);  // Restart charger
			ChargerPaused = 0;  // Clear charging paused flag
			break;
		}

		// Got status yet?
		if (!g_bGotStatus)
			break;  // Not yet
		RETAILMSG(SHOW_CAL, ("Charger_Tick: gauging status4: %08X\n",g_GiftedV2Data.GaugingStatus));

		if (0xffffffff == g_GiftedV2Data.GaugingStatus) // Check for error
		{ // Give up on cal this time round
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Bad gauging status\n"));
			local_EnableCharger(1);  // Restart charger
			ChargerPaused = 0;  // Clear charging paused flag
			Pointers->GG_Cal =  NO_CAL_NEEDED; // Clear doing cal flag
			g_dwChargerState = BM_FAST_CHG_STATE_NUM;
			break;
		}

		// Check OCVPRED flag
		if (!(g_GiftedV2Data.GaugingStatus & NGG_OCVPRED_BIT)) // OCVPRED = 0?
		{
			RETAILMSG(SHOW_CAL, ("Charger_Tick: Got gauging status OCVPRED bit not set!\n"));
			// Wait for OCVPRED == 1
			// Start GaugingStatus read
			g_bGaugingStatus = true; // Trigger gauging status read
			g_bGotStatus = false; // Clear got status flag

			if (SHOW_CAL)
			{
				// Start ITStatus reads
				g_bITStatus2 = true;
				g_bGotITStatus2 = false;
				g_bITStatus3 = true;
				g_bGotITStatus3 = false;
				g_bReadQMAX_DAY = true;
				g_bGotQMAX_DAY = false;
			}
			break;
		}
		// All done!
		RETAILMSG(SHOW_CAL, ("Charger_Tick: Finish up cal charge!\n"));
		dwMinCnt = 0; // Clear timieout timer
		g_dwChargerState = BM_FAST_CHG_STATE_NUM; // Back to normal charging
		local_EnableCharger(1);  // Restart charger
		ChargerPaused = 0;  // Clear charging paused flag
		if (SHOW_CAL)
			DBcnt = 0;  // Restart debug stuff if needed
		break;
	}
}

//------------------------------------------------------------------------------
//
//  Function:  DoCal
//
//  Decide if an MPA3 battery force calibration cycle is needed.
//
bool DoCal(void)
{
	switch (g_BattType)
	{
	case BATT_M200:  // M200 GG PP+ batt
		RETAILMSG(SHOW_CAL, ("DoCal: QMAX_DAYS: %d  MaxRecalDays: %d\n"
			,Pointers->QMAX_DAYS,g_GiftedBattData.Dyn1Block[0].MaxRecalPd_Days));
		RETAILMSG(SHOW_CAL, ("DoCal: SOL_CAL_MAX: %d  QVC: %d  MaxRecalCycles: %d\n"
			,g_GiftedBattData.SOC_CAL_MAX,g_GiftedBattData.QVC,g_GiftedBattData.MaxRecal_Cycle));
		RETAILMSG(SHOW_CAL, ("DoCal: PrepTimeSec: %d  Flattop: %d  PredMin: %d  Delta: %d\n"
			,g_GiftedBattData.OCV_PRED_Prep_Time_Sec,(g_GiftedBattData.SOCZ & 0x00ff)
			,g_GiftedBattData.MaxOCV_PREDmins,g_GiftedBattData.SOC_DELTA));

		// Check for enough % left to do delta
		if (g_GiftedBattData.SOC > g_GiftedBattData.SOC_CAL_MAX)
			return (false);  // Not enough room left

		// Check for forcing calibration
		if (FORCE_CAL)
			return (true);

		// Check for invalid QMAX_DAY
		if (0xffff == g_GiftedBattData.QMAX_DAY)
			return (false);

		// Check how long since last calibration
		if (g_GiftedBattData.Dyn1Block[0].MaxRecalPd_Days > 0 &&  Pointers->QMAX_DAYS >= g_GiftedBattData.Dyn1Block[0].MaxRecalPd_Days)
			return (true);  // Been too many days since last calibration

		// Check how many cycles since last calibration
		if (g_GiftedBattData.MaxRecal_Cycle > 0 && Pointers->QVC >= g_GiftedBattData.MaxRecal_Cycle)
			return (true);  // Been too many cycles since last calibration
		break;
	case BATT_Z561:  // Z561 GG PP+ batt
		RETAILMSG(SHOW_CAL, ("DoCal: QMAX_DAY: %d QMAX_DAYS: %d  MaxRecalDays: %d\n"
			,g_GiftedV2Data.QMAX_DAY,Pointers->QMAX_DAYS,g_GiftedV2Data.Cal.MaxRecalDays));
		RETAILMSG(SHOW_CAL, ("DoCal: RSOC_CalMax: %d  QVC: %d  MaxRecalCycles: %d\n"
			,g_GiftedV2Data.Cal.RSOC_CalMax,g_GiftedV2Data.QVC,g_GiftedV2Data.Cal.MaxRecalCycles));
		RETAILMSG(SHOW_CAL, ("DoCal: PrepTimeSec: %d  PredMin: %d  Delta: %d\n"
			,g_GiftedV2Data.Cal.OCVPRED_PrepTimeSec,g_GiftedV2Data.Cal.MaxOCVPRED_Mins,g_GiftedV2Data.Cal.RSOC_Delta));

		// Check for enough % left to do delta
		if (g_GiftedV2Data.RSOC > g_GiftedV2Data.Cal.RSOC_CalMax)
			return (false);  // Not enough room left

		// Check for forcing calibration
		if (FORCE_CAL)
			return (true);

		// Check for invalid QMAX_DAY
		if (0xffff == g_GiftedV2Data.QMAX_DAY)
			return (false);

		// Check how long since last calibration
		if (g_GiftedV2Data.Cal.MaxRecalDays > 0 &&  Pointers->QMAX_DAYS >= g_GiftedV2Data.Cal.MaxRecalDays)
			return (true);  // Been too many days since last calibration

		// Check how many cycles since last calibration
		if (g_GiftedV2Data.Cal.MaxRecalCycles > 0 && Pointers->QVC >= g_GiftedV2Data.Cal.MaxRecalCycles)
			return (true);  // Been too many cycles since last calibration
		break;
	default:  // Not a PP+ batt
		local_print("PM_Batt: Warning, DoCal non PP+ Batt: %d\n",g_BattType);
		break;
	}

	return (false);  // Not time yet!
}


