//--------------------------------------------------------------------
// FILENAME:	pwm.h
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	Include file for power micro functions
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

#ifndef PWM_H_
#define PWM_H_

// Function prototypes
void PM_Init(void);
void PM_Reinit(void);
void ClearWriteFlags(void);
uint32_t PM_Tick(void);
void PM_Resume(void);
void PM_Suspend(void);
uint32_t HibernateBatt(void);
void ResetRateLimit(void);
uint32_t FindNewLevel(uint32_t dwCapacity);

extern long g_dwNextTSFU_Time;	// Time to next update NGG time since first use

extern uint32_t dwWrBattMode;  // Mode of write battery data state machine
extern uint32_t RegBytesRead;				// Count of bytes read from the gas gauge registers

extern uint32_t g_dwGaugingStatus; // Gauging status bits

// Battery update/request flags
extern bool g_bHibernate;		// Flag to request putting GG into hibernate
extern bool g_bReadMPA3Regs;	// Flag to request read of MPA3 GG registers
extern bool g_bReadMPA3Health;	// Flag to request read of state of health
extern bool g_bUpdateBM;			// Flag to trigger update of battery micro data
extern bool g_bWriteDB1, g_bWriteDB2, g_bWriteDB3, g_bWriteDB4;	// Flags to trigger write of dynamic blocks
extern bool bWriteTC;  // Flag to trigger write of total charge
extern bool bWhichTC;  // Flag to indicate which TC area to write
extern bool g_bWriteMPA2Health;	// Flag to request write of MPA2 battery health area
extern bool g_bReadQMAX_DAY;	// Flag to request read of QMAX_DAY value
extern bool g_bGotQMAX_DAY;		// Flag to indicate read of QMAX_DAY is done
extern bool g_bReadCONTROL_STATUS;	// Flag to request read of CONTROL_STATUS flags
extern bool g_bReadTempChip; // Flag to request a temp chip read
extern bool g_bWriteVTAC1, g_bWriteVTAC2, g_bWriteVTH1, g_bWriteVTH2;  // Flags to trigger VT battery updates
extern bool g_bWriteNGG_AC1, g_bWriteNGG_AC2;  // NGG request agg charge write flags
extern bool g_bWriteIT;  // NGG write initial times data flag
extern bool g_bWriteHD;  // NGG write health data flag
extern bool g_bUTSFU;  // NGG update time since first use
extern bool g_bGaugingStatus;  // Get gauging status data
extern bool g_bGotStatus;  // Flag to indicate a new gauging status value is in
extern bool g_bITStatus2;  // Flag to trigger read of ITStatus2 register
extern bool g_bGotITStatus2;  // Flag to indicate ITStatus2 was read
extern bool g_bITStatus3;  // Flag to trigger read of ITStatus3 register
extern bool g_bGotITStatus3;  // Flag to indicate ITStatus3 was read

// Charge accumulatiion
extern bool		g_dwDoChgAcc;		// Flag to enable charge accumulation
extern uint32_t	g_dwLeftOverChg;	// Left over maHrs * 3600000
extern uint32_t	g_dwLastTC;			// Last total charge value
extern unsigned long DoAccTime;		// Time to do charge accumulation

// Batt comm error counter
extern uint32_t g_dwBattCommErrCnt;	// Counter of battery comm errors

// Loop times
#define FAST_LOOP Pointers->FastLoop  // Def for fast and normal loop times
#define NORM_LOOP Pointers->NormLoop

// Battery temp checking
extern int16_t LastGGTmp;  // Last temp from GG
#define NO_TEMP_YET 15000  // Didn't get a temp from chip yet, temp.
#define WACKY_TEMP_CHANGE 10  // Max temp change reading to reading
#define MIN_OK_VOLTAGE 1500  // Minimum battery voltage that is OK
#define MAX_OK_VOLTAGE 5000  // Max battery voltage that is OK

extern int LastVTcap;

// Write battery data state machine defs
#define WR_MODE_IDLE		0		// Idle, waiting for data to write
#define WR_MODE_TC			1		// Waiting for first total charge write to finish
#define WR_MODE_BM1			2		// Waiting for display battery write to finish
#define WR_MODE_REGS		3		// Waiting for GG register read to finish
#define WR_MODE_DB1			4		// Waiting for read of lock block
#define WR_MODE_TOSS		5		// Toss any incomming I2C stuff, then got to idle
#define WR_MODE_HEALTH		6		// Write MPA2 health record
#define RD_QMAX_DAY1		7		// Setup to read QMAX_DAY
#define	RD_QMAX_DAY2		8		// Get QMAX_DAY value
#define RD_CONTROL_STATUS1	9		// Setup to read CONTROL_STATUS
#define	RD_CONTROL_STATUS2	10		// Get CONTROL_STATUS value
#define WR_AT_RATE_DONE		11		// Waiting for AtRate() write to finish
#define WR_MODE_START_TEMP	12		// Start temp chip read
#define WR_MODE_WAIT_TEMP	13		// Wait for temp chip to do conversion
#define WR_MODE_GET_TEMP	14		// Read temp
#define WR_MODE_STOP_TEMP	15		// Shutdown temp chip
#define WR_MODE_DB2			16		// Waiting for write of dynamic block to finish
#define WR_MODE_HIBERNATE	17		// Put GG into hibernate mode
#define WR_MODE_STOPPED		18		// No more battery access
#define WR_MODE_Auth		19		// Write auth chip data
#define RD_MODE_TSFU		20		// Read times in ranges
#define WR_MODE_IT			21		// Write intial times data
#define RD_QMAX_DAY_NGG1	22		// Get Qmax day value
#define RD_QMAX_DAY_NGG2	23		// Get firmware runtime value
#define RD_MODE_GGST		24		// Get GaugingStatus() stuff
#define RD_MODE_ITS2		25		// Get ITStatus2 stuff
#define RD_MODE_ITS3		26		// Get ITStatus3 stuff

#endif	// #ifndef PWM_H_
