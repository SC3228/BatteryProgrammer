//--------------------------------------------------------------------
// FILENAME:	pwm_batt.c
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	Virtual Power Micro - Battery functions
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

#include <linux/string.h>
#include <linux/types.h>

#include "pwm.h"
#include "pwm_batt.h"
#include "pwm_chrg.h"
#include "aes.h"
#include "keys.h"
#include "BattMan_main.h"

// MPA3 eeprom address
uint16_t MPA3_eeprom_addr;

long g_dwNextGasGaugeTime;	// Time to next report a capacity

u32 DesignCap = 1000;  // Gas gauge design capacity value

// Local globals
uint32_t dwBlkCnt;					// Count of blocks read from MPA3 EEPROM
uint32_t dwVoltOkCnt;				// Counter for good battery readings
uint32_t EnabledCharger;			// Already enabled charger flag
bool Have_VT_EEPROM = false;		// Flag to indicate we found a VT battery with an EEPROM
uint16_t VT_EEPROM_Offset = 0;		// Current offset into VT EEPROM
uint16_t VT_EEPROM_BlobSize = 0;	// Size of the blob in the VT EEPROM
uint8_t VT_EEPROM_BlobCsum = 0;		// Checksum of the VT EEPROM data

// Battery finding stuff
uint32_t dwTries;	// Counter for tries at finding an EEPROM
#define MPA2_TRIES		3	// Max times to look for MPA2 battery
#define MPA3_TRIES		3	// Max times to look for MPA3 battery
#define AUTH_TRIES		4	// Retries for auth chip read during detection
#define EEPROM_TRIES	4	// Retries for EEPROM read during detection
#define VT_TRIES		2	// Retries for VT large EEPROM
uint32_t DidReset;	// Already tried a reset flag

// Other defs
#define GG_SLAVE_ADDRESS 0x55	// Gas Gauge slave address on I2C4
#define	VERY_COLD		-42;	// Temp to use for ignoring low 1725 discharge limit

// MPA2 battery part number stuff
#define DEFAULT_BATTERY_PREFIX_NOS		82		// Default prefix for battery family numbers
typedef struct SMART_BATTERY_PREFIX_LOOKUP_TAB_STRUCT
{
	uint32_t g_dwBatteryFamilyNo;
	uint32_t g_dwBatteryPrefixNo;
}SMART_BATTERY_PREFIX_LOOKUP_TAB;

typedef struct SMART_BATTERY_FAMILY_LOOKUP_TAB_STRUCT
{
	uint32_t g_dwIncorrectBattFamilyNo;
	uint32_t g_dwCorrectBattFamilyNo;
}SMART_BATTERY_FAMILY_LOOKUP_TAB;

//Lookup table for identifying the correct prefix number from the corresponding battery family number.
SMART_BATTERY_PREFIX_LOOKUP_TAB g_StructSmartBattPrefixLookupTab[] =
{{60112, 55}, {60117, 55}, {166, 55}, {65587, 21}, {61261, 21}, {62960, 21}};

//Lookup table to correct the battery family number from the incorrect battery family number (MSB is missing)
SMART_BATTERY_FAMILY_LOOKUP_TAB g_StructSmartBattFamilyLookupTab[] =
{{27909,127909}, {27912,127912}, {7172,107172}, {1094,111094}, {1606,101606}, {11734,111734}, {11636,111636}, {5,90005}};

void Hello(void)
{
	local_print("Battman: Ready\n");
}

//------------------------------------------------------------------------------
//
//  Function:  BattInit
//
//  Battery stuf init
//		Sets up the detection state machine and the gas gauge calibrate stuff
//
uint32_t BattInit(void)
{
	uint32_t dwLoop;  // New delay time for PM loop

	g_BattType = BATT_NONE;  // Clear internal battery types
	g_OldBattType = BATT_NONE;
	g_dwBattDetectState = BATT_DET_IDLE;  //  Don't look for a valid battery
	dwLoop = NORM_LOOP;  // Inital loop delay
	g_LastErrorCode = BATT_ERR_NONE;  // No errors yet
	EnabledCharger = 0; // Didn't ask for charger yet

	GasGauge(1);  // Reset gas gauge

	// No charge accumulation
	g_dwDoChgAcc = false;

//	dwStartUpTime = GetTickCount(); // Get startup time

	return (dwLoop);  // Return new loop time
}

//------------------------------------------------------------------------------
//
//  Function:  BattDetectStart
//
//  Start battery detection state machine
//
uint32_t BattDetectStart(void)
{
	g_dwBattDetectState = BATT_DET_START;  //  Start looking for a valid battery
	g_dwBattDetectAfterResetState = BATT_DET_START; // Start over after a GG reset

	// Set "no batt found" values
	Pointers->BatteryType = GB_LOOKING; // Default to looking for battery
	local_InvalidBattery(BM_BATTERY_LOOKING);

	Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Reset to valid battery for now
	g_BattType = BATT_NONE; // Clear internal battery types
	g_OldBattType = BATT_NONE;
	CancelAccess();  // Cancel any writes
	DidReset = 0; // Clear did reset flags
	Pointers->GG_WasReset = 0;

	LastGGTmp = NO_TEMP_YET; // Clear last battery temp
	g_LastErrorCode = BATT_ERR_NONE;  // No errors yet
	g_dwDoChgAcc = false;
	EnabledCharger = 0; // Didn't ask for charger yet

	DoAccTime = local_GetStopTime(120000); // Reset charge accumulation timer

	return (0);
}

//------------------------------------------------------------------------------
//
//  Function:  BattDetectResume
//
//  Restart battery detection state machine after a resume
//
void BattDetectResume(void)
{
	dwBDStopTime = local_GetStopTime(EA_WAIT_TIME);  // Set stop time
	g_dwBattDetectState = BATT_DET_TOSS; // Toss any I2C transactions
	LastGGTmp = NO_TEMP_YET; // Clear last battery temp
	EnabledCharger = 0; // Didn't ask for charger yet
}

//------------------------------------------------------------------------------
//
//  Function:  BattDetectReset
//
//  Reset gas gauge and then do an ID check
//
void BattDetectReset(void)
{
	g_dwBattDetectState = BATT_DET_RESET1;  //  Start GG reset
	g_dwBattDetectAfterResetState = BATT_DET_GET_ID1; // Check ID after GG reset
	CancelAccess(); // Stop any battery I/O
	LastGGTmp = NO_TEMP_YET; // Clear last battery temp
	Pointers->GG_WasReset = 0;  // Clear did reset flag
	EnabledCharger = 0; // Didn't ask for charger yet
	g_OldBattType = g_BattType; // Save current type
	g_BattType = BATT_NONE;  // No battery types now

	BattDetect();  // Do first "tick"
}

//------------------------------------------------------------------------------
//
//  Function:  ShowBatteryData
//
//  Display battery data if needed
//
void ShowBatteryData(void)
{
	if (SHOW_BATT_DATA)  // Show battery data if needed
	{
		switch (Pointers->BatteryType) // Handle the various battery types
		{
		case GB_GIFTED:
		case GB_SMART:
		case GB_VALUE:
			local_print("PM_Batt: %s  Type: %d\n",(g_BattType ? "Valid battery!" : "INVALID BATTERY!!!"), Pointers->BatteryType);
			local_print("PM_Batt: Rated: %dma  Faire: %d%%  Unfaire: %d%%  Low: %d%%\n",Pointers->batteryRatedCapacity,Pointers->battFaireLevel,Pointers->battUnfaireLevel,Pointers->battLowLevel);
			local_print("PM_Batt: MinSlowCur: %dma  MaxSlowCur: %dma  SlowFastVolt: %dmv  SCTO: %d\n",Pointers->MinBattSlowCurr,Pointers->BattSlowCurr,Pointers->SlowFastCharge_mV,Pointers->ChargeSlowMins);
			local_print("PM_Batt: FastCur: %dma  MaxCVolt: %dmv  FCTO: %d  TC: %dmaHr\n",Pointers->BattFastCurr,Pointers->ChargeUp_mV,Pointers->ChargeFastMins,g_dwAggregateCharge);
			local_print("PM_Batt: Nearly: %dma  Done: %dma\n",Pointers->NearlyDoneCurrent,Pointers->DoneCurrent);
			if (GB_GIFTED == Pointers->BatteryType)
			{ // MPA3 battery
				local_print("PM_BATT: Recharge Voltage Delta: %d\n",Pointers->RechargeVoltageDelta);
				local_print("PM_Batt: SOH Threshold: %d%%  SOH: %d%%  Cycles: %d   ZTC: %dmaHr\n"
					,Pointers->dwPercentThreshold,Pointers->SOH,Pointers->CycleCount,Pointers->TotalAccCharge);
			}
			else if (GB_SMART == Pointers->BatteryType)
			{ // MPA2 battery
				local_print("PM_Batt: Cycle Threshold: %d  Cycles: %d\n",Pointers->dwCycleCountThreshold,Pointers->CycleCount);
				local_print("PM_BATT: Recharge Voltage: %d\n",Pointers->ChargeUp_mV-Pointers->RechargeVoltageDelta);
				local_print("PM_Batt: VOCFudge: %d  Start: %d  Stop: %d\n",g_SmartBattData.VocFudge,g_SmartBattData.VocFudgeTempStart,g_SmartBattData.VocFudgeTempStop);
				local_print("PM_Batt: DateFirstUse: %d/%d/%d\n",g_SmartBattData.DateFirstUse[2]>>4,g_SmartBattData.DateFirstUse[0]
								,((g_SmartBattData.DateFirstUse[2]& 0x0f) << 8) | g_SmartBattData.DateFirstUse[1]);
			}
			else if (GB_VALUE == Pointers->BatteryType)
			{ // Value tier battery
				local_print("PM_Batt: Cycle Threshold: %d  Cycles: %d\n",Pointers->dwCycleCountThreshold,Pointers->CycleCount);
				local_print("PM_BATT: Recharge Voltage Delta: %d\n",Pointers->RechargeVoltageDelta);
			}
			local_print("PM_Batt: Health Byte: %d\n",Pointers->battHealth);
			local_print("PM_Batt: Part#: %s\n",Pointers->batteryPartNumber);
			local_print("PM_Batt: PartEx#: %s\n",Pointers->batteryPartNumberEx);
			local_print("PM_Batt: PartNew#: %s\n",Pointers->batteryPartNumberNew);
			local_print("PM_Batt: Serial#: %s\n",Pointers->batteryID);
			local_print("PM_Batt: Manuf Date: %d/%d/%d\n",Pointers->mmonth,Pointers->mday,Pointers->myear);
			break;
		case GB_INVALID:
			local_print("PM_Batt: Invalid Battery!\n");
			break;
		default:
			local_print("PM_Batt: ERROR - Unknown battery type!\n");
			break;
		}
	}
}

//------------------------------------------------------------------------------
//
//  Function:  BattDetect
//
//  Battery detection state machine
//
uint32_t BattDetect(void)
{
	uint32_t dwLoop;  // New delay time for PM loop
	uint32_t dwCnt, dwBcnt;  // Counters
	uint8_t cCSum, *cpnt;  // Checksum checking stuff
//	uint8_t Data;
	char sz_PN[MPA3_BATT_PN_LEN];
	int16_t tmp;  // Temperature conversion variable
	uint32_t dwBattPrefixNo  = 0;  // Used in part number conversions
	uint32_t dwBattFamilyNo  = 0;
	uint32_t wTabCnt = 0;
	u32 DetectFailCode = CHG_NO_ERROR;

	dwLoop = NORM_LOOP;  // Default to regular loop delay

	RETAILMSG(SHOW_DET_STATES,("PM_Batt: DetectState: %d\n",g_dwBattDetectState));  // Show battery detect state if needed

	// Battery detect state machine
	switch (g_dwBattDetectState)
	{
	case BATT_DET_IDLE: // Battery detection state machine is idle
		break;
	case BATT_DET_START: // Start looking for a valid battery
StartBattDetect:
		RETAILMSG(SHOW_DET_STATES,("PM_Batt: Start Detect\n"));
		g_dwBattDetectState = BATT_DET_CHECK_VOLT; // Set to look for MPA3 battery
		dwLoop = FAST_LOOP/20;  // Very short loop delay
		dwVoltOkCnt = 0; // Reset counter
		dwTries = MPA3_TRIES; // set retries
//			dwVoltOkWaitCnt = 0;
		dwBDStopTime = local_GetStopTime(VOLT_WAIT_TIME); // Get stop time
		EnabledCharger = 0; // Didn't ask for charger yet
		goto CheckVolt;
		break;

case BATT_DET_MPA2_FIND: // Waitng for MPA2 battery
	if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
	{
		// Got battery?
		if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
		{
			// Found MPA2 Batt!
			Pointers->BatteryType = GB_SMART; // Set to MPA2 battery
			// Start read of first 16 bytes of battery data
			// Setup I2C structure
			g_BattTrans.byBattChipAddr1 = MPA2EEPROM | 0x01;  // Set EEPROM address and read
			g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
			g_BattTrans.byBattChipAddr2 = 0; // No second transaction
			g_BattTrans.byBattDataAddr1 = 0; // Start of EEPROM
			g_BattTrans.byBattDataSize1 = 16; // Do first 16 bytes

			dwBlkCnt = 0; // Reading first block


			if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
			{  // Set next state
				g_dwBattDetectState = BATT_DET_GET_SDATA1; // Get smart data
				dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
			}
			else  // No good, give up.
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C24\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}
		else  // Try again
		{
			--dwTries;  // Check if more tries left
			if (dwTries)
			{ // Yes
				// Try reading one byte from temp chip
				g_BattTrans.byBattChipAddr1 = MPA2TEMP | 0x01;  // Set temp chip address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = 1; // Just read config register
				g_BattTrans.byBattDataSize1 = 1;

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set wait time
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP;  // Short loop delay
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C30\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
			else
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt31\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}
	}
	else  // Not done yet
	{
		// Been too long?
		if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
		{ // Too long!
			RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt28\n"));
			DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}
	}
	break;

	case BATT_DET_GET_SDATA1: // Get smart battery data
		// Check for first read done
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy((uint8_t *)(&g_SmartBattData)+dwBlkCnt*16,g_BattTrans.byBattDataBuff1,16);
				// Check for last read done
				++dwBlkCnt;
				if (dwBlkCnt >= 16)
				{  // Done, go to verify step
					g_dwBattDetectState = BATT_DET_GET_SDATA2; // Next state
				}
				else
				{  // Start next read
					g_BattTrans.byBattChipAddr1 = MPA2EEPROM | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = dwBlkCnt * 16; // Next block
					g_BattTrans.byBattDataSize1 = 16; // Do next block

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_GET_SDATA1; // Get more smart data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C34\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt2\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}
		break;

	case BATT_DET_GET_SDATA2: // Validate smart battery data
		// Check for valid data
		cpnt = (uint8_t *)&g_SmartBattData;

		// Verify main smart battery data area
		cCSum = 0;
		for (dwCnt = 0; dwCnt < SB_DATA_SIZE; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+SB_DATA_ADD+dwCnt);
		}
		if (cCSum) // Bad checksum?
		{
			local_print("PM_Batt: Bad SB battery checksum\n");
			DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Check main area data type
		if (g_SmartBattData.BattDataType != SB_SUPPORTED_TYPE)
		{
			local_print("PM_Batt: Bad SB battery data type\n");
			DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Verify IEEE 1725 data area
		cCSum = 0;
		for (dwCnt = 0; dwCnt < SB_1725_DATA_SIZE; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+SB_1725_DATA_ADD+dwCnt);
		}
		if (cCSum || SUPPORTED_1725_TYPE != g_SmartBattData._1725_DataType) // Bad checksum or data type?
		{
			if (cCSum)
				local_print("PM_Batt: Bad SB 1725 checksum, defaults used\n");
			else
				local_print("PM_Batt: Bad SB 1725 type, defaults used\n");

			// Use default data from GB driver
			g_SmartBattData.BattMaxDTemp = Pointers->BattMaxDTemp;
			g_SmartBattData.BattMinDTemp = Pointers->BattMinDTemp;
			g_SmartBattData.BattFastCurr = Pointers->BattFastCurr;
			g_SmartBattData.BattMaxCVolt = 4200;
		}

		// Verify health data area
		cCSum = 0;
		for (dwCnt = 0; dwCnt < SB_HEALTH_DATA_SIZE; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+SB_HEALTH_DATA_ADD+dwCnt);
		}
		if (cCSum || SUPPORTED_HEALTH_TYPE != g_SmartBattData.Health_DataType) // Bad checksum or data type?
		{
			if (cCSum)
				local_print("PM_Batt: Bad SB health checksum, defaults used\n");
			else
				local_print("PM_Batt: Bad SB health type, defaults used\n");

			// Use default data
			for (dwCnt = 1; dwCnt < SB_HEALTH_DATA_SIZE; ++dwCnt)
			{
				*(cpnt+SB_HEALTH_DATA_ADD+dwCnt) = 0;
			}
			g_SmartBattData.Health_DataType = SUPPORTED_HEALTH_TYPE;
		}

		// Verify battery life data
		cCSum = 0;
		for (dwCnt = 0; dwCnt < SB_LIFE_SIZE; ++dwCnt)  // Check checksum on first area
		{
			cCSum = cCSum + *(cpnt+SB_LIFE_ADD1+dwCnt);
		}
		if (cCSum) // Bad checksum?
		{  // Try next area
			cCSum = 0;
			for (dwCnt = 0; dwCnt < SB_LIFE_SIZE; ++dwCnt)  // Check checksum on second area
			{
				cCSum = cCSum + *(cpnt+SB_LIFE_ADD2+dwCnt);
			}
			if (cCSum) // Bad checksum?
			{
				local_print("PM_Batt: Bad SB battery life data\n");
				// Set Error Data
				g_SmartBattData.BattLife1 = BAD_LIFE_DATA;
			}
			else  // Copy over good data
			{
				g_SmartBattData.BattLife1 = g_SmartBattData.BattLife2;

				// Trigger life data update
// ***FIX***  Add code to trigger update
			}
		}

		// Update health record if needed
		// Check for valid date
		if (0 == g_SmartBattData.DateFirstUse[0])
		{ // Need to set date
			local_print("PM_Batt: Setting SB date\n");

			// Set update flag
			g_bWriteMPA2Health = true;
		}

		// Check for valid life data
		if (BAD_LIFE_DATA == g_SmartBattData.BattLife1)
		{ // bad life data
			g_SmartBattData.BattHealth = BATT_SOH_UNHEALTHY;  // Set to unhealthy
			// Set update flag
			g_bWriteMPA2Health = true;
		}
		else
		{  // Check health level
			if (Pointers->dwCycleCountThreshold < (g_SmartBattData.BattLife1/g_SmartBattData.BattRated))
			{  // Unhealthy
				// check for not currently marked as unhealthy
				if (g_SmartBattData.BattHealth != BATT_SOH_UNHEALTHY)
				{  // Change to bad
					g_SmartBattData.BattHealth = BATT_SOH_UNHEALTHY;
					// Set update flag
					g_bWriteMPA2Health = true;
				}
			}
			else
			{
				// check for not currently marked as healthy
				if (g_SmartBattData.BattHealth != BATT_SOH_HEALTHY)
				{  // Change to good
					g_SmartBattData.BattHealth = BATT_SOH_HEALTHY;
					// Set update flag
					g_bWriteMPA2Health = true;
				}
			}
		}

		// Set common data
		// ---- Part Number ----
		// Default Battery Prefix Number
		dwBattPrefixNo = DEFAULT_BATTERY_PREFIX_NOS;

		// Find out the battery prefix nos from the lookup table by searching the corresponding battery family number.
		for(wTabCnt=0; wTabCnt<(sizeof(g_StructSmartBattPrefixLookupTab)/sizeof(SMART_BATTERY_PREFIX_LOOKUP_TAB)); wTabCnt++)
		{
			if((g_SmartBattData.BattPartNum/10000) == g_StructSmartBattPrefixLookupTab[wTabCnt].g_dwBatteryFamilyNo)
			{
				dwBattPrefixNo = g_StructSmartBattPrefixLookupTab[wTabCnt].g_dwBatteryPrefixNo;
			}
		}

		//Battery Family Number
		dwBattFamilyNo = g_SmartBattData.BattPartNum/10000;

		// Find out the correct battery family number lookup table by searching the corresponding incorrect battery family number.
		for(wTabCnt=0; wTabCnt<(sizeof(g_StructSmartBattFamilyLookupTab)/sizeof(SMART_BATTERY_FAMILY_LOOKUP_TAB)); wTabCnt++)
		{
			if((g_SmartBattData.BattPartNum/10000) == g_StructSmartBattFamilyLookupTab[wTabCnt].g_dwIncorrectBattFamilyNo)
			{
				dwBattFamilyNo = g_StructSmartBattFamilyLookupTab[wTabCnt].g_dwCorrectBattFamilyNo;
			}
		}

		// See 70-62284-01 Smart Programming Guide for format of part number stored in E2
		// Typical data in battery E2: 713630101 or 1279090121
		// Typical data format to convert to: 82-71363-01 Rev.01 or 82-127909-01 Rev. A resp.

		// From Document 70-62284-01: 	If the last 2 digits <  21 then numeric revision 00 to 20
		//								If the last 2 digits >= 21 then numeric alpha, 21=A, 22=B etc.
		if (g_SmartBattData.BattPartNum%100 < 21)
		{
			local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%02d-%06d-%02d Rev.%02d", dwBattPrefixNo, dwBattFamilyNo, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100);
			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%02d-%06d-%02d Rev.%02d", dwBattPrefixNo, dwBattFamilyNo, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100);
		}
		else
		{
			local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%02d-%06d-%02d Rev. %c", dwBattPrefixNo, dwBattFamilyNo, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100 - 21 + 'A');
			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%02d-%06d-%02d Rev. %c", dwBattPrefixNo, dwBattFamilyNo, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100 - 21 + 'A');
		}

		// See 70-62284-01 Smart Programming Guide for format of part number stored in E2
		// Typical data in battery E2: 655870105
		// Typical data format to convert to: 21-65587-01 Rev.05

		// From Document 70-62284-01: 	If the last 2 digits <  21 then numeric revision 00 to 20
		//								If the last 2 digits >= 21 then numeric alpha, 21=A, 22=B etc.
		if (g_SmartBattData.BattPartNum%100 < 21)
		{
			local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"21-%05d-%02d Rev.%02d", g_SmartBattData.BattPartNum/10000, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100);
//			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"21-%05d-%02d Rev.%02d", g_SmartBattData.BattPartNum/10000, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100);
		}
		else
		{
			local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"21-%05d-%02d Rev. %c", g_SmartBattData.BattPartNum/10000, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100 - 21 + 'A');
//			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"21-%05d-%02d Rev. %c", g_SmartBattData.BattPartNum/10000, (g_SmartBattData.BattPartNum/100)%100, g_SmartBattData.BattPartNum%100 - 21 + 'A');
		}

		// Date
		Pointers->myear = ((g_SmartBattData.BattDate[2] & 0x0f) << 8) | g_SmartBattData.BattDate[1];
		Pointers->mmonth = g_SmartBattData.BattDate[2] >> 4;
		Pointers->mday = g_SmartBattData.BattDate[0];

	// ***FIX*** For Smart, Replace the below code with the newer A0000 encoding scheme as per Chris.
		// ---- ID ----
		// Battery manufacturers have been known to start serial numbers back at zero.
		// The date will be added to high bytes of serial number.
		// Hopefully serial numbers will not be duplicated on the same date.
		// 8 bytes = 2 byte year, 1 byte day, 1 byte month, 4 byte serial number
//		_stprintf(g_szBatteryID, _T("%04x%02x%02x%08x"),
//						Pointers->myear,Pointers->mday,Pointers->mmonth,g_SmartBattData.BattID);

		// Serial number
		// In A0000 format. from A0000 to Z9999 are valid.
		// Encoded by multiplying the letter-'A' times 10,000 and adding the number

		// Fix for MC32 batts, clear upper byte
		g_SmartBattData.BattID &= 0x00ffffff;

		// Check for valid ID
		if (g_SmartBattData.BattID > 259999)
			local_sprint(Pointers->batteryID,SER_NUM_LENGTH,"ERROR");
		else // Should be OK
		{
			wTabCnt = g_SmartBattData.BattID/10000;  // Get leading character
			local_sprint(Pointers->batteryID,SER_NUM_LENGTH,"%c%04d",(uint8_t)wTabCnt+'A',g_SmartBattData.BattID-(wTabCnt*10000));
		}

		Pointers->type = BATTERY_CHEMISTRY_LION;
		Pointers->batteryRatedCapacity = g_SmartBattData.BattRated;
		Pointers->battFaireLevel = g_SmartBattData.BattFaireLevel;
		Pointers->battUnfaireLevel = g_SmartBattData.BattUnfaireLevel;
		Pointers->battLowLevel = g_SmartBattData.BattLowLevel;
		Pointers->AbnormalCurrent = g_SmartBattData.AbnormalCurrent;
		Pointers->BattFastCurr = g_SmartBattData.BattFastCurr;
		Pointers->ChargeSlowMins = g_SmartBattData.SlowChrgTO * 10;
		Pointers->ChargeFastMins = g_SmartBattData.FastChrgTO * 10;
		Pointers->ChargeUp_mV = g_SmartBattData.BattMaxCVolt;
		Pointers->SlowFastCharge_mV = g_SmartBattData.SlowFastThreshold;
		Pointers->BattSlowCurr = 300;  // MPA2 only supported 100ma, MPA3 min is 300ma
		Pointers->MinBattSlowCurr = 0;
		Pointers->NearlyDoneCurrent = g_SmartBattData.NearlyDoneCurrent;
		Pointers->DoneCurrent = g_SmartBattData.DoneCurrent;
		Pointers->RechargeVoltageDelta = g_SmartBattData.BattMaxCVolt - g_SmartBattData.RechargeVoltage;
		Pointers->MinChrgTemp = g_SmartBattData.MinChrgTemp;
		Pointers->ColdOnTemp = g_SmartBattData.ColdOnTemp;
		Pointers->MaxChrgTemp = g_SmartBattData.MaxChrgTemp;
		Pointers->HotOnTemp = g_SmartBattData.HotOnTemp;
		Pointers->RM = 0;
		Pointers->FCC = 0;
		Pointers->TTE = 0xffff;
		Pointers->TTF = 0xffff;
		Pointers->ARTTE = 0xffff;
		Pointers->dwSecSinceFirstUse = 0;
		Pointers->BattMinDTemp = g_SmartBattData.BattMinDTemp;
		Pointers->BattMaxDTemp = g_SmartBattData.BattMaxDTemp;
		Pointers->fyear = ((g_SmartBattData.DateFirstUse[2] & 0x0f) << 8) | g_SmartBattData.DateFirstUse[1];
		Pointers->fmonth = g_SmartBattData.DateFirstUse[2] >> 4;
		Pointers->fday = g_SmartBattData.DateFirstUse[0];
		Pointers->TotalAccCharge = 0;  // No Zebra charge on smart batts
		Pointers->TotalAccChargeAll = g_SmartBattData.BattLife1;  // Set total charge acc
		Pointers->BattFlags = 0;  // No flags support

		// Battery health stuff
		Pointers->battHealth = g_SmartBattData.BattHealth;
		g_dwAggregateCharge = g_SmartBattData.BattLife1;
		g_GiftedBattData.SOH = 0; // Fudge MPA3 value

		if (g_SmartBattData.BattLife1 != BAD_LIFE_DATA) // Do we have valid life data?
		{
			g_dwDoChgAcc = true;  // Enable charge acc stuff
			DoAccTime = local_GetStopTime(120000); // Reset charge accumulation timer
			g_dwLeftOverChg = 0;  // Clear left over charge
			Pointers->CycleCount = g_SmartBattData.BattLife1 / g_SmartBattData.BattRated;  // Set cycle count
		}
		else // Clear cycle count
			Pointers->CycleCount = 0;  // Set cycle count

		ChargerInit();  // Reset charger stuff

		g_bReadTempChip = true; // Trigger temp read

		g_BattType = BATT_SMART;  // Set to smart battery type
		g_dwBattDetectState = BATT_DET_IDLE; // Done
		Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
		g_dwBattCommErrCnt = 0; // Clear comm error counter
		ShowBatteryData();  // Show battery data if needed

		// Call battery found function
		local_BatteryFound(FOUND_NEW_BATT);
		break;

	case BATT_DET_CHECK_VOLT:
CheckVolt:
		// Get battery voltage
		dwBcnt = local_GetBatteryVoltage();

		// Is it OK?
		if (dwBcnt > MIN_BATT_VOLTS)
		{  // Yes it's OK
			++dwVoltOkCnt; // Increment count of OK times

			if (dwVoltOkCnt > 2) // Must be good three times
			{ // Long enough
// The below line causes a restart of the battery detection, not needed
// Set batt type before call to invalid battery!!!  *** FIX
//				local_InvalidBattery(BM_BATTERY_LOOKING);  // Set back to looking for battery
				// local_StopCharger(); // Shut down charger

				// Check for using value tier batts
				if (Pointers->UseVTbatt)
				{
					// Setup read of auth chip data
					g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
					g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
					g_BattTrans.byBattDataSize1 = ZA_MAX_SIZE; // Read whole chip

					g_BattTrans.byBattChipAddr2 = 0; // No second transaction

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_VT1; // Check data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES; // Set retry counter
					}
					else // Retries?
					{
						--dwTries;
						if (!dwTries)
						{
							RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C32\n"));
							DetectFailCode = CHG_COMM_ERROR;
							goto NoBatteryFound;
						}
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
				}
				else
				{
					// Setup read of device type from GG
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_DEVICE_TYPE & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_DEVICE_TYPE >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH2; // Check control write
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES; // Set retry counter
					}
					else // Retries?
					{
						--dwTries;
						if (!dwTries)
						{
							RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C3\n"));
							DetectFailCode = CHG_COMM_ERROR;
							goto NoBatteryFound;
						}
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
				}
			}
			else  // Need to check again
				dwLoop = FAST_LOOP/20;  // Very short loop delay

		}
		else
		{  // Battery voltage is low!
			// Did we already enable the charger?
			if(!EnabledCharger)
			{  // Nope
				local_EnableCharger(1);  // Turn on charging
				EnabledCharger = 1; // Set turned on charger flag
			}

			dwVoltOkCnt = 0; // Reset counter

			// Added code to do a timeout for CQ:119520
			// Check for timeout
//			++dwVoltOkWaitCnt;
//			if ((15 * 60 * 10) < dwVoltOkWaitCnt) // Longer than 15 minutes? (.1 second loops)
			if (local_PastTime(dwBDStopTime)) // Been longer than 15 mins?
			{ // Bad battery, give up
				local_StopCharger(); // Shut down charger
				local_print("PM_Batt: Can't raise battery voltage\n");
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			dwLoop = NORM_LOOP;  // Wait 5 sec to check again

			// Set to 0% capacity only if the reading is below empty
			// battery voltage and not 0V  [EE-3885]
			if (dwBcnt != 0 && dwBcnt < Pointers->EmptyBattVolt)
			{
				Pointers->battCapacity = 0;
				local_NewData(1);
			}
		}
		break;

	case BATT_DET_VT1: // Check value tier auth data read
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Got VT data!
				Pointers->BatteryType = GB_VALUE; // Set to value tier battery

				// Copy over data
				memcpy((void *)(&g_ValueTierData),g_BattTrans.byBattDataBuff1,sizeof(g_ValueTierData));

				// Swap capacity bytes
				g_ValueTierData.ManfCapacity = (g_ValueTierData.ManfCapacity >> 8) | (g_ValueTierData.ManfCapacity << 8);

				// Start read of large EEPROM (May not be there)
				g_BattTrans.byBattChipAddr1 = VT_EEPROM | 0x01;  // Set EEPROM address and read
				g_BattTrans.byLargeEEPROMAddr = 1;  // Set to large EEPROM addressing
				g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
				g_BattTrans.byBattDataAddr1_2 = 0;
				g_BattTrans.byBattDataSize1 = 64; // Read first 64 bytes

				g_BattTrans.byBattChipAddr2 = 0; // No second transaction

				Have_VT_EEPROM = false;  // Default to no EEPROM
				VT_EEPROM_Offset = 0;  // Set to offset to start of EEPROM

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_VT2; // Check data
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C32A\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of auth chip data
					g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
					g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
					g_BattTrans.byBattDataSize1 = ZA_MAX_SIZE; // Read whole chip

					g_BattTrans.byBattChipAddr2 = 0; // No second transaction

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_VT1; // Check data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else // Retries?
					{
						--dwTries;
						if (!dwTries)
						{
							RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C33\n"));
							DetectFailCode = CHG_COMM_ERROR;
							goto NoBatteryFound;
						}
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C36\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt4A\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_VT2: // Check value tier data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Got VT EEPROM data!
				if (0 == VT_EEPROM_Offset)  // First read?
				{ // Get the size of the blob
					VT_EEPROM_BlobSize = g_BattTrans.byBattDataBuff1[0] | (g_BattTrans.byBattDataBuff1[1] << 8);
					if (VT_EEPROM_BlobSize > GB_MAX_BLOB)  // Make sure it's not too big
						VT_EEPROM_BlobSize = GB_MAX_BLOB;
					Have_VT_EEPROM = true;  // Found an EEPROM!
				}

				// Copy over data
				memcpy((void *)(Pointers->Blob+VT_EEPROM_Offset),g_BattTrans.byBattDataBuff1,64);
				VT_EEPROM_Offset += 64;  // Increment offset

				if (VT_EEPROM_Offset < VT_EEPROM_BlobSize)  // More to go?
				{  // Not done reading yet, get the next block
					g_BattTrans.byBattChipAddr1 = VT_EEPROM | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 1;  // Set to large EEPROM addressing
					g_BattTrans.byBattDataAddr1 = VT_EEPROM_Offset >> 8;
					g_BattTrans.byBattDataAddr1_2 = VT_EEPROM_Offset & 0xff;
					g_BattTrans.byBattDataSize1 = 64; // Read first 64 bytes

					g_BattTrans.byBattChipAddr2 = 0; // No second transaction

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_VT2; // Check data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES; // Set retry counter
					}
					else
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C32B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto NoBatteryFound;
					}
					break;
				}
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of auth chip data
					g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
					g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
					g_BattTrans.byBattDataSize1 = ZA_MAX_SIZE; // Read whole chip

					g_BattTrans.byBattChipAddr2 = 0; // No second transaction

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_VT1; // Check data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C33A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto NoBatteryFound;
					}
					break;
				}
				else  // No EEPROM
				{
					Have_VT_EEPROM = false;  // Didn't find an EEPROM!
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt4A\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
			break;
		}

		// Validate data
		// Verify main checksum
		cCSum = 0;
		cpnt = (uint8_t *)&g_ValueTierData;
		for (dwCnt = 0; dwCnt <= 431; ++dwCnt)
			cCSum += cpnt[dwCnt];

		if (cCSum)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad main VT checksum: VT1\n"));
			DetectFailCode = CHG_MEM_ERROR;
			goto BadMPA3Battery;
		}

		// Check format type
		if ((1 != g_ValueTierData.FormatRev) && (2 != g_ValueTierData.FormatRev))
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad VT Format Revision: %d   VT11\n",g_ValueTierData.FormatRev));
			DetectFailCode = CHG_MEM_ERROR;
			goto BadMPA3Battery;
		}

		// Verify second DTSI checksum
		if (g_ValueTierData.FormatRev >= 2)
		{
			cCSum = g_ValueTierData.ASD2_Checksum;
			for (dwCnt = 0; dwCnt < VT_ASD2_SIZE; ++dwCnt)
				cCSum += g_ValueTierData.ASD2[dwCnt];

			if (cCSum)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad second DTSI block checksum: VT15\n"));
				goto BadMPA3Battery;
			}
		}

		// Check charger control data
		cCSum = 0;
		cpnt = (uint8_t *)&g_ValueTierData.ChargerCtrl;
		for (dwCnt = 0; dwCnt < sizeof(CHARGER_CTRL_VT_t); ++dwCnt)
			cCSum += cpnt[dwCnt];

		if (cCSum)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad charger control checksum: VT2\n"));
			DetectFailCode = CHG_MEM_ERROR;
			goto BadMPA3Battery;
		}

		// Check JEITA data
		cCSum = 0;
		cpnt = (uint8_t *)&g_ValueTierData.JEITA;
		for (dwCnt = 0; dwCnt < sizeof(EX_TEMP_CHARGING_EP_VT_t); ++dwCnt)
			cCSum += cpnt[dwCnt];

		if (cCSum)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad JEITA checksum: VT3\n"));
			DetectFailCode = CHG_MEM_ERROR;
			goto BadMPA3Battery;
		}

		// Check cell ident data
		cCSum = 0;
		cpnt = (uint8_t *)&g_ValueTierData.Ident;
		for (dwCnt = 0; dwCnt < sizeof(CELL_IDENT_t); ++dwCnt)
			cCSum += cpnt[dwCnt];

		if (cCSum)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad Ident checksum: VT4\n"));
		}

		// Check first health block
		cCSum = 0;
		cpnt = (uint8_t *)&g_ValueTierData.Health1;
		for (dwCnt = 0; dwCnt < sizeof(BATT_HEALTH_VT_t); ++dwCnt)
			cCSum += cpnt[dwCnt];

		if (cCSum)  // First block bad
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad VT health data1: VT5\n"));

			// Check second health block
			cCSum = 0;
			cpnt = (uint8_t *)&g_ValueTierData.Health2;
			for (dwCnt = 0; dwCnt < sizeof(BATT_HEALTH_VT_t); ++dwCnt)
				cCSum += cpnt[dwCnt];

			if (cCSum)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad VT health data2: VT6\n"));
				DetectFailCode = CHG_MEM_ERROR;
				goto BadMPA3Battery;
			}
			if (0 != g_ValueTierData.Health2.RecordType)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad VT Health Type: %d   VT12\n",g_ValueTierData.Health2.RecordType));
				DetectFailCode = CHG_MEM_ERROR;
				goto BadMPA3Battery;
			}

			// Use data from second block
			g_ValueTierData.Health1.Health = g_ValueTierData.Health2.Health;
			g_ValueTierData.Health1.RecordType = g_ValueTierData.Health2.RecordType;

			// Trigger update of first block
			g_bWriteVTH1 = true;
		}
		else  // Check second block
		{
			// First check block1 record type!
			if (0 != g_ValueTierData.Health1.RecordType)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad VT Health Type: %d   VT13\n",g_ValueTierData.Health1.RecordType));
				DetectFailCode = CHG_MEM_ERROR;
				goto BadMPA3Battery;
			}

			// Check second health block
			cCSum = 0;
			cpnt = (uint8_t *)&g_ValueTierData.Health2;
			for (dwCnt = 0; dwCnt < sizeof(BATT_HEALTH_VT_t); ++dwCnt)
				cCSum += cpnt[dwCnt];

			if (cCSum || (0 != g_ValueTierData.Health2.RecordType))
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad health data block2: VT14\n"));

				// Use block 1 data instead
				g_ValueTierData.Health2.Health = g_ValueTierData.Health1.Health;
				g_ValueTierData.Health2.RecordType = g_ValueTierData.Health1.RecordType;

				// Trigger update of second block
				g_bWriteVTH2 = true;
			}
		}

		// Check first aggregate charge block
		cCSum = 0;
		cpnt = (uint8_t *)&g_ValueTierData.AggCharge1;
		for (dwCnt = 0; dwCnt < sizeof(AGG_CHARGE_VT_t); ++dwCnt)
			cCSum += cpnt[dwCnt];

		if (cCSum)  // First block bad
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad agg charge data: VT8\n"));

			// Check Second aggregate charge block
			cCSum = 0;
			cpnt = (uint8_t *)&g_ValueTierData.AggCharge2;
			for (dwCnt = 0; dwCnt < sizeof(AGG_CHARGE_VT_t); ++dwCnt)
				cCSum += cpnt[dwCnt];

			if (cCSum)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad agg charge data: VT9\n"));
				DetectFailCode = CHG_MEM_ERROR;
				goto BadMPA3Battery;
			}

			// Use data from second block
			g_ValueTierData.AggCharge1.Partial = g_ValueTierData.AggCharge2.Partial;
			g_ValueTierData.AggCharge1.Cycles = g_ValueTierData.AggCharge2.Cycles;

			// Trigger update of first block
			g_bWriteVTAC1 = true;
		}
		else  // Check second block
		{
			// Check Second aggregate charge block
			cCSum = 0;
			cpnt = (uint8_t *)&g_ValueTierData.AggCharge2;
			for (dwCnt = 0; dwCnt < sizeof(AGG_CHARGE_VT_t); ++dwCnt)
				cCSum += cpnt[dwCnt];

			if (cCSum)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad agg charge data: VT10\n"));

				// Use data from first block
				g_ValueTierData.AggCharge2.Partial = g_ValueTierData.AggCharge1.Partial;
				g_ValueTierData.AggCharge2.Cycles = g_ValueTierData.AggCharge1.Cycles;

				// Trigger update of second block
				g_bWriteVTAC2 = true;
			}
		}

		// Copy over global data
		// Set static data
		Pointers->myear = ((g_ValueTierData.Date[2] & 0x0f) << 8) | g_ValueTierData.Date[1];
		Pointers->mmonth = g_ValueTierData.Date[2] >> 4;
		Pointers->mday = g_ValueTierData.Date[0];
		Pointers->type = BATTERY_CHEMISTRY_LION;

		// Reformat part number
		for(dwCnt = 0, dwBcnt = 0; dwCnt < 20; ++dwCnt)
		{
			if ('%' == g_ValueTierData.PartNumber[dwCnt])
			{
				sz_PN[dwBcnt++] = ' ';
				sz_PN[dwBcnt++] = 'R';
				sz_PN[dwBcnt++] = '.';
			}
			else
			{
				sz_PN[dwBcnt++] = g_ValueTierData.PartNumber[dwCnt];
			}
		}
		sz_PN[20] = 0;  // Add terminator at max VT part number length

		// Do longer New part number
		local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%s", sz_PN);

		// Do older Ex part number
		local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%s", sz_PN);

		// Do clipped part number field
		sz_PN[18] = 0;  // Add terminator at max Moto part number length to fit into 19 char string w/rev.
		local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"%s", sz_PN);

		memcpy(Pointers->batteryID,g_ValueTierData.SerialNumber,5);
		Pointers->batteryID[5] = 0;  // Add terminator

		// Copy over the JEITA data
		Pointers->ExCharge.StopTemp = g_ValueTierData.JEITA.StopTemp;
		Pointers->ExCharge.RecMinTemp = g_ValueTierData.JEITA.RecMinTemp;
		Pointers->ExCharge.RecMaxTemp = g_ValueTierData.JEITA.RecMaxTemp;
		Pointers->ExCharge.Hysteresis = g_ValueTierData.ChargerCtrl.Hysteresis;
		for (dwCnt = 0; dwCnt < 5; ++dwCnt)
		{
			Pointers->ExCharge.TempRange[dwCnt].StartTemp = g_ValueTierData.JEITA.TempRange[dwCnt].StartTemp;
			for (dwBcnt = 0; dwBcnt < 3; ++dwBcnt)
			{
				Pointers->ExCharge.TempRange[dwCnt].Voltage[dwBcnt] = g_ValueTierData.JEITA.TempRange[dwCnt].Voltage[dwBcnt];
				Pointers->ExCharge.TempRange[dwCnt].Current[dwBcnt] = g_ValueTierData.JEITA.TempRange[dwCnt].Current[dwBcnt];
			}
		}

		// Do we have usefull voltage data?
		if (0 == g_ValueTierData.ShipMode.HighVoltage
			|| 0 == g_ValueTierData.ShipMode.LowVoltage)
		{  // Nope
			RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode voltage data, using defaults\n"));
			Pointers->dwShipModeVoltHi = g_ShipModeDefaults.HighVoltage;
			Pointers->dwShipModeVoltLow = g_ShipModeDefaults.LowVoltage;
		}
		else
		{  // Have voltage values
			Pointers->dwShipModeVoltHi = g_ValueTierData.ShipMode.HighVoltage;
			Pointers->dwShipModeVoltLow = g_ValueTierData.ShipMode.LowVoltage;
		}

		// Do we have usefull capacity data?
		if (0 == g_ValueTierData.ShipMode.HighCapacity
			|| 0 == g_ValueTierData.ShipMode.LowCapacity)
		{  // Nope
			RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode capacity data, using defaults\n"));
			Pointers->dwShipModeCapHi = g_ShipModeDefaults.HighCapacity;
			Pointers->dwShipModeCapLow = g_ShipModeDefaults.LowCapacity;
		}
		else
		{  // Have capacity values
			Pointers->dwShipModeCapHi = g_ValueTierData.ShipMode.HighCapacity;
			Pointers->dwShipModeCapLow = g_ValueTierData.ShipMode.LowCapacity;
		}

		// Check for forcing invalid batt
		if (FORCE_INVALID)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Force Bad batt!!!\n"));
			DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Set common data
		Pointers->batteryRatedCapacity = g_ValueTierData.ManfCapacity;
		Pointers->battFaireLevel = g_ValueTierData.BatteryLow;
		Pointers->battUnfaireLevel = g_ValueTierData.BatteryVeryLow;
		Pointers->battLowLevel = g_ValueTierData.BatteryCritical;
		Pointers->AbnormalCurrent = g_ValueTierData.ChargerCtrl.AbnormalCurr;
		Pointers->ChargeSlowMins = g_ValueTierData.ChargerCtrl.SlowChrgTimeout;
		Pointers->ChargeFastMins = g_ValueTierData.ChargerCtrl.FastChrgTimeout;
		Pointers->SlowFastCharge_mV = g_ValueTierData.ChargerCtrl.SlowFastVolt;
		Pointers->NearlyDoneCurrent = g_ValueTierData.ChargerCtrl.NearlyDone;
		Pointers->DoneCurrent = g_ValueTierData.ChargerCtrl.Done;
		Pointers->BattSlowCurr = g_ValueTierData.ChargerCtrl.SlowChrgHighFaultCurr;
		Pointers->MinBattSlowCurr = g_ValueTierData.ChargerCtrl.SlowChrgLowFaultCurr;
		Pointers->BattFastCurr = 0;
		Pointers->MinChrgTemp = 0;
		Pointers->ColdOnTemp = 0;
		Pointers->MaxChrgTemp = 0;
		Pointers->HotOnTemp = 0;
		Pointers->ChargeUp_mV = 0;
		Pointers->Authentic = 1;
		Pointers->BattMinDTemp = g_ValueTierData._1725DiscLowLimit;
		Pointers->BattMaxDTemp = g_ValueTierData._1725DiscHighLimit;
		Pointers->BattFlags = g_ValueTierData._660Data.Flags;
		Pointers->MinStartupVolt = g_ValueTierData._660Data.MinStartupVolt;
		Pointers->ThermCoff = (uint32_t)g_ValueTierData._660Data.ThermCoff[0];
		Pointers->ThermCoff |= ((uint32_t)g_ValueTierData._660Data.ThermCoff[1]) << 8;
		Pointers->ThermCoff |= ((uint32_t)g_ValueTierData._660Data.ThermCoff[2]) << 16;
		Pointers->UVLO = g_ValueTierData._660Data.UVLO;
		Pointers->OVLO = g_ValueTierData._660Data.OVLO;
		Pointers->CutOff = g_ValueTierData._660Data.CutoffVolt;

		// Set total charge, cycle count
		g_dwAggregateCharge = (u32)g_ValueTierData.AggCharge1.Cycles * (u32)g_ValueTierData.ManfCapacity;
		g_dwAggregateCharge += (u32)g_ValueTierData.AggCharge1.Partial * (u32)g_ValueTierData.ManfCapacity / 100;
		Pointers->TotalAccChargeAll = g_dwAggregateCharge; // Save charge from all devices
		Pointers->TotalAccCharge  = g_dwAggregateCharge; // Save charge from zebra devices
		Pointers->CycleCount = g_ValueTierData.AggCharge1.Cycles;
		g_dwDoChgAcc = true;  // Enable charge acc stuff
		VT_CheckHealth(); // Check health level

		Pointers->CurTemp = local_GetBatteryTemp(); // Set new temp
		Pointers->Voltage = local_GetBatteryVoltage(); // Set new voltage
		Pointers->Current = local_GetBatteryCurrent(); // Set new current

		DoAccTime = local_GetStopTime(120000); // Reset charge accumulation timer

		// Copy over architecture specific data
		if (!Have_VT_EEPROM)
		{  // Copy over the Auth chip data (EEPROM data is already there if found)
			for (dwCnt = 0; dwCnt < VT_ASD1_SIZE; ++dwCnt)
				Pointers->Blob[dwCnt] = g_ValueTierData.ASD1[dwCnt];
			for (dwCnt = 0; dwCnt < VT_ASD2_SIZE; ++dwCnt)
				Pointers->Blob[dwCnt+VT_ASD1_SIZE] = g_ValueTierData.ASD2[dwCnt];
		}
		else
		{  // Check EEPROM data checksum
			cCSum = 0;
			for (dwCnt = 0; dwCnt < VT_EEPROM_BlobSize; ++dwCnt)
				cCSum += Pointers->Blob[dwCnt];

			if (cCSum)
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad VT EEPROM checksum\n"));
				// Flush blob data
				for (dwCnt = 0; dwCnt < GB_MAX_BLOB; ++dwCnt)
					Pointers->Blob[dwCnt] = 0;
			}
		}

		ChargerInit();  // Reset charger stuff

		// Return found VT battery!
		g_BattType = BATT_VT; // Set to VT battery
		g_dwBattDetectState = BATT_DET_IDLE; // Done
		Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
		g_dwBattCommErrCnt = 0; // Clear comm error counter
		ResetRateLimit();
		ShowBatteryData();  // Show battery data if needed

		// Call battery found function
		local_BatteryFound(FOUND_NEW_BATT);


		break;

	case BATT_DET_VTCHK:  // Check for same VT batt
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Got VT data!
				// Check first 31 btyes to make sure they match
				// This will check the data fomat, checksum, part#, rev, and date

				// Validate data
				cpnt = (uint8_t *)(&g_ValueTierData);

				for (dwCnt = 0; dwCnt < 31; ++dwCnt)
				{
					if (cpnt[dwCnt] != g_BattTrans.byBattDataBuff1[dwCnt])
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: VT ID Missmatch @%d\n",dwCnt));
						DidReset = 0; // Clear did reset flag
						goto StartBattDetect;  // Just restart detect
					}
				}

				// Same batt, start using it
				ChargerInit();  // Reset charger stuff

				g_BattType = BATT_VT; // Set to VT battery
				g_dwBattDetectState = BATT_DET_IDLE; // Done
				Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
				g_dwBattCommErrCnt = 0; // Clear comm error counter
				ResetRateLimit();
				local_BatteryFound(FOUND_OLD_BATT);  // Call battery found function, not new batt.
			}
			else  // No good, try restarting.
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results 119A\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 120A\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_AUTH2:  // Check device type
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Found MPA3 Batt!
				Pointers->BatteryType = GB_GIFTED; // Set to MPA3 battery

				// Set EEPROM addr based on Auth chip usage
				if (Pointers->UseAuthData)
					MPA3_eeprom_addr = AUTH_CHIP; // Using auth chip
				else
					MPA3_eeprom_addr = MPA3EEPROM; // Using eeprom

				// Copy over data
				memcpy((void *)(&g_GiftedBattData.M200_DeviceType),g_BattTrans.byBattDataBuff2,2);

				// Check for valid device type
				if (MPA3_GG_DEVICE_TYPE != g_GiftedBattData.M200_DeviceType && NGG_DEVICE_TYPE_OLD != g_GiftedBattData.M200_DeviceType)
				{  // invalid device type
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad Device Type\n"));
					--dwTries;
					if (dwTries)
					{
						// Setup read of device type from GG
						g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
						g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
						g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
						g_BattTrans.byBattDataBuff1[0] = GG_DEVICE_TYPE & 0xff;
						g_BattTrans.byBattDataBuff1[1] = (GG_DEVICE_TYPE >> 8) & 0xff;
						g_BattTrans.byBattDataSize1 = 2; // 2 bytes

						g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
						g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
						g_BattTrans.byBattDataSize2 = 2; // 2 bytes

						g_BattTrans.DoStop = 1; // Force stop in between

						if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						{  // Set next state
							g_dwBattDetectState = BATT_DET_AUTH2; // Check control write
							dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
							dwLoop = FAST_LOOP/20;  // Very short loop delay
							break;
						}
						else
						{
							RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C5B\n"));
							DetectFailCode = CHG_COMM_ERROR;
							goto BadMPA3Battery;
							break;
						}
					}
					else
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Bad Device TypeA\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
						break;
					}
				}

				// Check for PP+ device type
				if (MPA3_GG_DEVICE_TYPE == g_GiftedBattData.M200_DeviceType)
				{  // Is old gas gauge
					Pointers->GG_DeviceType = g_GiftedBattData.M200_DeviceType;
					Pointers->ARpnt = &g_GiftedBattData.AR; // Set reg dump pointer

					// Setup read of status register
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Do read of status reg
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH3; // Check hibernate and sealed bits
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES;
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C5C\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else // Must be a V2 gas gauge
				{
					// Setup read of device type from GG
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_DEVICE_TYPE & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_DEVICE_TYPE >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_NGG1; // Check device type
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES; // Set retry counter
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C5D\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of device type from GG
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0;  // No second transaction
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_DEVICE_TYPE & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_DEVICE_TYPE >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH2; // Check control write
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C29\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto NoBatteryFound;
					}
				}
				else if (Pointers->EnableSB) // No more tries left, try Smart Battery if enabled
				{
					// Try reading one byte from temp chip
					g_BattTrans.byBattChipAddr1 = MPA2TEMP | 0x01;  // Set temp chip address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = 1; // Just read config register
					g_BattTrans.byBattDataSize1 = 1;

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_MPA2_FIND; // Set to look for smart batt
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwTries = MPA2_TRIES; // Set retry counter
						dwLoop = FAST_LOOP;  // Short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C35\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto NoBatteryFound;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt32\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt4B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_AUTH3:  // Check hibernate and sealed bits
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check for hibernate/sealed bits still set
				if ((STATUS_LOW_HIBERNATE_BIT & g_BattTrans.byBattDataBuff2[0])
					|| !(STATUS_HIGH_FAS_BIT & g_BattTrans.byBattDataBuff2[1])
					|| !(STATUS_HIGH_SS_BIT & g_BattTrans.byBattDataBuff2[1]))
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Clearing status bits: %02X%02X\n",g_BattTrans.byBattDataBuff2[1],g_BattTrans.byBattDataBuff2[0]));

					// Setup write of hibernate bit
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_SEAL_CHIP & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_SEAL_CHIP >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Setup write of seal bit
					g_BattTrans.byBattChipAddr2 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff2[0] = GG_CLEAR_HIBERNATE & 0xff;
					g_BattTrans.byBattDataBuff2[1] = (GG_CLEAR_HIBERNATE >> 8) & 0xff;
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH4; // Setup check of firmware version
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C4\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{ // Do read of firmware version
					// Setup read of firmware version
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_FW_VERSION & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_FW_VERSION >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH5; // Check firmware version
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C5E\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of status register
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Do read of status reg
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH3; // Check hibernate and sealed bits
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C5F\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results7\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt8\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_AUTH4:  // Start firmware version read
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Setup read of firmware version
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_FW_VERSION & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_FW_VERSION >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataSize2 = 2; // 2 bytes

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_AUTH5; // Check firmware version
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C2\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // More tries?
			{
				--dwTries;
				if (dwTries)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Clearing status bits2: %02X%02X\n",g_BattTrans.byBattDataBuff2[1],g_BattTrans.byBattDataBuff2[0]));

					// Setup write of hibernate bit
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_SEAL_CHIP & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_SEAL_CHIP >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Setup write of seal bit
					g_BattTrans.byBattChipAddr2 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff2[0] = GG_CLEAR_HIBERNATE & 0xff;
					g_BattTrans.byBattDataBuff2[1] = (GG_CLEAR_HIBERNATE >> 8) & 0xff;
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH4; // Setup check of firmware version
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C4A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results7B\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt7\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_AUTH5:  // Read firmware version, start enable RMFCC
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy((void *)(&g_GiftedBattData.M200_FirmwareVer),g_BattTrans.byBattDataBuff2,2);

				// Check for valid firmware version
				if ((g_GiftedBattData.M200_FirmwareVer & 0xff00) != MPA3_GG_FW_VERSION)
				{  // invalid firmware version
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad Firmware Version\n"));
					--dwTries;
					if (dwTries)
					{
						// Setup read of firmware version
						g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
						g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
						g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
						g_BattTrans.byBattDataBuff1[0] = GG_FW_VERSION & 0xff;
						g_BattTrans.byBattDataBuff1[1] = (GG_FW_VERSION >> 8) & 0xff;
						g_BattTrans.byBattDataSize1 = 2; // 2 bytes

						g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
						g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
						g_BattTrans.byBattDataSize2 = 2; // 2 bytes

						if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						{  // Set next state
							g_dwBattDetectState = BATT_DET_AUTH5; // Check firmware version
							dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
							dwLoop = FAST_LOOP/20;  // Very short loop delay
						}
						else  // No good, give up.
						{
							RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C2B\n"));
							DetectFailCode = CHG_COMM_ERROR;
							goto BadMPA3Battery;
						}
						break;
					}
					else
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Bad Firmware VersionA\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
						break;
					}
				}

				// Setup write of ENABLE_RMFCC
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_ENABLE_RMFCC & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_ENABLE_RMFCC >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				// Setup write of FULL_SLEEP
				g_BattTrans.byBattChipAddr2 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff2[0] = GG_SET_FULLSLEEP & 0xff;
				g_BattTrans.byBattDataBuff2[1] = (GG_SET_FULLSLEEP >> 8) & 0xff;
				g_BattTrans.byBattDataSize2 = 2; // 2 bytes

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_SET_CTRL2; // Check control write
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: I2C Err8\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // More tries?
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of firmware version
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_FW_VERSION & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_FW_VERSION >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_AUTH5; // Check firmware version
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C2A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results8\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt9\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_SET_CTRL2:  // Start disable IBAW
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Setup write of DISABLE_IBAW
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_DISABLE_IBAW & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_DISABLE_IBAW >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				// Start read of Manf ID
				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = MFGID_CMD; // Manuf ID
				g_BattTrans.byBattDataSize2 = 8; // 8 bytes

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_GET_GDATA1; // Get gifted data
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C11\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // More tries?
			{
				--dwTries;
				if (dwTries)
				{
					// Setup write of ENABLE_RMFCC
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_ENABLE_RMFCC & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_ENABLE_RMFCC >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Setup write of FULL_SLEEP
					g_BattTrans.byBattChipAddr2 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff2[0] = GG_SET_FULLSLEEP & 0xff;
					g_BattTrans.byBattDataBuff2[1] = (GG_SET_FULLSLEEP >> 8) & 0xff;
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_SET_CTRL2; // Check control write
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: I2C Err8A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results10\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt11\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GET_GDATA1: // Get gifted battery data step 1
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy(g_GiftedBattData.M200_Manf_ID,g_BattTrans.byBattDataBuff2,8);

				// Start read of design capacity
				// Setup I2C structure
				g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = DCAP_CMD; // Design capacity
				g_BattTrans.byBattDataSize1 = 2; // 2 Byte int


				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_GET_GDATA2; // Get gifted data
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C13\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // More tries?
			{
				--dwTries;
				if (dwTries)
				{
					// Setup write of DISABLE_IBAW
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_DISABLE_IBAW & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_DISABLE_IBAW >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Start read of Manf ID
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = MFGID_CMD; // Manuf ID
					g_BattTrans.byBattDataSize2 = 8; // 8 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_GET_GDATA1; // Get gifted data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C11A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results12\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt13\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;
	case BATT_DET_GET_GDATA2: // Get gifted battery data step 2
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				DesignCap = (g_BattTrans.byBattDataBuff1[1] << 8) | g_BattTrans.byBattDataBuff1[0];

				if (Pointers->UseAuthData) // Are we using the auth chip for data?
				{ // Yes, do whole read at once
					// Start read of all battery data
					// Setup I2C structure
					g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = 0; // Start of EEPROM
					g_BattTrans.byBattDataSize1 = 416; // Do all 416 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_GET_GDATA3B; // Get gifted data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP;  // Short loop delay
						dwTries = AUTH_TRIES;  // Set to Auth chip tries
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C14B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{  // Read in 16 byte chunks
					// Start read of first bytes of battery data
					// Setup I2C structure
					g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = 0; // Start of EEPROM
					g_BattTrans.byBattDataSize1 = 16; // Do first 16 bytes

					dwBlkCnt = 0; // Reading first block

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_GET_GDATA3; // Get gifted data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = EEPROM_TRIES;  // Set to EEPROM tries
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C14\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
			else  // More tries?
			{
				--dwTries;
				if (dwTries)
				{
					// Start read of design capacity
					// Setup I2C structure
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = DCAP_CMD; // Design capacity
					g_BattTrans.byBattDataSize1 = 2; // 2 Byte int


					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_GET_GDATA2; // Get gifted data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C13A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results13\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt14\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GET_GDATA3: // Get gifted battery data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				cpnt = (uint8_t *)&g_GiftedBattData;
				MovI2Cdata(g_BattTrans.byBattDataBuff1,cpnt+(dwBlkCnt*16),dwBlkCnt == 3 ? Key2 : Key1,0);

				// Check for last read done
				++dwBlkCnt;
				if (dwBlkCnt >= (Pointers->UseAuthData ? 26 : 32))
				{  // Done, setup first GG data read
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
					g_BattTrans.byBattDataSize1 = 1; // One byte
					g_BattTrans.byBattDataBuff1[0] = MAN_BLK_A; // Manuf data block A

							// Setup read of data block
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
					g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
					g_BattTrans.byBattDataSize2 = 32; // Block Size

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						g_dwBattDetectState = BATT_DET_GET_GDATA5; // Next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C15\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{  // Start next read
					g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					if (dwBlkCnt >= 16)  // Check for address above 256
						g_BattTrans.byBattChipAddr1 |= 0x02;  // Yup, set upper address bit
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = (uint8_t)((dwBlkCnt << 4) & 0xff); // End of last read
					g_BattTrans.byBattDataSize1 = 16; // Do rest of data


					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwTries = EEPROM_TRIES;  // Set to EEPROM tries
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C16\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					if (dwBlkCnt >= 16)  // Check for address above 256
						g_BattTrans.byBattChipAddr1 |= 0x02;  // Yup, set upper address bit
						g_BattTrans.byBattDataAddr1 = (uint8_t)((dwBlkCnt << 4) & 0xff); // End of last read
					g_BattTrans.byBattDataSize1 = 16; // Do rest of data


					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C31\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{ // Nope, call it.
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results14\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt15\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GET_GDATA3B: // Get all gifted battery data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				cpnt = (uint8_t *)&g_GiftedBattData;
				for (dwBlkCnt = 0; dwBlkCnt < 26; ++dwBlkCnt)
					MovI2Cdata(g_BattTrans.byBattDataBuff1+(dwBlkCnt*16),cpnt+(dwBlkCnt*16),dwBlkCnt == 3 ? Key2 : Key1,0);

				// Done, setup first GG data read
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
				g_BattTrans.byBattDataSize1 = 1; // One byte
				g_BattTrans.byBattDataBuff1[0] = MAN_BLK_A; // Manuf data block A

				// Setup read of data block
				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
				g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
				g_BattTrans.byBattDataSize2 = 32; // Block Size

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					g_dwBattDetectState = BATT_DET_GET_GDATA5; // Next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C15B\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					g_BattTrans.byBattChipAddr1 = MPA3_eeprom_addr | 0x01;  // Set EEPROM address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = 0; // Start of data
					g_BattTrans.byBattDataSize1 = 416; // Do all of data


					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C31B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{ // Nope, call it.
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results14B\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt15B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP;  // Short loop delay
		}
		break;

	case BATT_DET_GET_GDATA5: // Get gifted battery data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy(g_GiftedBattData.BlockA,g_BattTrans.byBattDataBuff2,GB_MANF_BLK_SIZE);

				// Setup select of next block
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
				g_BattTrans.byBattDataSize1 = 1; // One byte
				g_BattTrans.byBattDataBuff1[0] = MAN_BLK_B; // Manuf data block B

				// Setup read of data block
				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
				g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
				g_BattTrans.byBattDataSize2 = GB_MANF_BLK_SIZE; // Block Size

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					g_dwBattDetectState = BATT_DET_GET_GDATA7; // Next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C18\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					// Setup first GG data read
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
					g_BattTrans.byBattDataSize1 = 1; // One byte
					g_BattTrans.byBattDataBuff1[0] = MAN_BLK_A; // Manuf data block A

					// Setup read of data block
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
					g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
					g_BattTrans.byBattDataSize2 = 32; // Block Size

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						g_dwBattDetectState = BATT_DET_GET_GDATA5; // Next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C15C\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results16\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt17\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GET_GDATA7: // Get gifted battery data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy(g_GiftedBattData.BlockB,g_BattTrans.byBattDataBuff2,GB_MANF_BLK_SIZE);

				// Setup select of next block
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
				g_BattTrans.byBattDataSize1 = 1; // One byte
				g_BattTrans.byBattDataBuff1[0] = MAN_BLK_C; // Manuf data block C

				// Setup read of data block
				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
				g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
				g_BattTrans.byBattDataSize2 = GB_MANF_BLK_SIZE; // Block Size

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{
					g_dwBattDetectState = BATT_DET_GET_GDATA9; // Next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C20\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					// Setup select of next block
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
					g_BattTrans.byBattDataSize1 = 1; // One byte
					g_BattTrans.byBattDataBuff1[0] = MAN_BLK_B; // Manuf data block B

					// Setup read of data block
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
					g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
					g_BattTrans.byBattDataSize2 = GB_MANF_BLK_SIZE; // Block Size

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						g_dwBattDetectState = BATT_DET_GET_GDATA7; // Next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						break;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C18\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results18\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt19\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GET_GDATA9: // Get gifted battery data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				cpnt = (uint8_t *)&g_GiftedBattData.Checksum_c;
				memcpy(cpnt,g_BattTrans.byBattDataBuff2,GB_MANF_BLK_SIZE);

				// Start read of GG regsters
				g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set gas gauge address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = AR_CMD; // Start read at AR register
				if (Pointers->MuxedClock)  // Are we using a clock mux?
					g_BattTrans.byBattDataSize1 = GB_CMD_PARTIAL_READ_SIZE; // yes, read first chunk of registers
				else
					g_BattTrans.byBattDataSize1 = GB_CMD_FULL_READ_SIZE; // No, read all the registers
				RegBytesRead = 0; // Reset bytes read counter

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_GET_GDATA10; // Next state
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES;
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Proc: Can't start register read1\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					// Setup select of next block
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set GG address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = DFBLK_CMD;  // Set block select register
					g_BattTrans.byBattDataSize1 = 1; // One byte
					g_BattTrans.byBattDataBuff1[0] = MAN_BLK_C; // Manuf data block C

					// Setup read of data block
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set GG address and read
					g_BattTrans.byBattDataAddr2 = A_DF_CMD;  // Block data address
					g_BattTrans.byBattDataSize2 = GB_MANF_BLK_SIZE; // Block Size

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						g_dwBattDetectState = BATT_DET_GET_GDATA9; // Next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C20A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results20\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt21\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GET_GDATA10: // Get gifted battery data
		// Read done?
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			// Get results
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy((uint8_t *)&g_GiftedBattData.AR+RegBytesRead,g_BattTrans.byBattDataBuff1,g_BattTrans.byBattDataSize1);
				RegBytesRead += g_BattTrans.byBattDataSize1; // Add in the current bytes

				// Are we done?
				if (RegBytesRead >= GB_CMD_FULL_READ_SIZE)
				{ // Yes, setup for the next state
					// Setup read of status register
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Start read of status reg
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_CHECK_STATUS2; // Set to read status register
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C104\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{ // No, read more bytes
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set gas gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = AR_CMD+RegBytesRead; // Start read at current address

					// Read next chunk of registers
					if ((RegBytesRead+GB_CMD_PARTIAL_READ_SIZE) > GB_CMD_FULL_READ_SIZE)  // Going too far?
					{ // Yes, do smaller read
						g_BattTrans.byBattDataSize1 = GB_CMD_FULL_READ_SIZE - RegBytesRead;
					}
					else
					{ // No, read size is OK
						g_BattTrans.byBattDataSize1 = GB_CMD_PARTIAL_READ_SIZE;
					}

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Setup next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwTries = MPA3_TRIES;
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Proc: Can't start register read2\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					// Read more bytes
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set gas gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = AR_CMD+RegBytesRead; // Start read at current address

					if (!RegBytesRead)  // First read?
					{
						if (Pointers->MuxedClock)  // Are we using a clock mux?
							g_BattTrans.byBattDataSize1 = GB_CMD_PARTIAL_READ_SIZE; // yes, read first chunk of registers
						else
							g_BattTrans.byBattDataSize1 = GB_CMD_FULL_READ_SIZE; // No, read all the registers
					}
					else
					{
						// Read next chunk of registers
						if ((RegBytesRead+GB_CMD_PARTIAL_READ_SIZE) > GB_CMD_FULL_READ_SIZE)  // Going too far?
						{ // Yes, do smaller read
							g_BattTrans.byBattDataSize1 = GB_CMD_FULL_READ_SIZE - RegBytesRead;
						}
						else
						{ // No, read size is OK
							g_BattTrans.byBattDataSize1 = GB_CMD_PARTIAL_READ_SIZE;
						}
					}

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Setup next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Proc: Can't start register read2A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Proc: Bad capacity read\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else
		{  // Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt22\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_CHECK_STATUS2:  // Read status register, check hibernate bit
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check for hibernate still set
				if (STATUS_LOW_HIBERNATE_BIT & g_BattTrans.byBattDataBuff1[0])
				{
					if (DidReset) // Already tried once?
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: HB reset second try\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
					else
						g_dwBattDetectState = BATT_DET_RESET1; // Go to reset state
				}
				else  // OK, start validation
					g_dwBattDetectState = BATT_DET_GVAL; // Set to do validation

				dwLoop = FAST_LOOP/20;  // Very short loop delay
			}
			else  // No good, check for retries
			{
				--dwTries;
				if (dwTries)  // More left
				{ // Yup
					// Setup read of status register
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					// Start read of status reg
					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataSize2 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_CHECK_STATUS2; // Set to read status register
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C104A\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results105\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt105\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_RESET1:  // Write first unseal key

		// Setup send of key
		g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
		g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
		g_BattTrans.byBattChipAddr2 = 0; // No second transaction
		g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
		g_BattTrans.byBattDataBuff1[0] = UNSEAL_KEY1 & 0xff;
		g_BattTrans.byBattDataBuff1[1] = (UNSEAL_KEY1 >> 8) & 0xff;
		g_BattTrans.byBattDataSize1 = 2; // 2 bytes

		if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
		{  // Set next state
			g_dwBattDetectState = BATT_DET_RESET2; // Check control write
			dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
			dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		else  // No good, give up.
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C100\n"));
			Pointers->GG_WasReset = 2;  // Set error code
			DetectFailCode = CHG_COMM_ERROR;
			goto NoBatteryFound;
		}
		break;

	case BATT_DET_RESET2:  // Write second unseal key
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Found MPA3 Batt, and sent first key

				// Start write of second key
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = UNSEAL_KEY2 & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (UNSEAL_KEY2 >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes


				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_RESET3; // Check for unsealed
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C101\n"));
					Pointers->GG_WasReset = 3;  // Set error code
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // No good
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C102\n"));
				Pointers->GG_WasReset = 4;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt100\n"));
				Pointers->GG_WasReset = 5;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_RESET3:  // Start status read
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Sent both keys
				// Setup read of flags to check if we are unsealed
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_RESET4; // Check unseal went OK
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C103\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
					Pointers->GG_WasReset = 6;  // Set error code
				}
			}
			else // Failed!
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C103\n"));
				Pointers->GG_WasReset = 7;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt101\n"));
				Pointers->GG_WasReset = 8;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_RESET4:  // Check for OK to read status reg
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Start read of status reg
				// Setup I2C structure
				g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes


				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_RESET5; // Get status reg
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C110\n"));
					Pointers->GG_WasReset = 9;  // Set error code
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of device type from GG
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_READ_CONTROL_STATUS & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_READ_CONTROL_STATUS >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_CHECK_STATUS2; // Get firmware version
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C111\n"));
						Pointers->GG_WasReset = 10;  // Set error code
						DetectFailCode = CHG_COMM_ERROR;
						goto NoBatteryFound;
					}
				}
				else  // No more tries left, give up
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C112\n"));
					Pointers->GG_WasReset = 11;  // Set error code
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt110\n"));
				Pointers->GG_WasReset = 12;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_RESET5:  // Read status register, check sealed bit
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check for unsealed
				if (STATUS_HIGH_SS_BIT & g_BattTrans.byBattDataBuff1[1])
				{ // Still sealed, give up
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt111\n"));
					Pointers->GG_WasReset = 13;  // Set error code
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
				else  // OK, send reset
				{
					DidReset = 1; // Set tried reset flag

					// Setup write of reset command
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattChipAddr2 = 0; // No second transaction
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_RESET_CHIP & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_RESET_CHIP >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_RESET6; // Get firmware version
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C113\n"));
						Pointers->GG_WasReset = 14;  // Set error code
						DetectFailCode = CHG_COMM_ERROR;
						goto NoBatteryFound;
					}
				}
			}
			else  // No good, give up.
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results 114\n"));
				Pointers->GG_WasReset = 15;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 115\n"));
				Pointers->GG_WasReset = 16;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_RESET6:  // Done sending reset command?
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Restart detection
				g_dwBattDetectState = g_dwBattDetectAfterResetState; // Start over
				dwLoop = FAST_LOOP;  // Short loop delay
				Pointers->GG_WasReset = 1;  // Set OK code
			}
			else  // No good, give up.
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results 116\n"));
				Pointers->GG_WasReset = 17;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 117\n"));
				Pointers->GG_WasReset = 18;  // Set error code
				DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_GVAL:  // Validate gifted battery data
		// Verify fixed manf blocks
		for (dwCnt = 0; dwCnt < GB_MANF_BLK_SIZE; ++dwCnt)  // Check fixed blocks
		{
			if (BlockA_Fixed[dwCnt] != g_GiftedBattData.BlockA[dwCnt] || BlockB_Fixed[dwCnt] != g_GiftedBattData.BlockB[dwCnt])
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad manf fixed block\n"));
				if (Pointers->UseAuthData)
					DetectFailCode = CHG_MEM_ERROR;
				else
					DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}

		// Check Manf block C checksum
		cpnt = (uint8_t *)&g_GiftedBattData.Checksum_c;
		cCSum = 0;
		for (dwCnt = 0; dwCnt < GB_MANF_BLK_SIZE; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+dwCnt);
		}
		if (cCSum) // Bad checksum?
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad manf checksum\n"));
			if (Pointers->UseAuthData)
				DetectFailCode = CHG_MEM_ERROR;
			else
				DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Verify gifted battery Manf area type
		if (g_GiftedBattData.DataFormat541 != GB_MANF_SupportedType) // Check data type
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad manf data type\n"));
			if (Pointers->UseAuthData)
				DetectFailCode = CHG_MEM_ERROR;
			else
				DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Set static data
		Pointers->myear = ((g_GiftedBattData.DateMade[2] & 0x0f) << 8) | g_GiftedBattData.DateMade[1];
		Pointers->mmonth = g_GiftedBattData.DateMade[2] >> 4;
		Pointers->mday = g_GiftedBattData.DateMade[0];
		Pointers->type = BATTERY_CHEMISTRY_LION;

		// Do longer New part number
		memcpy(sz_PN,g_GiftedBattData.BatteryPartNumber,21);
		sz_PN[21] = 0;  // Add terminator at max gifted part number length

		if (g_GiftedBattData.Revision >= 0xc9)
		{
			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%s R.%02d", sz_PN, g_GiftedBattData.Revision-0xc8);
		}
		else if (g_GiftedBattData.Revision <= 26)
		{
			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%s R.%c", sz_PN, '@'+g_GiftedBattData.Revision);
		}
		else
		{
			local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%s R.%c%c", sz_PN, '@'+((g_GiftedBattData.Revision-1)/26)
																						,'A'+((g_GiftedBattData.Revision-1)%26));
		}

		// Do older Ex part number
		// Added support for longer part number "ex" for CQ138814
		sz_PN[18] = 0;  // Add terminator at max Symbol part number length to fit into 24 char string w/rev.

		if (g_GiftedBattData.Revision >= 0xc9)
		{
			local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%s R.%02d", sz_PN, g_GiftedBattData.Revision-0xc8);
		}
		else if (g_GiftedBattData.Revision <= 26)
		{
			local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%s R.%c", sz_PN, '@'+g_GiftedBattData.Revision);
		}
		else
		{
			local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%s R.%c%c", sz_PN, '@'+((g_GiftedBattData.Revision-1)/26)
																						,'A'+((g_GiftedBattData.Revision-1)%26));
		}

		// Do clipped part number field
		sz_PN[13] = 0;  // Add terminator at max Moto part number length to fit into 19 char string w/rev.

		if (g_GiftedBattData.Revision >= 0xc9)
		{
			local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"%s R.%02d", sz_PN, g_GiftedBattData.Revision-0xc8);
		}
		else if (g_GiftedBattData.Revision <= 26)
		{
			local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"%s R.%c", sz_PN, '@'+g_GiftedBattData.Revision);
		}
		else
		{
			local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"%s R.%c%c", sz_PN, '@'+((g_GiftedBattData.Revision-1)/26)
																						,'A'+((g_GiftedBattData.Revision-1)%26));
		}

		memcpy(Pointers->batteryID,g_GiftedBattData.SerialNumber,5);
		Pointers->batteryID[5] = 0;  // Add terminator

		g_GiftedBattData.PadByte1 = 0;  // Clear pad bytes
		g_GiftedBattData.PadByte2 = 0;

		// Check Static section checksum
		cpnt = (uint8_t *)&g_GiftedBattData;   // NOTE: Also used in a loop down a bit
		cCSum = 0;
		for (dwCnt = 0; dwCnt < GB_STATIC_DATA_SIZE; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+dwCnt);
		}
		if (cCSum) // Bad checksum?
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad battery static checksum\n"));
			if (Pointers->UseAuthData)
				DetectFailCode = CHG_MEM_ERROR;
			else
				DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Verify gifted battery static data area type
		if (g_GiftedBattData.DataType != GB_SupportedType) // Check data type
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad battery data type\n"));
			if (Pointers->UseAuthData)
				DetectFailCode = CHG_MEM_ERROR;
			else
				DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Verify gifted battery BQ block allocation byte
		if (g_GiftedBattData.Block_Allocation_27541 != GB_BQ_ALLOC)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad gifted battery data1\n"));
			if (Pointers->UseAuthData)
				DetectFailCode = CHG_MEM_ERROR;
			else
				DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Verify blank EEPROM blocks
		for (dwCnt = 0; dwCnt < (Pointers->UseAuthData ? 26 : 32); ++dwCnt)  // Check blocks
		{
			if (g_GiftedBattData.Block_Allocation_EEPROM & (1 << dwCnt))
			{  // block is free, check for default pattern
				for (cCSum = 0; cCSum < 15; ++cCSum)  // Check first 15 bytes
				{
					if (*(cpnt+(16*dwCnt)+cCSum) != dwCnt) // Check for block number in each byte
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Bad gifted battery data2\n"));
						if (Pointers->UseAuthData)
							DetectFailCode = CHG_MEM_ERROR;
						else
							DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
		}

		// Verify Lock Block
		cCSum = 0;
		// Start at the end of block and go backwards to work
		// around an optimization error cause by the compiler knowing
		// that g_GiftedBattData.Manufacture_ID is 8 bytes long and preventing
		// a loop cnt of 15 from being used.
		cpnt = (uint8_t *)&g_GiftedBattData.Checksum_y;
		for (dwCnt = 0; dwCnt < 15; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt-dwCnt);
		}
		if (cCSum) // Bad checksum?
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad lb checksum\n"));
			if (Pointers->UseAuthData)
				DetectFailCode = CHG_MEM_ERROR;
			else
				DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Show manufacturer IDs if needed
		if (SHOW_MF_ID)
		{
			RETAILMSG(ZONE_ERROR,("GGID: "));
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)
				RETAILMSG(ZONE_ERROR,("%02X%c",g_GiftedBattData.M200_Manf_ID[dwCnt],(dwCnt == 7 ? '\n' : ' ')));
			RETAILMSG(ZONE_ERROR,(" ID1: "));
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)
				RETAILMSG(ZONE_ERROR,("%02X%c",g_GiftedBattData.Dyn1Block[0].CopiedManufactureID[dwCnt],(dwCnt == 7 ? '\n' : ' ')));
			RETAILMSG(ZONE_ERROR,(" ID2: "));
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)
				RETAILMSG(ZONE_ERROR,("%02X%c",g_GiftedBattData.Dyn1Block[1].CopiedManufactureID[dwCnt],(dwCnt == 7 ? '\n' : ' ')));
			RETAILMSG(ZONE_ERROR,(" ID3: "));
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)
				RETAILMSG(ZONE_ERROR,("%02X%c",g_GiftedBattData.Dyn2Block[0].CopiedManufactureID[dwCnt],(dwCnt == 7 ? '\n' : ' ')));
			RETAILMSG(ZONE_ERROR,(" ID4: "));
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)
				RETAILMSG(ZONE_ERROR,("%02X%c",g_GiftedBattData.Dyn2Block[1].CopiedManufactureID[dwCnt],(dwCnt == 7 ? '\n' : ' ')));
			RETAILMSG(ZONE_ERROR,("EFPRC1: %d\n",g_GiftedBattData.Dyn2Block[0].EEFixedPattRewriteCtr));
			RETAILMSG(ZONE_ERROR,("BQFPPCA1: %d\n",g_GiftedBattData.Dyn2Block[0].BQFixedPattRewriteCtrA));
			RETAILMSG(ZONE_ERROR,("BQFPPCB1: %d\n",g_GiftedBattData.Dyn2Block[0].BQFixedPattRewriteCtrB));
			RETAILMSG(ZONE_ERROR,("EFPRC2: %d\n",g_GiftedBattData.Dyn2Block[1].EEFixedPattRewriteCtr));
			RETAILMSG(ZONE_ERROR,("BQFPPCA2: %d\n",g_GiftedBattData.Dyn2Block[1].BQFixedPattRewriteCtrA));
			RETAILMSG(ZONE_ERROR,("BQFPPCB2: %d\n",g_GiftedBattData.Dyn2Block[1].BQFixedPattRewriteCtrB));
		}

		// Check ID
		for (dwCnt = 0; dwCnt < 14; ++dwCnt)  // loop thru block data
		{
			if (dwCnt < 8)
			{ // Check ID
				if (g_GiftedBattData.Manufacture_ID[dwCnt] != g_GiftedBattData.M200_Manf_ID[dwCnt])
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad lb data1\n"));
					if (Pointers->UseAuthData)
						DetectFailCode = CHG_MEM_ERROR;
					else
						DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else
			{ // Check for zero
				if (g_GiftedBattData.DummyData[dwCnt-8])
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad lb data2\n"));
					if (Pointers->UseAuthData)
						DetectFailCode = CHG_MEM_ERROR;
					else
						DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
		}

		// Verify Dynamic block 1
		cpnt = (uint8_t *)&g_GiftedBattData.Dyn1Block[0];
		cCSum = 0;
		for (dwCnt = 0; dwCnt < 15; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+dwCnt);
		}

		if (cCSum) // Bad checksum?
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad dyn1 checksum\n"));

			// Check block 2 for good checksum
			cpnt = (uint8_t *)&g_GiftedBattData.Dyn1Block[1];
			cCSum = 0;
			for (dwCnt = 0; dwCnt < 15; ++dwCnt)  // Check checksum
			{
				cCSum = cCSum + *(cpnt+dwCnt);
			}

			if (cCSum) // Bad checksum?
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad dyn2 checksum\n"));
				if (Pointers->UseAuthData)
					DetectFailCode = CHG_MEM_ERROR;
				else
					DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}

			// Use block 2 data instead
			g_GiftedBattData.Dyn1Block[0] = g_GiftedBattData.Dyn1Block[1];
			g_bWriteDB1 = true;  // Trigger a rewrite of block 1
		}

		// Verify Dynamic block 2
		cpnt = (uint8_t *)&g_GiftedBattData.Dyn1Block[1];
		cCSum = 0;
		for (dwCnt = 0; dwCnt < 15; ++dwCnt)  // Check checksum
		{
			cCSum = cCSum + *(cpnt+dwCnt);
		}

		if (cCSum) // Bad checksum?
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Bad dyn2 checksum\n"));

			// Use block 1 data instead
			g_GiftedBattData.Dyn1Block[1] = g_GiftedBattData.Dyn1Block[0];
			g_bWriteDB2 = true;  // Trigger a rewrite of block 2
		}

		// Check ID in block1
		for (dwCnt = 0; dwCnt < 8; ++dwCnt)  // loop thru ID data
		{
			if (g_GiftedBattData.Dyn1Block[0].CopiedManufactureID[dwCnt] != g_GiftedBattData.M200_Manf_ID[dwCnt])
			{
				break; // Stop on error
			}
		}

		if (dwCnt < 8)  // Ended too soon?
		{ // Had an error
			// Check for all ones, only alowable error (unprogrammed part)
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)  // loop thru ID data
			{
				// Make sure it's all 0xff's
				if (0xff != g_GiftedBattData.Dyn1Block[0].CopiedManufactureID[dwCnt])
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad MID1\n"));
					if (Pointers->UseAuthData)
						DetectFailCode = CHG_MEM_ERROR;
					else
						DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery; // Error
				}
			}

			// Copy over correct string
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)  // loop thru ID data
			{
				g_GiftedBattData.Dyn1Block[0].CopiedManufactureID[dwCnt] = g_GiftedBattData.M200_Manf_ID[dwCnt];
			}
			// Set flag to trigger rewrite
			g_bWriteDB1 = true;
		}

		// Check ID in block2
		for (dwCnt = 0; dwCnt < 8; ++dwCnt)  // loop thru ID data
		{
			if (g_GiftedBattData.Dyn1Block[1].CopiedManufactureID[dwCnt] != g_GiftedBattData.M200_Manf_ID[dwCnt])
			{
				break; // Stop on error
			}
		}

		if (dwCnt < 8)  // Ended too soon?
		{ // Had an error
			// Check for all ones, only alowable error (unprogrammed part)
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)  // loop thru ID data
			{
				// Make sure it's all 0xff's
				if (0xff != g_GiftedBattData.Dyn1Block[1].CopiedManufactureID[dwCnt])
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad MID2\n"));
					if (Pointers->UseAuthData)
						DetectFailCode = CHG_MEM_ERROR;
					else
						DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery; // Error
				}
			}

			// Copy over correct string
			for (dwCnt = 0; dwCnt < 8; ++dwCnt)  // loop thru ID data
			{
				g_GiftedBattData.Dyn1Block[1].CopiedManufactureID[dwCnt] = g_GiftedBattData.M200_Manf_ID[dwCnt];
			}
			// Set flag to trigger rewrite
			g_bWriteDB2 = true;
		}

		// Update thresholds if we have a valid one
		if (Pointers->PercentThresholdSet)
		{
			// Check health threshold in block1
			if (g_GiftedBattData.Dyn1Block[0].HealthPct != Pointers->dwPercentThreshold)
			{ // Need an update
				g_GiftedBattData.Dyn1Block[0].HealthPct = (uint8_t)Pointers->dwPercentThreshold;
				// Set flag to trigger rewrite
				g_bWriteDB1 = true;
				RETAILMSG(ZONE_ERROR,("PM_Batt: Setting battery threshold: %d\n",Pointers->dwPercentThreshold));
			}

			// Check health threshold in block2
			if (g_GiftedBattData.Dyn1Block[1].HealthPct != Pointers->dwPercentThreshold)
			{ // Need an update
				g_GiftedBattData.Dyn1Block[1].HealthPct = (uint8_t)Pointers->dwPercentThreshold;
				// Set flag to trigger rewrite
				g_bWriteDB2 = true;
			}
		}
		else
		{ // Not set yet, use data in battery
			Pointers->dwPercentThreshold = g_GiftedBattData.Dyn1Block[0].HealthPct;
			RETAILMSG(ZONE_ERROR,("PM_Batt: Using battery threshold: %d\n",Pointers->dwPercentThreshold));
		}

		// Verify Dynamic blocks 3 & 4
// ***FIX*** do check/fix of manf ID bytes!!! (Need to add wr block 3 & 4 routines, and clears for bad MPA3 batt below)
		for (dwBcnt = 0; dwBcnt < 2; ++dwBcnt)
		{
			cpnt = (uint8_t *)&g_GiftedBattData.Dyn2Block[dwBcnt];
			cCSum = 0;
			for (dwCnt = 0; dwCnt < 15; ++dwCnt)  // Check checksum
			{
				cCSum = cCSum + *(cpnt+dwCnt);
			}

			if (cCSum) // Bad checksum?
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad dyn3_4 checksum\n"));
				if (Pointers->UseAuthData)
					DetectFailCode = CHG_MEM_ERROR;
				else
					DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}
		}

		// Check extended temp charging data if it's there
		if (EX_CHARGE_TEMP_BLOCKS != (g_GiftedBattData.Block_Allocation_EEPROM & EX_CHARGE_TEMP_BLOCKS))  // Check if any of those blocks are marked as used
		{
			// Zero the random pad bytes
			g_GiftedBattData.ExCharge.pad[10] = 0;
			for (dwCnt = 0; dwCnt < 5; ++dwCnt)
				g_GiftedBattData.ExCharge.TempRange[dwCnt].pad[2] = 0;

			// Check the checksum
			cpnt = (uint8_t *)&g_GiftedBattData.ExCharge;
			cCSum = 0;
			for (dwCnt = 0; dwCnt < sizeof(EX_TEMP_CHARGING_EP_t); ++dwCnt)  // Check checksum
			{
				cCSum = cCSum + *(cpnt+dwCnt);
			}
			if (cCSum) // Bad checksum?
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad ExTempCharge checksum\n"));
				if (Pointers->UseAuthData)
					DetectFailCode = CHG_MEM_ERROR;
				else
					DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}

			// Copy over the data
			Pointers->ExCharge.StopTemp = g_GiftedBattData.ExCharge.StopTemp;
			Pointers->ExCharge.RecMinTemp = g_GiftedBattData.ExCharge.RecMinTemp;
			Pointers->ExCharge.RecMaxTemp = g_GiftedBattData.ExCharge.RecMaxTemp;
			Pointers->ExCharge.Hysteresis = 2;
			for (dwCnt = 0; dwCnt < 5; ++dwCnt)
			{
				Pointers->ExCharge.TempRange[dwCnt].StartTemp = g_GiftedBattData.ExCharge.TempRange[dwCnt].StartTemp;
				for (dwBcnt = 0; dwBcnt < 3; ++dwBcnt)
				{
					Pointers->ExCharge.TempRange[dwCnt].Voltage[dwBcnt] = g_GiftedBattData.ExCharge.TempRange[dwCnt].Voltage[dwBcnt];
					Pointers->ExCharge.TempRange[dwCnt].Current[dwBcnt] = g_GiftedBattData.ExCharge.TempRange[dwCnt].Current[dwBcnt];
				}
			}
		}
		else
		{
			// Flush to 0
			Pointers->ExCharge.StopTemp = 0;
			Pointers->ExCharge.RecMinTemp = 0;
			Pointers->ExCharge.RecMaxTemp = 0;
			Pointers->ExCharge.Hysteresis = 0;
			for (dwCnt = 0; dwCnt < 5; ++dwCnt)
			{
				Pointers->ExCharge.TempRange[dwCnt].StartTemp = 0;
				for (dwBcnt = 0; dwBcnt < 3; ++dwBcnt)
				{
					Pointers->ExCharge.TempRange[dwCnt].Voltage[dwBcnt] = 0;
					Pointers->ExCharge.TempRange[dwCnt].Current[dwBcnt] = 0;
				}
			}
		}

		// Check for ship mode data being used
		if (!(g_GiftedBattData.Block_Allocation_EEPROM & QC660_DATA_BLOCK))
		{  // Block is used
			// Un-decrypt the block
			cpnt = (uint8_t *)&g_GiftedBattData._660Data;
			MovI2Cdata(cpnt,cpnt,Key1,1);

			// Check the checksum
			cCSum = 0;
			for (dwCnt = 0; dwCnt < 16; ++dwCnt)  // Check checksum
				cCSum = cCSum + *(cpnt+dwCnt);

			if (cCSum) // Bad checksum?
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad QC660 data block checksum!!!\n"));
				if (Pointers->UseAuthData)
					DetectFailCode = CHG_MEM_ERROR;
				else
					DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}

			// Move over data
			Pointers->BattFlags = g_GiftedBattData._660Data.Flags;
			Pointers->MinStartupVolt = g_GiftedBattData._660Data.MinStartupVolt;
			Pointers->ThermCoff = (uint32_t)g_GiftedBattData._660Data.ThermCoff[0];
			Pointers->ThermCoff |= ((uint32_t)g_GiftedBattData._660Data.ThermCoff[1]) << 8;
			Pointers->ThermCoff |= ((uint32_t)g_GiftedBattData._660Data.ThermCoff[2]) << 16;
			Pointers->UVLO = g_GiftedBattData._660Data.UVLO;
			Pointers->OVLO = g_GiftedBattData._660Data.OVLO;
			Pointers->CutOff = g_GiftedBattData._660Data.CutoffVolt;
			Pointers->RechargeVoltageDelta = g_GiftedBattData._660Data.RechargeVoltDelta;
		}
		else
		{  // No data, use defaults
			RETAILMSG(ZONE_ERROR,("PM_Batt: No QC660 data, using 0's\n"));
			Pointers->BattFlags = 0;
			Pointers->MinStartupVolt = 0;
			Pointers->ThermCoff = 0;
			Pointers->UVLO = 0;
			Pointers->OVLO = 0;
			Pointers->CutOff = 0;
			Pointers->RechargeVoltageDelta = 0;
		}

		// Check for ship mode data being used
		if (!(g_GiftedBattData.Block_Allocation_EEPROM & SHIP_MODE_BLOCK))
		{  // Block is used
			// Un-decrypt the block
			cpnt = (uint8_t *)&g_GiftedBattData.ShipMode;
			MovI2Cdata(cpnt,cpnt,Key1,1);

			// Check the checksum
			cCSum = 0;
			for (dwCnt = 0; dwCnt < SHIP_MODE_SIZE; ++dwCnt)  // Check checksum
				cCSum = cCSum + *(cpnt+dwCnt);

			if (cCSum) // Bad checksum?
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Bad ship mode data checksum!!!\n"));
				if (Pointers->UseAuthData)
					DetectFailCode = CHG_MEM_ERROR;
				else
					DetectFailCode = CHG_COMM_ERROR;
				goto BadMPA3Battery;
			}

			// Do we have usefull voltage data?
			if (0 == g_GiftedBattData.ShipMode.HighVoltage
				|| 0 == g_GiftedBattData.ShipMode.LowVoltage)
			{  // Nope
				RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode voltage data, using defaults\n"));
				Pointers->dwShipModeVoltHi = g_ShipModeDefaults.HighVoltage;
				Pointers->dwShipModeVoltLow = g_ShipModeDefaults.LowVoltage;
			}
			else
			{  // Have voltage values
				Pointers->dwShipModeVoltHi = g_GiftedBattData.ShipMode.HighVoltage;
				Pointers->dwShipModeVoltLow = g_GiftedBattData.ShipMode.LowVoltage;
			}

			// Do we have usefull capacity data?
			if (0 == g_GiftedBattData.ShipMode.HighCapacity
				|| 0 == g_GiftedBattData.ShipMode.LowCapacity)
			{  // Nope
				RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode capacity data, using defaults\n"));
				Pointers->dwShipModeCapHi = g_ShipModeDefaults.HighCapacity;
				Pointers->dwShipModeCapLow = g_ShipModeDefaults.LowCapacity;
			}
			else
			{  // Have capacity values
				Pointers->dwShipModeCapHi = g_GiftedBattData.ShipMode.HighCapacity;
				Pointers->dwShipModeCapLow = g_GiftedBattData.ShipMode.LowCapacity;
			}
		}
		else
		{  // No data, use defaults
			RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode data, using defaults\n"));
			Pointers->dwShipModeVoltHi = g_ShipModeDefaults.HighVoltage;
			Pointers->dwShipModeVoltLow = g_ShipModeDefaults.LowVoltage;
			Pointers->dwShipModeCapHi = g_ShipModeDefaults.HighCapacity;
			Pointers->dwShipModeCapLow = g_ShipModeDefaults.LowCapacity;
		}

		// Check for forcing invalid batt
		if (FORCE_INVALID)
		{
			RETAILMSG(ZONE_ERROR,("PM_Batt: Force Bad batt!!!\n"));
			DetectFailCode = CHG_COMM_ERROR;
			goto BadMPA3Battery;
		}

		// Set common data
		if (DesignCap > g_GiftedBattData.CC_Threshold)  // Use higer of design cap and CC_Threshold
			Pointers->batteryRatedCapacity = DesignCap;
		else
			Pointers->batteryRatedCapacity = g_GiftedBattData.CC_Threshold;
		Pointers->battFaireLevel = g_GiftedBattData.Faire;
		Pointers->battUnfaireLevel = g_GiftedBattData.Unfaire;
		Pointers->battLowLevel = g_GiftedBattData.Low;
		Pointers->AbnormalCurrent = g_GiftedBattData.AbnormalCharge_mA;
		Pointers->BattSlowCurr = g_GiftedBattData.SlowCharge_mA;
		Pointers->MinBattSlowCurr = 0;
		Pointers->BattFastCurr = g_GiftedBattData.FastCharge_mA;
		Pointers->NearlyDoneCurrent = g_GiftedBattData.NearlyCharged_mA;
		Pointers->DoneCurrent = g_GiftedBattData.ChargeTerm_mA;
		Pointers->MinChrgTemp = g_GiftedBattData.ChargeColdOff_C;
		Pointers->ColdOnTemp = g_GiftedBattData.ChargeColdOn_C;
		Pointers->MaxChrgTemp = g_GiftedBattData.ChargeHotOff_C;
		Pointers->HotOnTemp = g_GiftedBattData.ChargeHotOn_C;
		Pointers->TotalAccCharge = g_GiftedBattData.Dyn1Block[0].BatteryLifeData;
		Pointers->SOH = g_GiftedBattData.SOH;
		Pointers->RM = g_GiftedBattData.RM;
		Pointers->FCC = g_GiftedBattData.FCC;
		Pointers->TTE = g_GiftedBattData.TTE;
		Pointers->TTF = g_GiftedBattData.TTF;
		Pointers->ChargeSlowMins = g_GiftedBattData.ChargeSlowMins;
		Pointers->ChargeFastMins = g_GiftedBattData.ChargeFastMins;
		Pointers->SlowFastCharge_mV = g_GiftedBattData.SlowFastCharge_mV;
		Pointers->ChargeUp_mV = g_GiftedBattData.ChargeUp_mV;
		Pointers->Authentic = 1;

/* ***FIX***  Defeat low 1725 limit
		if (0 == g_Device.dwDisable1725Low) // Are we OK to check low temps?
*/
			Pointers->BattMinDTemp = g_GiftedBattData.DischargeMin_C;  // yes
/*		else
			Pointers->g_BattMinDTemp = VERY_COLD;  // No
*/

		Pointers->BattMaxDTemp = g_GiftedBattData.DischargeMax_C;

		// Set MPA2 state of health
		if (Pointers->dwPercentThreshold > g_GiftedBattData.SOH)
		{ // Bad health
			Pointers->battHealth = BATT_SOH_UNHEALTHY;
		}
		else
		{ // Good health
			Pointers->battHealth = BATT_SOH_HEALTHY;
		}

		// Convert temp
		if (g_GiftedBattData.TEMP < 2032 || g_GiftedBattData.TEMP > 3732) // Out of range (-70C to +100C), set to invalid
		{
			RETAILMSG(1, ("PM_Proc: Reset GG4\n"));
			Pointers->CurTemp =  NO_BATT_TEMP;
			g_dwBattDetectState = BATT_DET_RESET1;  //  Start GG reset
			g_dwBattDetectAfterResetState = BATT_DET_START; // Start over after GG reset
			CancelAccess(); // Stop any battery I/O
			dwLoop = FAST_LOOP/20;  // Very short loop delay
			break;
		}
		else
		{  // Convert to deg C
			tmp = (int16_t)g_GiftedBattData.TEMP - 2732;  // Convert to .1 deg C
			tmp = tmp / 10;  // Convert to deg C
			if (tmp > g_GiftedBattData.DischargeMax_C || tmp <  g_GiftedBattData.DischargeMin_C)  // Force temp to be in OK range, only this one time.
				Pointers->CurTemp = 25; // Set fake temp
			else
				Pointers->CurTemp = tmp; // Set new temp
			LastGGTmp = tmp;  // Set last gas gauge temp
		}

		// Set total charge
		g_dwAggregateCharge = g_GiftedBattData.CC_Threshold * g_GiftedBattData.CHGCC + g_GiftedBattData.LCCA;
		g_dwLastTC = g_dwAggregateCharge;  // Save current accumulated charge for Zebra TC calcs
		Pointers->TotalAccChargeAll = g_dwAggregateCharge; // Save charge from all devices

		Pointers->CycleCount = g_GiftedBattData.CHGCC; // Update cycle count

		// Update secs since first use
		Pointers->dwSecSinceFirstUse = ((uint32_t)g_GiftedBattData.ETU << 16) | (uint32_t)g_GiftedBattData.ETL;

		Pointers->battCapacity = g_GiftedBattData.SOC; // Set capacity

		g_dwDoChgAcc = true;  // Enable charge acc stuff
		DoAccTime = local_GetStopTime(120000); // Reset charge accumulation timer

		g_GiftedBattData.Last_CHGCC = 0;  // Clear last cycle count/charge accumulator values
		g_GiftedBattData.Last_LCCA = 0;

		ChargerInit();  // Reset charger stuff

		g_BattType = BATT_M200; // Set to old gauge battery
		g_dwBattDetectState = BATT_DET_IDLE; // Done
		Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
		g_dwBattCommErrCnt = 0; // Clear comm error counter
		ResetRateLimit();
		ShowBatteryData();  // Show battery data if needed

		// Call battery found function
		local_BatteryFound(FOUND_NEW_BATT);

		g_bReadQMAX_DAY = true;  // Trigger read of Qmax day value
		break;

//****************************************************************************
//  Start of new gas gauge states!
//****************************************************************************
	case BATT_DET_NGG1:  // Check new gauge device type
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(GG_DEVICE_TYPE,g_BattTrans.byBattDataBuff2) != 6)
					goto BATT_DET_NGG1_retry;

				// Copy over data
				memcpy((void *)(&g_GiftedV2Data.GG_DeviceType),g_BattTrans.byBattDataBuff2+2,2);

				// Check for valid device type
				if (NGG_DEVICE_TYPE != g_GiftedV2Data.GG_DeviceType)
				{  // invalid device type
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Device Type\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
					break;
				}

				Pointers->GG_DeviceType = g_GiftedV2Data.GG_DeviceType;
				Pointers->ARpnt = &g_GiftedV2Data.AR; // Set reg dump pointer

				// Setup read of firmware version from GG
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = GG_FW_VERSION & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (GG_FW_VERSION >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG2;  //  Start GG reset
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C201\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG1_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of device type from GG
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_DEVICE_TYPE & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_DEVICE_TYPE >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C200\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt201\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt202\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG2:  // Get new gauge firmware version
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(GG_FW_VERSION,g_BattTrans.byBattDataBuff2) != 15)
					goto BATT_DET_NGG2_retry;

				// Copy over data
				memcpy((void *)(&g_GiftedV2Data.GG_FirmwareVer),g_BattTrans.byBattDataBuff2+2,11);

				// Setup read of manuf name
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_MANF_NAME & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_NAME >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG3;  // Get name
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C206\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG2_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of firmware version from GG
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = GG_FW_VERSION & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (GG_FW_VERSION >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C206B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt206\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt206B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG3:  // Get manf name
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				dwBlkCnt = BlockReadCheck(NGG_MANF_NAME,g_BattTrans.byBattDataBuff2) - 4;
				if (dwBlkCnt < 1 || dwBlkCnt > 21)
					goto BATT_DET_NGG3_retry;

				// Copy over data
				memcpy((void *)(g_GiftedV2Data.ManufName),g_BattTrans.byBattDataBuff2+2,dwBlkCnt);
				g_GiftedV2Data.ManufName[dwBlkCnt] = 0;

				// Setup read of manuf date
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_MANF_DATE & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_DATE >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG4;  // Get date
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C207\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG3_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of manuf name
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_MANF_NAME & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_NAME >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C207B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt207\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt207B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG4:  // Get manf date
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_MANF_DATE,g_BattTrans.byBattDataBuff2) != 6)
					goto BATT_DET_NGG4_retry;

				// Copy over data
				memcpy((void *)(&g_GiftedV2Data.DateMade),g_BattTrans.byBattDataBuff2+2,2);

				// Setup read of serial number
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_SERIAL_NUM & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_SERIAL_NUM >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG5;  // Get serial number
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C208\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG4_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of manuf date
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_MANF_DATE & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_DATE >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C208B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt208\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt208B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG5:  // Get serial number
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_SERIAL_NUM,g_BattTrans.byBattDataBuff2) != 6)
					goto BATT_DET_NGG5_retry;

				// Copy over data
				memcpy((void *)(&g_GiftedV2Data.SerialNum),g_BattTrans.byBattDataBuff2+2,2);

				// Setup read of manuf block A
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_MANF_BLKA & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_BLKA >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG6;  // Get block A
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C209\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG5_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of serial number
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_SERIAL_NUM & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_SERIAL_NUM >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C209B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt209\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt209B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG6:  // Get manuf block A
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_MANF_BLKA,g_BattTrans.byBattDataBuff2) != 36)
					goto BATT_DET_NGG6_retry;

				// Copy over data
				memcpy((void *)(&g_GiftedV2Data.InitData),g_BattTrans.byBattDataBuff2+2,32);

				// Setup read of manuf block A
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_MANF_BLKB & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_BLKB >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG7;  // Get block B
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C210\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG6_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of manuf block A
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_MANF_BLKA & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_BLKA >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C210B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt210\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt210B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG7:  // Get manuf block B
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_MANF_BLKB,g_BattTrans.byBattDataBuff2) != 36)
					goto BATT_DET_NGG7_retry;

				// Copy over data
				memcpy((void *)((uint8_t *)(&g_GiftedV2Data.InitData)+32),g_BattTrans.byBattDataBuff2+2,32);

				// Setup read of manuf block A
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_MANF_BLKC & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_BLKC >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG8;  // Get block C
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C211\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG7_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of manuf block B
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_MANF_BLKB & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_BLKB >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C211B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt211\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt211B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG8:  // Get manuf block C
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_MANF_BLKC,g_BattTrans.byBattDataBuff2) != 36)
					goto BATT_DET_NGG8_retry;

				// Copy over data
				memcpy((void *)((uint8_t *)(&g_GiftedV2Data.InitData)+64),g_BattTrans.byBattDataBuff2+2,32);

				// Setup read of registers
				g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = AR_CMD; // AR register
				g_BattTrans.byBattDataSize1 = 0x20; // 32 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = AR_CMD + 0x20; // Next chunk
				g_BattTrans.byBattDataSize2 = 0x1c; // Rest of registers

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG9;  // Get design capacity
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C212\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG8_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of manuf block C
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = NGG_MANF_BLKC & 0xff;
					g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_BLKC >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C212B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt212\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt212B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG9:  // Get registers
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy((void *)(&g_GiftedV2Data.AR),g_BattTrans.byBattDataBuff1,0x20);
				memcpy((void *)(&g_GiftedV2Data.AP),g_BattTrans.byBattDataBuff2,0x1c);

				// Setup read of lifetime data
				dwBlkCnt = 0; // Reading first block

				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_LIFE_TIME_CAPS & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_LIFE_TIME_CAPS >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG10;  // Get design capacity
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C213\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of registers
					g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = AR_CMD; // AR register
					g_BattTrans.byBattDataSize1 = 0x20; // 32 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = AR_CMD + 0x20; // Next chunk
					g_BattTrans.byBattDataSize2 = 0x1e; // Rest of registers

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C213B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt213\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt213B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG10:  // Get block of time/cap data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_LIFE_TIME_CAPS+dwBlkCnt,g_BattTrans.byBattDataBuff2) != 36)
					goto BATT_DET_NGG10_retry;

				// Copy over data
				memcpy((void *)((uint8_t *)(&g_GiftedV2Data.times[dwBlkCnt])),g_BattTrans.byBattDataBuff2+2,32);

				// Done yet?
				++dwBlkCnt;
				if (dwBlkCnt >= 7)
				{ // On to the next thing
					// Setup read of auth chip data
					g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
					g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
					g_BattTrans.byBattDataSize1 = ZA_MAX_SIZE; // Read whole chip

					g_BattTrans.byBattChipAddr2 = 0; // No second transaction

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						g_dwBattDetectState = BATT_DET_NGG11;  // Check all data
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
						dwTries = MPA3_TRIES; // Set retry counter
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C214C\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
					break;
				}

				// Setup read of next block
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = (NGG_LIFE_TIME_CAPS+dwBlkCnt) & 0xff;
				g_BattTrans.byBattDataBuff1[1] = ((NGG_LIFE_TIME_CAPS+dwBlkCnt) >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_NGG10;  // Get design capacity
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
					dwTries = MPA3_TRIES; // Set retry counter
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C214\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}
			}
			else // Check for more tries
			{
BATT_DET_NGG10_retry:
				--dwTries;
				if (dwTries)
				{
					// Setup read of manuf block C
					g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
					g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
					g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
					g_BattTrans.byBattDataBuff1[0] = (NGG_LIFE_TIME_CAPS+dwBlkCnt) & 0xff;
					g_BattTrans.byBattDataBuff1[1] = ((NGG_LIFE_TIME_CAPS+dwBlkCnt) >> 8) & 0xff;
					g_BattTrans.byBattDataSize1 = 2; // 2 bytes

					g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
					g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
					g_BattTrans.byBattDataSize2 = 36; // Block read

					g_BattTrans.DoStop = 1; // Force stop in between

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C214B\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt214\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto NoBatteryFound;
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt214B\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case BATT_DET_NGG11: // Check all V2 PP+ data
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Copy over data
				memcpy((void *)(&g_GiftedV2Data),g_BattTrans.byBattDataBuff1,ZA_MAX_SIZE);

				// Validate data
				// Verify block1
				cCSum = 0;
				cpnt = (uint8_t *)&g_GiftedV2Data;
				for (dwCnt = 0; dwCnt <= 51; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Block1 checksum\n"));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check format type
				if (1 != g_GiftedV2Data.B1FormatRev)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Block1 Format Revision: %d\n",g_GiftedV2Data.B1FormatRev));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Verify block2
				cCSum = 0;
				for (dwCnt = 52; dwCnt <= 147; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Block2 checksum\n"));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check format type
				if (1 != g_GiftedV2Data.B2FormatRev)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Block2 Format Revision: %d\n",g_GiftedV2Data.B2FormatRev));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Verify block3
				cCSum = 0;
				for (dwCnt = 200; dwCnt <= 631; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Block3 checksum\n"));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check format type
				if (1 != g_GiftedV2Data.B3FormatRev)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Block3 Format Revision: %d\n",g_GiftedV2Data.B3FormatRev));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check JEITA format type
				if (1 != g_GiftedV2Data.JEITA.DataType)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 JEITA Format Revision: %d\n",g_GiftedV2Data.JEITA.DataType));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Verify agg chrg block1
				cCSum = 0;
				for (dwCnt = 148; dwCnt < 156; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Agg Chrg Block1 checksum\n"));

					// Verify agg chrg block2
					cCSum = 0;
					for (dwCnt = 156; dwCnt < 164; ++dwCnt)
						cCSum += cpnt[dwCnt];

					if (cCSum)
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Agg Chrg Block1&2 checksums\n"));
						DetectFailCode = CHG_MEM_ERROR;
						goto BadMPA3Battery;
					}

					// Use data from second block
					g_GiftedV2Data.AggCharge1.AcumChg = g_GiftedV2Data.AggCharge2.AcumChg;

					// Trigger update of first block
					g_bWriteNGG_AC1 = true;
				}
				else
				{  // Verify agg chrg block2
					cCSum = 0;
					for (dwCnt = 156; dwCnt < 164; ++dwCnt)
						cCSum += cpnt[dwCnt];

					if (cCSum)
					{
						// Use data from first block
						g_GiftedV2Data.AggCharge2.AcumChg = g_GiftedV2Data.AggCharge1.AcumChg;

						// Trigger update of second block
						g_bWriteNGG_AC2 = true;
					}
				}

				// Verify intial times block
				cCSum = 0;
				for (dwCnt = 164; dwCnt < 196; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Inital Times Block checksum\n"));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Verify health block
				cCSum = 0;
				for (dwCnt = 196; dwCnt < 200; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Health Block checksum\n"));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check inital data block
				cCSum = 0;
				for (dwCnt = 632; dwCnt < 643; ++dwCnt)
					cCSum += cpnt[dwCnt];

				if (cCSum)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Initial Data checksum\n"));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check format type
				if (1 != g_GiftedV2Data.InitData.Rev)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Bad V2 Initial Data Format Revision: %d\n",g_GiftedV2Data.InitData.Rev));
					DetectFailCode = CHG_MEM_ERROR;
					goto BadMPA3Battery;
				}

				// Check cell ident data block
// ***FIX*** Get from Brad!!!

				// Copy over data
				// Set static data
				Pointers->myear = (g_GiftedV2Data.DateMade >> 9) + 1980;
				Pointers->mmonth = (g_GiftedV2Data.DateMade & 0x1e0) >> 5;
				Pointers->mday = g_GiftedV2Data.DateMade & 0x1f;
				Pointers->type = BATTERY_CHEMISTRY_LION;

				// Reformat part number
				for(dwCnt = 0, dwBcnt = 0; dwCnt < 20; ++dwCnt)
				{
					if ('%' == g_GiftedV2Data.PartNumber[dwCnt])
					{
						sz_PN[dwBcnt++] = ' ';
						sz_PN[dwBcnt++] = 'R';
						sz_PN[dwBcnt++] = '.';
					}
					else
					{
						sz_PN[dwBcnt++] = g_GiftedV2Data.PartNumber[dwCnt];
					}
				}
				sz_PN[20] = 0;  // Add terminator at max VT part number length

				// Do longer New part number
				local_sprint(Pointers->batteryPartNumberNew,PART_NUMBER_LENGTH_NEW,"%s", sz_PN);

				// Do older Ex part number
				local_sprint(Pointers->batteryPartNumberEx,PART_NUMBER_LENGTH_EX,"%s", sz_PN);

				// Do clipped part number field
				sz_PN[18] = 0;  // Add terminator at max Moto part number length to fit into 19 char string w/rev.
				local_sprint(Pointers->batteryPartNumber,PART_NUMBER_LENGTH,"%s", sz_PN);

				// Serial number
				local_sprint(Pointers->batteryID,18,"%c%04d",g_GiftedV2Data.ManufName[0],g_GiftedV2Data.SerialNum);

				// Update thresholds if we have a valid one
				if (Pointers->PercentThresholdSet)
				{
					// Check health threshold in battery
					if (g_GiftedV2Data.Health.Health != Pointers->dwPercentThreshold)
					{ // Need an update
						g_GiftedV2Data.Health.Health = (uint8_t)Pointers->dwPercentThreshold;
						// Set flag to trigger rewrite
						g_bWriteHD = true;
						RETAILMSG(ZONE_ERROR,("PM_Batt: Setting battery threshold: %d\n",Pointers->dwPercentThreshold));
					}
				}
				else
				{ // Not set yet, use data in battery
					Pointers->dwPercentThreshold = g_GiftedV2Data.Health.Health;
					RETAILMSG(ZONE_ERROR,("PM_Batt: Using battery threshold: %d\n",Pointers->dwPercentThreshold));
				}

				// Set non-JEITA data to defaults
				Pointers->ChargeUp_mV = 4100;
				Pointers->BattFastCurr = 1000;
				Pointers->MinChrgTemp = 10;
				Pointers->ColdOnTemp = 11;
				Pointers->MaxChrgTemp = 42;
				Pointers->HotOnTemp = 41;

				// Copy over the JEITA data
				Pointers->ExCharge.StopTemp = g_GiftedV2Data.JEITA.StopTemp;
				Pointers->ExCharge.RecMinTemp = g_GiftedV2Data.JEITA.RecMinTemp;
				Pointers->ExCharge.RecMaxTemp = g_GiftedV2Data.JEITA.RecMaxTemp;
				Pointers->ExCharge.Hysteresis = g_GiftedV2Data.ChargerCtrl.Hysteresis;
				for (dwCnt = 0; dwCnt < 5; ++dwCnt)
				{
					Pointers->ExCharge.TempRange[dwCnt].StartTemp = g_GiftedV2Data.JEITA.TempRange[dwCnt].StartTemp;
					for (dwBcnt = 0; dwBcnt < 3; ++dwBcnt)
					{
						Pointers->ExCharge.TempRange[dwCnt].Voltage[dwBcnt] = g_GiftedV2Data.JEITA.TempRange[dwCnt].Voltage[dwBcnt];
						Pointers->ExCharge.TempRange[dwCnt].Current[dwBcnt] = g_GiftedV2Data.JEITA.TempRange[dwCnt].Current[dwBcnt];
					}
					// Check for in range that has 25Deg. C
					// Use the first JEITA data from that range for non-JEITA defaults
					if (g_GiftedV2Data.JEITA.TempRange[dwCnt].StartTemp < 25)  // Min temp under 25
					{
						// Check next start temp if used, else use stop temp
						if (dwCnt < 4 && g_GiftedV2Data.JEITA.TempRange[dwCnt+1].Voltage[0] != 0)
							dwBcnt = g_GiftedV2Data.JEITA.TempRange[dwCnt+1].StartTemp;
						else
							dwBcnt = g_GiftedV2Data.JEITA.StopTemp;

						if (25 < dwBcnt)  // In this range?
						{
							// Set non-JEITA stuff from current range
							Pointers->ChargeUp_mV = g_GiftedV2Data.JEITA.TempRange[dwCnt].Voltage[0];
							Pointers->BattFastCurr = g_GiftedV2Data.JEITA.TempRange[dwCnt].Current[0];
							Pointers->MinChrgTemp = g_GiftedV2Data.JEITA.TempRange[dwCnt].StartTemp;
							Pointers->ColdOnTemp = g_GiftedV2Data.JEITA.TempRange[dwCnt].StartTemp + 1;
							Pointers->MaxChrgTemp = dwBcnt;
							Pointers->HotOnTemp = dwBcnt - 1;
						}
					}
				}

				// Copy ship mode data
				// Do we have usefull voltage data?
				if (0 == g_GiftedV2Data.ShipMode.HighVoltage
					|| 0 == g_GiftedV2Data.ShipMode.LowVoltage)
				{  // Nope
					RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode voltage data, using defaults\n"));
					Pointers->dwShipModeVoltHi = g_ShipModeDefaults.HighVoltage;
					Pointers->dwShipModeVoltLow = g_ShipModeDefaults.LowVoltage;
				}
				else
				{  // Have voltage values
					Pointers->dwShipModeVoltHi = g_GiftedV2Data.ShipMode.HighVoltage;
					Pointers->dwShipModeVoltLow = g_GiftedV2Data.ShipMode.LowVoltage;
				}

				// Do we have usefull capacity data?
				if (0 == g_GiftedV2Data.ShipMode.HighCapacity
					|| 0 == g_GiftedV2Data.ShipMode.LowCapacity)
				{  // Nope
					RETAILMSG(ZONE_ERROR,("PM_Batt: No ship mode capacity data, using defaults\n"));
					Pointers->dwShipModeCapHi = g_ShipModeDefaults.HighCapacity;
					Pointers->dwShipModeCapLow = g_ShipModeDefaults.LowCapacity;
				}
				else
				{  // Have capacity values
					Pointers->dwShipModeCapHi = g_GiftedV2Data.ShipMode.HighCapacity;
					Pointers->dwShipModeCapLow = g_GiftedV2Data.ShipMode.LowCapacity;
				}

				// Check for forcing invalid batt
				if (FORCE_INVALID)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Force Bad batt!!!\n"));
					DetectFailCode = CHG_COMM_ERROR;
					goto BadMPA3Battery;
				}

				// Do time since first use stuff
				// Do we have inital times yet?
				wTabCnt = 0;
				for (dwCnt = 0; dwCnt < 7; ++dwCnt)
					wTabCnt += g_GiftedV2Data.IT.Time[dwCnt];
				if (!wTabCnt)
				{  // Nope setup inital times
					RETAILMSG(ZONE_ERROR,("PM_Batt: Setting inital times\n"));
					for (dwCnt = 0; dwCnt < 7; ++dwCnt)
					{
						wTabCnt = 0;
						for (dwBcnt = 0; dwBcnt < 8; ++dwBcnt)
							wTabCnt += g_GiftedV2Data.times[dwCnt][dwBcnt];
						g_GiftedV2Data.IT.Time[dwCnt] = wTabCnt;
					}
					// Set flag to trigger initial time update
					g_bWriteIT = true;
				}
				Update_TSFU(); // Calculate time ince first use

				// Set common data
				Pointers->batteryRatedCapacity = g_GiftedV2Data.ManfCapacity_ma;
				Pointers->battFaireLevel = g_GiftedV2Data.BatteryLow;
				Pointers->battUnfaireLevel = g_GiftedV2Data.BatteryVeryLow;
				Pointers->battLowLevel = g_GiftedV2Data.BatteryCritical;
				Pointers->RechargeVoltageDelta = g_GiftedV2Data.ChargerCtrl.RechargeVoltDelta;
				Pointers->AbnormalCurrent = g_GiftedV2Data.ChargerCtrl.AbnormalCurr;
				Pointers->BattSlowCurr = g_GiftedV2Data.ChargerCtrl.SlowChrgCurr;
				Pointers->MinBattSlowCurr = 0;
				Pointers->ChargeSlowMins = g_GiftedV2Data.ChargerCtrl.SlowChrgTimeout * 10;
				Pointers->ChargeFastMins = g_GiftedV2Data.ChargerCtrl.FastChrgTimeout * 10;
				Pointers->SlowFastCharge_mV = g_GiftedV2Data.ChargerCtrl.SlowFastVolt;
				Pointers->NearlyDoneCurrent = g_GiftedV2Data.ChargerCtrl.NearlyDoneCurr;
				Pointers->DoneCurrent = g_GiftedV2Data.ChargerCtrl.FallBackTermCurr;

				g_dwDoChgAcc = true;  // Enable charge acc stuff
				DoAccTime = local_GetStopTime(120000); // Reset charge accumulation timer

				if (g_GiftedV2Data.RSOC > 100)  // Check for wacky RSOC
					Pointers->battCapacity = 50;
				else
					Pointers->battCapacity = g_GiftedV2Data.RSOC;
				Pointers->SOH = g_GiftedV2Data.SOH;
				Pointers->RM = g_GiftedV2Data.RM;
				Pointers->FCC = g_GiftedV2Data.FCC;
				Pointers->TTE = g_GiftedV2Data.TTE;
				Pointers->TTF = g_GiftedV2Data.TTF;
				Pointers->Authentic = 1;

				// Set total charge, cycle count
				Pointers->TotalAccChargeAll = g_GiftedV2Data.CC * g_GiftedV2Data.DCAP; // Save charge from all devices
				Pointers->TotalAccCharge  = g_GiftedV2Data.AggCharge1.AcumChg; // Save charge from zebra devices
				Pointers->CycleCount = Pointers->TotalAccChargeAll / g_GiftedV2Data.ManfCapacity_ma;
				LastVTcap = g_GiftedV2Data.RSOC;

				// 1725 data
				Pointers->BattMinDTemp = g_GiftedV2Data._1725DiscLowLimit;
				Pointers->BattMaxDTemp = g_GiftedV2Data._1725DiscHighLimit;

				// 660 data block
				Pointers->BattFlags = g_GiftedV2Data._660Data.Flags;
				Pointers->MinStartupVolt = g_GiftedV2Data._660Data.MinStartupVolt;
				Pointers->ThermCoff = (uint32_t)g_GiftedV2Data._660Data.ThermCoff[0];
				Pointers->ThermCoff |= ((uint32_t)g_GiftedV2Data._660Data.ThermCoff[1]) << 8;
				Pointers->ThermCoff |= ((uint32_t)g_GiftedV2Data._660Data.ThermCoff[2]) << 16;
				Pointers->UVLO = g_GiftedV2Data._660Data.UVLO;
				Pointers->OVLO = g_GiftedV2Data._660Data.OVLO;
				Pointers->CutOff = g_GiftedV2Data._660Data.CutoffVolt;

				// Update voltage, current, and temp
				Pointers->Voltage = g_GiftedV2Data.VOLT;
				Pointers->Current = g_GiftedV2Data.AI;
				Pointers->CurTemp = g_GiftedV2Data.TEMP;

				ChargerInit();  // Reset charger stuff

				// Return found PP+ battery!
				g_BattType = BATT_Z561;  // Set to new gg battery
				g_dwBattDetectState = BATT_DET_IDLE; // Done
				Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
				g_dwBattCommErrCnt = 0; // Clear comm error counter
				ResetRateLimit();

				ShowBatteryData();  // Show battery data if needed

				// Call battery found function
				local_BatteryFound(FOUND_NEW_BATT);

				g_bReadQMAX_DAY = true;  // Trigger read of Qmax day value
			}
			else // Check for more tries
			{
				--dwTries;
				if (dwTries)
				{
					// Setup read of auth chip data
					g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
					g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
					g_BattTrans.byBattDataSize1 = ZA_MAX_SIZE; // Read whole chip

					g_BattTrans.byBattChipAddr2 = 0; // No second transaction

					if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
					{  // Set next state
						dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
						dwLoop = FAST_LOOP/20;  // Very short loop delay
					}
					else  // No good, give up.
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C215\n"));
						DetectFailCode = CHG_COMM_ERROR;
						goto BadMPA3Battery;
					}
				}
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt215\n"));
				DetectFailCode = CHG_COMM_ERROR;
				goto NoBatteryFound;
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case NGG_CHECK_BATT1:  // Check for same NGG batt, step 1
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Got data!
				// Check first 22 btyes to make sure they match
				// This will check the data fomat, checksum, and part#
				cpnt = (uint8_t *)(&g_GiftedV2Data);

				for (dwCnt = 0; dwCnt < 22; ++dwCnt)
				{
					if (cpnt[dwCnt] != g_BattTrans.byBattDataBuff1[dwCnt])
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: V2 ID Missmatch @%d\n",dwCnt));
						DidReset = 0; // Clear did reset flag
						goto StartBattDetect;  // Just restart detect
					}
				}

				// Looks good so far, now check the manufacture date
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_MANF_DATE & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_MANF_DATE >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = NGG_CHECK_BATT2;  // Get date
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C216\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}
			}
			else  // No good, try restarting.
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results 119B\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 121\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case NGG_CHECK_BATT2:  // Check manf date
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_MANF_DATE,g_BattTrans.byBattDataBuff2) != 6)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: V2 Date Error\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}

				// Check date
				cpnt = (uint8_t *)&g_GiftedV2Data.DateMade;
				if (cpnt[0] != g_BattTrans.byBattDataBuff2[2] || cpnt[1] != g_BattTrans.byBattDataBuff2[3])
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: V2 Date Missmatch\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}

				// Setup read of serial number
				g_BattTrans.byBattChipAddr1 = MPA3GG;  // Set Gas Gauge address and write
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = CNTL_CMD; // Control()
				g_BattTrans.byBattDataBuff1[0] = NGG_SERIAL_NUM & 0xff;
				g_BattTrans.byBattDataBuff1[1] = (NGG_SERIAL_NUM >> 8) & 0xff;
				g_BattTrans.byBattDataSize1 = 2; // 2 bytes

				g_BattTrans.byBattChipAddr2 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byBattDataAddr2 = ALT_MANF_ACC; // Manf access
				g_BattTrans.byBattDataSize2 = 36; // Block read

				g_BattTrans.DoStop = 1; // Force stop in between

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = NGG_CHECK_BATT3;  // Get serial number
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, give up.
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C217\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}
			}
			else // give up
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C217\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 122\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	case NGG_CHECK_BATT3:  // Check serial number
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check block transfer
				if (BlockReadCheck(NGG_SERIAL_NUM,g_BattTrans.byBattDataBuff2) != 6)
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: V2 Serial Number Error\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}

				// Check serial number
				cpnt = (uint8_t *)&g_GiftedV2Data.SerialNum;
				if (cpnt[0] != g_BattTrans.byBattDataBuff2[2] || cpnt[1] != g_BattTrans.byBattDataBuff2[3])
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: V2 Serial Number Missmatch\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}

				// Same batt, start using it
				g_BattType = BATT_Z561; // Set battery type to new gauge
// Don't reset charger on same batt, we now suspend while charging
//				ChargerInit();  // Reset charger stuff
				g_dwBattDetectState = BATT_DET_IDLE; // Done
				Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
				g_dwBattCommErrCnt = 0; // Clear comm error counter
				ResetRateLimit();
				local_BatteryFound(FOUND_OLD_BATT);  // Call battery found function, not new batt.

				// Set flag to get latest temp and capacity
				g_bReadMPA3Regs = true;
				dwLoop = FAST_LOOP/20;  // Very short loop delay
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 123\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

//****************************************************************************
//  End of new gas gauge states!
//****************************************************************************

BadMPA3Battery:
		CancelAccess();  // Cancel any writes
		Pointers->BatteryIsInvalid = DetectFailCode;  // Save invalid cause
		Pointers->BatteryType = GB_INVALID; // Set to "Invalid" battery
		local_InvalidBattery(DetectFailCode);  // Bad battery!
		g_dwBattDetectState = BATT_DET_IDLE;  // Back to idle
		dwLoop = NORM_LOOP;  // Regular loop delay
		local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
		break;

NoBatteryFound:
		CancelAccess();  // Cancel any writes
		Pointers->BatteryType = GB_OTHER; // Default to "other" battery
		Pointers->BatteryIsInvalid = CHG_COMM_ERROR;  // Save invalid reason
		local_InvalidBattery(CHG_COMM_ERROR);  // No battery!
		g_dwBattDetectState = BATT_DET_IDLE;  // Back to idle
		dwLoop = NORM_LOOP;  // Regular loop delay
		local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
		break;

	case BATT_DET_TOSS:
		dwLoop = FAST_LOOP/20;  // Very short loop delay
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			g_dwBattDetectState = g_dwBattDetectRestartState; // Done
			if (BATT_DET_GET_ID1 == g_dwBattDetectState) // Looking for the same battery?
				goto CheckForSameBatt;
		}
		else
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 3 secs?
			{ // Too long!
				g_dwBattDetectState = g_dwBattDetectRestartState; // Done
			}
		}
		break;

	case BATT_DET_RESTART:
		dwLoop = FAST_LOOP;  // Short loop delay
		g_dwBattDetectState = g_dwBattDetectRestartState;  // Switch to the restart state select by the PM software
		break;

	case BATT_DET_GET_ID1: // Start checking battery ID
CheckForSameBatt:
		RETAILMSG(SHOW_DET_STATES,("PM_Batt: Start ID Check\n"));

		// Check battery voltage
		if (local_GetBatteryVoltage() <= MIN_BATT_VOLTS)  // Is voltage OK to talk to battery?
		{  // Nope, give up and start over
			// Invalidate the battery
			Pointers->BatteryType = GB_LOOKING; // Default to looking for battery
			local_InvalidBattery(BM_BATTERY_LOOKING);  // Invalidate battery
			local_BatteryFound(FOUND_NEW_BATT);  // Call battery found function
			DidReset = 0; // Clear did reset flag
			goto StartBattDetect;  // Just restart detect
		}

		// Voltage is OK!
		// Check what kind of battery we had before
		switch(Pointers->BatteryType)
		{
		case GB_GIFTED:
			switch (g_OldBattType)
			{
			case BATT_Z561:  // Z561 GG battery
				// Just recheck for same battery
				// Start read of fist 32 bytes of auth data
				// Setup I2C structure
				g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
				g_BattTrans.byBattDataSize1 = 32; // Read fist 32 bytes
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = NGG_CHECK_BATT1; // Check data
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, start over
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C118A\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}
				break;
			case BATT_M200: // Old M200 Gauge, check manf ID
				// Start read of Manf ID
				// Setup I2C structure
				g_BattTrans.byBattChipAddr1 = MPA3GG | 0x01;  // Set Gas Gauge address and read
				g_BattTrans.byLargeEEPROMAddr = 0;  // Set to normal addressing
				g_BattTrans.byBattChipAddr2 = 0; // No second transaction
				g_BattTrans.byBattDataAddr1 = MFGID_CMD; // Manuf ID
				g_BattTrans.byBattDataSize1 = 8; // 8 bytes

				if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
				{  // Set next state
					g_dwBattDetectState = BATT_DET_GET_ID2; // Get gifted data
					dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
					dwLoop = FAST_LOOP/20;  // Very short loop delay
				}
				else  // No good, start over
				{
					RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C118\n"));
					DidReset = 0; // Clear did reset flag
					goto StartBattDetect;  // Just restart detect
				}
				break;
			default:  // Just in case
				local_print("PM_Batt: Unknown type in BATT_DET_GET_ID1: %d\n",g_BattType);
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
				break;
			}
			break;
		case GB_VALUE:  // Value tier
			// Just recheck for same battery
			// Start read of fist 32 bytes of auth data
			// Setup I2C structure
			g_BattTrans.byBattChipAddr1 = AUTH_CHIP | 0x01;  // Set auth chip address and read
			g_BattTrans.byBattDataAddr1 = 0; // Start of chip data
			g_BattTrans.byBattDataSize1 = 32; // Read fist 32 bytes
			g_BattTrans.byBattChipAddr2 = 0; // No second transaction

			if (ERROR_SUCCESS == local_EA_BattTransaction(&g_BattTrans)) // Start battery data transaction
			{  // Set next state
				g_dwBattDetectState = BATT_DET_VTCHK; // Check data
				dwBDStopTime = local_GetStopTime(EA_WAIT_TIME); // Get stop time
				dwLoop = FAST_LOOP/20;  // Very short loop delay
				dwTries = MPA3_TRIES; // Set retry counter
			}
			else  // No good, start over
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't start battery I2C118A\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
			break;
		case GB_SMART:  // Smart battery
// GB_TPB no longer supported
//		case GB_TPB:  // Third party pack
		case GB_INVALID:  // Bad battery
		case GB_UNAUTHENTIC:
		case GB_OTHER:
		default:  // Just in case
			DidReset = 0; // Clear did reset flag
			goto StartBattDetect;  // Just restart detect
			break;
		}
		break;

	case BATT_DET_GET_ID2: // Finish checking battery ID
		if (g_BattTrans.hCommCmpltEvnt)  // Done yet?
		{
			if (ERROR_SUCCESS == local_EA_BattTransresult(&g_BattTrans))
			{
				// Check for the correct Manufacture ID
				for (dwCnt = 0; dwCnt < 8; ++dwCnt)
				{
					if (g_GiftedBattData.M200_Manf_ID[dwCnt] != g_BattTrans.byBattDataBuff1[dwCnt])
					{
						RETAILMSG(ZONE_ERROR,("PM_Batt: ID Missmatch\n"));
						DidReset = 0; // Clear did reset flag
						goto StartBattDetect;  // Just restart detect
					}
				}
				// ID is good, start using it
// Don't reset charger after resume on same batt
//				ChargerInit();  // Reset charger stuff

				g_BattType = BATT_M200;
				g_dwBattDetectState = BATT_DET_IDLE; // Done
				Pointers->BatteryIsInvalid = CHG_NO_ERROR;  // Battery OK!
				g_dwBattCommErrCnt = 0; // Clear comm error counter
				local_BatteryFound(FOUND_OLD_BATT);  // Call battery found function, not new batt.

				// Set flag to get latest temp and capacity
				g_bReadMPA3Regs = true;
			}
			else  // No good, try restarting.
			{
				RETAILMSG(ZONE_ERROR,("PM_Batt: Can't get results 119\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
		}
		else  // Not done yet
		{
			// Been too long?
			if (local_PastTime(dwBDStopTime)) // Been longer than 5 secs?
			{ // Too long!
				RETAILMSG(ZONE_ERROR,("PM_Batt: No Batt 120\n"));
				DidReset = 0; // Clear did reset flag
				goto StartBattDetect;  // Just restart detect
			}
			else // Keep trying
				dwLoop = FAST_LOOP/20;  // Very short loop delay
		}
		break;

	}
	return (dwLoop);
}

// Function to cancel any pending battery acceses
void CancelAccess(void)
{
	// Reset write data state machine
	dwWrBattMode = WR_MODE_TOSS; // Toss current operation
	ClearWriteFlags();
}

//------------------------------------------------------------------------------
//
//  Function:  GasGauge
//
//  Runs the battery gas gauge software
//
void GasGauge(uint32_t dwReset)
{
//	uint32_t dwCnt;
//	uint32_t dwCap;
//	uint32_t dwAdd;
//	uint8_t cFudgeTemp;

	// Check for reset needed
	if (dwReset)
	{	// Clear Gas Gauging data
		RETAILMSG(ZONE_FUNCTION,("BattMan: GasGauge Reset\n"));
/* ***FIX*** for Smart battery
		g_dwCapacity = BL_UNKNOWN;			// Current battery capacity = ???
		g_dwUnFilCapacity = BL_UNKNOWN;
		g_dwFilCapacity = BL_UNKNOWN;
		Pointers->dwBatteryLevel = BL_UNKNOWN;		// Battery level unknown
		g_dwBattTempErr = BATT_TEMP_OK;
		dwRateLimitStart = 0;
		dwAdded = 0;
		g_dwResistance = 0;
		g_dwVoltage = 0;
		dwWas255 = TRUE;
*/
		g_dwNextGasGaugeTime = local_GetStopTime(GAS_GAUGE_INTERVAL); // Get next gas gauge time
// ***FIX***		dwStartAvgTime = GetTickCount();  // Reset delay timer

		// Set event to update capacity/level
// ***FIX***		g_dwEventCauses |= (PM_EVENT_MAIN_BATT_STATUS | PM_EVENT_SMART_BATT_STATUS);
//		SetEvent(hPM_Event);

		return;  // We are done here!
	}

	// Time to do capacity?
	if (local_PastTime(g_dwNextGasGaugeTime))  // Been 5 seconds since the last time?
	{
		RETAILMSG(ZONE_FUNCTION,("BattMan: GasGauge Do Capacity\n"));
		g_dwNextGasGaugeTime = local_GetStopTime(GAS_GAUGE_INTERVAL);  // Set next gas gauge time

		switch (g_BattType)
		{
		case BATT_M200: // MPA3 battery. Request read of MPA3 GG registers if battery is OK
		case BATT_Z561: // V2 PP+ battery
			g_bReadMPA3Regs = true;

			if (DUMP_GG_DATA)  // If we are dumping the data, also get QMAX_DAY and CONTROL_STATUS
			{
				g_bReadQMAX_DAY = true;
				g_bReadCONTROL_STATUS = true;
			}
			break;
		case BATT_VT: // Value tier battery
			Pointers->CurTemp = local_GetBatteryTemp(); // Set new temp
			Pointers->Voltage = local_GetBatteryVoltage(); // Set new voltage
			Pointers->Current = local_GetBatteryCurrent(); // Set new current
			Pointers->battCapacity = local_GetBatteryCapacity(); // Set new capacity
			Pointers->RM = (u32)Pointers->battCapacity * Pointers->batteryRatedCapacity / 100; // Set new remaing maHrs
//***FIX***    FIgure new health flag???

			// Set event to update capacity/level
			local_NewData(1);
			break;
		case BATT_SMART: // Valid MPA2 battery
			Pointers->Voltage = local_GetBatteryVoltage(); // Set new voltage
			Pointers->Current = local_GetBatteryCurrent(); // Set new current
			Pointers->battCapacity = local_GetBatteryCapacity(); // Set new capacity
			Pointers->RM = (u32)Pointers->battCapacity * Pointers->batteryRatedCapacity / 100; // Set new remaing maHrs
//***FIX***    FIgure new health flag???

			g_bReadTempChip = true; // Start next temp read going
			break;
		case BATT_NONE:  // No batt to gauge yet
			break;
		default: // Shouldn't get here
			local_print("PM_Batt: Unknown type in GasGauge(): %d\n",g_BattType);
			break;
		}
/* No longer supported
		else if (GB_TPB == Pointers->BatteryType)
		{
			Pointers->Voltage = local_GetBatteryVoltage(); // Set new voltage
			Pointers->Current = local_GetBatteryCurrent(); // Set new current
			g_bReadTempChip = true; // Start next temp read going
		}
		// Do nothing for invalid/other battery
*/
	}
}

//------------------------------------------------------------------------------
//
//  Function:  FindNewLevel
//
//  Determines the battery charge level
//
uint32_t FindNewLevel(uint32_t dwCapacity)
{
	uint32_t dwLevel;

// ***FIX*** for Battery micro
//	; Set flag to trigger gas gauge/LED/Health update to battery micro
//	lds	TEMP, UpdateReady
//	ori	TEMP, GasGaugeUpdate
//	sts	UpdateReady, TEMP

	// Lookup new battery level
	if (dwCapacity > 100)
		dwLevel = BL_UNKNOWN;
	else if (dwCapacity > Pointers->battFaireLevel)
		dwLevel = BL_OK;
	else if (dwCapacity > Pointers->battUnfaireLevel)
		dwLevel = BL_FAIRE;
	else if (dwCapacity > (Pointers->battLowLevel * Pointers->dwAdjustPer / 100))
		dwLevel = BL_UNFAIRE;
	else
		dwLevel = BL_LOW;

	if (dwLevel != Pointers->dwBatteryLevel)  // Show new level if needed
		switch (dwLevel)
		{
		case BL_UNKNOWN:
			local_print("BattMan: Battery Unknown\n");
			break;
		case BL_OK:
			local_print("BattMan: Battery OK\n");
			break;
		case BL_FAIRE:
			local_print("BattMan: Battery Faire\n");
			break;
		case BL_UNFAIRE:
			local_print("BattMan: Battery Unfaire\n");
			break;
		case BL_LOW:
/*  ***FIX***
			// Are we delaying?
			if ((BM_CHARGER_DISABLED_STATE_NUM != g_dwChargerState)
				|| (GetTickCount() - dwStartUpTime) > g_Device.dwStartupCapDelay)
			{  // Not any more
*/
				local_print("BattMan: Battery Low\n");
/*
			}
			else
			{  // Yes
				dwLevel = BL_UNKNOWN;
				local_print("BattMan: Delaying Battery Low\n");
			}
*/
			break;
		}

	// Return new capacity level
	return(dwLevel);
}

/* ***FIX***  For Smart

//------------------------------------------------------------------------------
//
//  Function:  CapacityFilter1
//
//  Runs the battery capacity filter
//
uint32_t CapacityFilter1(uint32_t dwCap)
{
	uint32_t dwNewCap = 0;
	DWORD64 I4;

	// Do Capacity Filter 1
	// This filter is documented in the file "2nd Order Digital Filter.vsd"
//local_print("dwCap: %d\n",dwCap);

	if (!g_Device.dwCapFilter1Enable) // Is filter enabled?
	{
		return (dwCap); // Nope, just return current capacity
	}

	if (dwCap > 100)  // Valid capacity?
	{ // Nope
		dwWas255 = TRUE; // Set flag to restart on next valid capacity
		return (BL_UNKNOWN);
	}

	if (TRUE == dwWas255) // Check if init is needed
	{
		dwWas255 = false; // Reset need init flag

		dwSwitchCnt = g_Device.dwFilterSwitch; // Reset switchover counter

		// Reset filter to new value
		X0 = dwCap;
		X1 = dwCap;
		X2 = dwCap;
		Y0 = (DWORD64)dwCap << 16;
		Y1 = (DWORD64)dwCap << 16;
		Y2 = (DWORD64)dwCap << 16;

		// Get constants
		A0 = g_Device.A0;
		A1 = g_Device.A1;
		A2 = g_Device.A2;
		B1 = g_Device.B1;
		B2 = g_Device.B2;
//WCHAR msg[150];
//swprintf(msg,L"A0:%I64u  A1:%I64u  A2:%I64u B1:%I64u  B2:%I64u sc: %d\n",A0,A1,A2,B1,B2,dwSwitchCnt);
//local_print(msg);
	}
	else // No need to init
	{
		// Do flter calculatfon
//WCHAR msg[150];
//DWORD64 Tmp;
//Tmp = Y0;

		Y0 = (A0 * X0) + (A1 * X1) + (A2 * X2) + ((B1 * Y1) >> 15);
		I4 = (B2 * Y2) >> 16;

//swprintf(msg,L"Input  X0: %I64u  X1: %I64u  X2: %I64u  Y0: %I64u  Y1: %I64u  Y2: %I64u\n",X0,X1,X2,Tmp,Y1,Y2);
//local_print(msg);
		// Check for underflow
		if (I4 > Y0)
		{  // Yup, flush filter to 0
			X0 = 0;
			X1 = 0;
			X2 = 0;
			Y0 = 0;
			Y1 = 0;
			Y2 = 0;
		}
		else  // Do the subtract
			Y0 = Y0 - I4;

		dwNewCap = (uint32_t)(Y0 >> 16);  // Get new capacity

		if (dwNewCap > 100) // Check for Overflow
		{ // Yup, flush filter to 100
			X0 = 100;
			X1 = 100;
			X2 = 100;
			Y0 = 100 << 16;
			Y1 = 100 << 16;
			Y2 = 100 << 16;

			dwNewCap = 100;
		}

//swprintf(msg,L"Input  X0: %I64u  X1: %I64u  X2: %I64u  Y0: %I64u  Y1: %I64u  Y2: %I64u  Output  Y0: %I64u\n",X0,X1,X2,Tmp,Y1,Y2,Y0);
//local_print(msg);
//local_print("NewCap: %d\n",dwNewCap);

		// Shift stuff over
		X2 = X1;
		X1 = X0;
		X0 = dwCap;
		Y2 = Y1;
		Y1 = Y0;
	}

	if (0 != dwSwitchCnt) // Not time to use filter value yet?
	{ // Correct, not time yet.
		--dwSwitchCnt;  // Decrement counter

//local_print("sc: %d\n",dwSwitchCnt);
		if (0 == dwSwitchCnt) // Will it be time, next time?
		{ // Yes
			// Switch over next time, need to reinit?
			if (dwCap < dwNewCap) // Is current cap lower than filter?
			{  // Yes, reset filter to current capacity
				X0 = dwCap;
				X1 = dwCap;
				X2 = dwCap;
				Y0 = (DWORD64)dwCap << 16;
				Y1 = (DWORD64)dwCap << 16;
				Y2 = (DWORD64)dwCap << 16;
			}
		}

		dwNewCap = dwCap; // Return current value
	}

	return dwNewCap;
}

*/

// Function to check/update VT battery health byte
void VT_CheckHealth(void)
{
	if (Pointers->dwCycleCountThreshold < Pointers->CycleCount)
	{  // Unhealthy
		Pointers->battHealth = BATT_SOH_UNHEALTHY;
		// check for not currently marked as unhealthy
		if (g_ValueTierData.Health1.Health <= BATT_SOH_HEALTHY)
		{  // Change to bad
			g_ValueTierData.Health1.Health = BATT_SOH_UNHEALTHY;
			// Set update flag
			g_bWriteVTH1 = true;
		}
		if (g_ValueTierData.Health2.Health <= BATT_SOH_HEALTHY)
		{  // Change to bad
			g_ValueTierData.Health2.Health = BATT_SOH_UNHEALTHY;
			// Set update flag
			g_bWriteVTH2 = true;
		}
	}
	else
	{  // Healthy
		Pointers->battHealth = BATT_SOH_HEALTHY;
		// check for not currently marked as healthy
		if (g_ValueTierData.Health1.Health > BATT_SOH_HEALTHY)
		{  // Change to good
			g_ValueTierData.Health1.Health = BATT_SOH_HEALTHY;
			// Set update flag
			g_bWriteVTH1 = true;
		}
		if (g_ValueTierData.Health2.Health > BATT_SOH_HEALTHY)
		{  // Change to good
			g_ValueTierData.Health2.Health = BATT_SOH_HEALTHY;
			// Set update flag
			g_bWriteVTH2 = true;
		}
	}
}

// Function to update percent threshold
void UpdatePercent(uint32_t NewPercent)
{
	// Check for limit
	if (NewPercent > 100)
		NewPercent = 100;

	Pointers->dwPercentThreshold = NewPercent;
	Pointers->PercentThresholdSet = true;

	// Set new values and trigger updates if we have a valid gifted battery
	switch (g_BattType)
	{
	case BATT_Z561:  // New Gauge
		// Check current health threshold value
		if (g_GiftedV2Data.Health.Health != Pointers->dwPercentThreshold)
		{ // Need to update
			g_GiftedV2Data.Health.Health = (uint8_t)Pointers->dwPercentThreshold;
			g_bWriteHD = true;  // Trigger health update
		}
		break;
	case BATT_M200: // Old gauge
		// Check health threshold in block1
		if (g_GiftedBattData.Dyn1Block[0].HealthPct != Pointers->dwPercentThreshold)
		{ // Need an update
			g_GiftedBattData.Dyn1Block[0].HealthPct = (uint8_t)Pointers->dwPercentThreshold;
			// Set flag to trigger rewrite
			g_bWriteDB1 = true;
			RETAILMSG(ZONE_ERROR,("PM_Batt: Setting battery threshold: %d\n",Pointers->dwPercentThreshold));
		}

		// Check health threshold in block2
		if (g_GiftedBattData.Dyn1Block[1].HealthPct != Pointers->dwPercentThreshold)
		{ // Need an update
			g_GiftedBattData.Dyn1Block[1].HealthPct = (uint8_t)Pointers->dwPercentThreshold;
			// Set flag to trigger rewrite
			g_bWriteDB2 = true;
		}
		break;
	default:  // Not a PP+ batt
		local_print("PM_Batt: Warning, updating percent threshold with non PP+ Batt: %d\n",g_BattType);
		break;
	}
}

// Function to update cycle count threshold
void UpdateCycle(uint32_t NewCycle)
{
	Pointers->dwCycleCountThreshold = NewCycle;

	if (BATT_VT == g_BattType)
		VT_CheckHealth();
}

//**************************************************************************
// New gas gauge util functions
//**************************************************************************

// Fnction to check block read results
// Returns size of block read
uint8_t BlockReadCheck(int cmd, uint8_t buf[])
{
	int cnt;
	uint8_t csum;
	uint16_t tmp;

	// Check length
	if (buf[BLK_READ_LEN] < 5 || buf[BLK_READ_LEN] > 36)
	{
		RETAILMSG(ZONE_ERROR,("PM_Batt: Bad block read len: %d",buf[BLK_READ_LEN]));
		return (0);
	}

	// Check checksum
	csum = buf[BLK_READ_CSUM] + 1;
	for (cnt = 0; cnt < (buf[BLK_READ_LEN]-2); ++cnt)
		csum += buf[cnt];
	if (csum)
	{
		RETAILMSG(ZONE_ERROR,("PM_Batt: Bad block read csum: %d\n",csum));
		return (0);
	}

	// Check command
	if (buf[0] != (cmd & 0xff) || buf[1] != ((cmd >> 8) & 0xff))
	{
		tmp = ((uint16_t)buf[1]<<8) | (uint16_t)buf[0];
		RETAILMSG(ZONE_ERROR,("PM_Batt: Block read cmd mismatch: %04X - %04X\n",cmd,cnt));
		return (0);
	}

	return (buf[BLK_READ_LEN]);
}

// Function to update time since first use
void Update_TSFU(void)
{
	uint32_t InitialTotal, CurrentTotal, Cnt, Cnt2;

	InitialTotal = 0;
	CurrentTotal = 0;

	for (Cnt = 0; Cnt < 7; ++Cnt)
		InitialTotal += g_GiftedV2Data.IT.Time[Cnt];

	for (Cnt = 0; Cnt < 7; ++Cnt)
	{
		for (Cnt2 = 0; Cnt2 < 8; ++Cnt2)
			CurrentTotal += g_GiftedV2Data.times[Cnt][Cnt2];
	}

	Pointers->dwSecSinceFirstUse = CurrentTotal - InitialTotal;
RETAILMSG(ZONE_ERROR,("PM_Batt: TSFU: %d  %d\n",CurrentTotal,InitialTotal));
}
