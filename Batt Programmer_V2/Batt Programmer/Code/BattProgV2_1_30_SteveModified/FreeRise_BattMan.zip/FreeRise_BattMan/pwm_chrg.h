//--------------------------------------------------------------------
// FILENAME:	pwm_chrg.h
//
// Copyright (c) 2022 Zebra Technologies Corporation and/or its affiliates. All rights reserved.
//
// DESCRIPTION:	BattMan charger stuff include file
//
// Author:	Joe Cabana
//
//--------------------------------------------------------------------

#ifndef PWM_CHRG_H_
#define PWM_CHRG_H_

// Function prototypes
extern uint32_t DoChargerStuff(void);
extern void ChargerInit(void);

extern u32 g_dwChargerState;  // Current state of state machine

// Other defs
#define MIN_CHARGING_CURRENT	50  // Min current to be considered charging in ma
#define SLOW_FAST_WAIT 3	// Samples to check for slow to fast change
#define USB_DONE_WAIT 60	// Samples to check for being done in USB mode
#define Z561_RELAX_WAIT 62  // Relax time wait for Z561 gauge to enter relax state

// USB defs
#define	USB_DONE_VOLT_OFF	(u32)100	// Voltage below charge to voltage for USB charge done check

// Charger state number defs
#define BM_CHARGER_DISABLED_STATE_NUM 		0	// Charger disabled, MUST BE ZERO!!!
#define BM_START_CHG_STATE_NUM				1	// Start charging state
#define BM_SLOW_CHG_STATE_NUM				2	// Slow charging (conditioning) the battery
#define BM_FAST_CHG_STATE_NUM				3	// Fast charging the battery using external power
#define BM_BATT_NEARLY_CHARGED_STATE_NUM	4	// Battery is almost fully charged,

#define BM_START_USB_CHG_STATE_NUM			6	// Start USB charging state
#define BM_USB_FAST_CHG_STATE_NUM			7	// Fast charging the battery using USB power

#define	BM_FIRST_CAL_STATE					8	// Begining of calibration states
#define BM_WAIT_QMAX_DAY_STATE_NUM			8	// Wait for QMAX_DAY to be read
#define BM_WAIT_FLAT_TOP_STATE_NUM			9	// Charge till past flat region
#define BM_CAL_PREP_STATE_NUM				10	// Charge at "prep" current
#define BM_CAL_WAIT1_STATE_NUM				11	// Wait for OCV_Pred bit to be set
#define BM_CAL_CHARGE_STATE_NUM				12	// Fast charge till enough capacity is in the battery
#define BM_CAL_WAIT2_STATE_NUM				13	// Wait for OCV_Pred bit to be set

#define BM_NO_CHRG_START					15	// All non-charging states must be higher than this

#define BM_BATT_CHARGED_STATE_NUM			16	// Battery is fully charged

#define BM_TEMP_TOO_LO_STATE_NUM			17	// Temperature too low to charge battery
#define BM_TEMP_TOO_HI_STATE_NUM			18	// Temperature too high to charge battery

#define BM_CHRG_FAULT_START					20	// All permanant fault states must be higher than this

#define BM_SLOW_CHG_TIME_FAULT_STATE_NUM	21	// Battery is faulty - took too long to condition
#define BM_FAST_CHG_TIME_FAULT_STATE_NUM	22	// Battery is faulty - took too long to charge
#define BM_NO_BATTERY_STATE_NUM				23	// No battery in charger
#define BM_ABNORMAL_CURRENT_STATE_NUM		24	// Charger is faulty,  tries to charge at too high a current
#define BM_SLOW_CURR_FAULT_STATE_NUM		25	// Battery is faulty,  will not sustain slow charge current
												// even when not fully charged.
#define BM_TH_SHUTD_FAULT_STATE_NUM			26	// Thermal shutdown
#define BM_BAT_OVP_FAULT_STATE_NUM			27	// Battery over voltage
#define BM_POOR_SRC_FAULT_STATE_NUM			28	// Low input voltage
#define BM_SLP_MODE_FAULT_STATE_NUM			29	// Sleep mode (VBAT > VBUS)
#define BM_VBUS_OVP_FAULT_STATE_NUM			30	// VBUS over voltage
#define BM_EA_ERROR_FAULT_STATE_NUM			31	// EA error
#define BM_EA_CURR_FAULT_STATE_NUM			32	// EA over current error
#define BM_POOR_SRC_RESTART_STATE_NUM		33	// Try restart after delay from low input voltage error

// New gauge states
#define BM_CAL_WAIT_RELAXTIME1				40  // First 62 second wait time
#define BM_CAL_WAIT_GAUGING_STATUS1			41  // Wait for updated gauging status
#define BM_CAL_WAIT_OCV_PRED_ACTIVE_TIMER	42  // Wait for OCV_Pred_Active timer to time out
#define BM_CAL_WAIT_GAUGING_STATUS2			43  // Wait for updated gauging status
#define BM_CAL_WAIT_OCVPRED					44  // Wait for OCVPRED bit set
#define BM_CAL_WAIT_GAUGING_STATUS3			45  // Wait for updated gauging status
#define BM_CAL_WAIT_GAUGING_STATUS4			46  // Wait for updated gauging status
#define BM_CAL_WAIT_GAUGING_STATUS5			47  // Wait for updated gauging status
#define BM_CAL_WAIT_VOLTAGE					48  // Wait for voltage increase of 60mv

#endif	// #ifndef PWM_CHRG_H
