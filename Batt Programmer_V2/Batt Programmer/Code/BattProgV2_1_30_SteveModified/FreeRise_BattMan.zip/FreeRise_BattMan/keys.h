#ifndef KEYS_H_
#define KEYS_H_

// Device type to encryption key lookup table
// Sunrise - 1
// IronMan - 2
// Freeport - 3
// Falcon - 4

// Encryption keys
extern const uint8_t AllKeys1[5][16];

extern const uint8_t AllKeys2[5][16];

// Fixed block patterns
extern uint8_t BlockA_Fixed[];

extern uint8_t BlockB_Fixed[];

#endif	// #ifndef KEYS_H_
