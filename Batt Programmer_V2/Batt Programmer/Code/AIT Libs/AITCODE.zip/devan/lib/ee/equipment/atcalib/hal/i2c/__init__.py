from .linux import AtmelCryptoI2CLinux
#from .cypress import AtmelCryptoI2CCypress

#__all__ = ['AtmelCryptoI2CLinux', 'AtmelCryptoI2CCypress']
__all__ = ['AtmelCryptoI2CLinux']

