// Manufacture include file

uint8_t ManufacturePPP(uint8_t *Buf);
uint8_t ManufacturePollux(uint8_t *Buf, uint8_t Format);
uint8_t ManufactureHawkeye(uint8_t *Buf);
